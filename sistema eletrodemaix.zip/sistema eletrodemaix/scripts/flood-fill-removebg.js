import fs from 'fs';
import { PNG } from 'pngjs';
import jpeg from 'jpeg-js';

function processImage(inputPath, outputPath) {
  let png;
  if (inputPath.endsWith('.jpg') || inputPath.endsWith('.jpeg')) {
    const jpegData = fs.readFileSync(inputPath);
    const raw = jpeg.decode(jpegData, { useTArray: true });
    png = new PNG({ width: raw.width, height: raw.height });
    for (let i = 0; i < raw.data.length; i += 4) {
      png.data[i] = raw.data[i];
      png.data[i + 1] = raw.data[i + 1];
      png.data[i + 2] = raw.data[i + 2];
      png.data[i + 3] = 255;
    }
  } else {
    png = PNG.sync.read(fs.readFileSync(inputPath));
  }

  const { width, height, data } = png;
  const visited = new Uint8Array(width * height);
  const queue = [];

  // Determine if a pixel is background:
  // Background in these images is light neutral (gray/white/off-white)
  function isBackground(x, y) {
    const idx = (y * width + x) * 4;
    const r = data[idx];
    const g = data[idx + 1];
    const b = data[idx + 2];
    const a = data[idx + 3];

    if (a < 10) return true;

    // Check for light color (gray / white / light checkerboard)
    // Neutral means r, g, b are close to each other
    const maxDiff = Math.max(Math.abs(r - g), Math.abs(g - b), Math.abs(r - b));
    const avg = (r + g + b) / 3;

    // The logo character and text has orange, brown, dark, red, yellow, etc.
    // The background is neutral gray/white between 180 and 255, with low color difference
    if (avg > 185 && maxDiff < 20) {
      return true;
    }

    // Very light off-white
    if (avg > 240) {
      return true;
    }

    return false;
  }

  // Push all perimeter border pixels into queue if background
  for (let x = 0; x < width; x++) {
    if (isBackground(x, 0)) {
      visited[0 * width + x] = 1;
      queue.push(x, 0);
    }
    if (isBackground(x, height - 1)) {
      visited[(height - 1) * width + x] = 1;
      queue.push(x, height - 1);
    }
  }
  for (let y = 0; y < height; y++) {
    if (isBackground(0, y)) {
      visited[y * width + 0] = 1;
      queue.push(0, y);
    }
    if (isBackground(width - 1, y)) {
      visited[y * width + (width - 1)] = 1;
      queue.push(width - 1, y);
    }
  }

  // BFS Flood Fill from edges
  let head = 0;
  while (head < queue.length) {
    const x = queue[head++];
    const y = queue[head++];

    const neighbors = [
      [x + 1, y],
      [x - 1, y],
      [x, y + 1],
      [x, y - 1]
    ];

    for (const [nx, ny] of neighbors) {
      if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
        const nIndex = ny * width + nx;
        if (!visited[nIndex] && isBackground(nx, ny)) {
          visited[nIndex] = 1;
          queue.push(nx, ny);
        }
      }
    }
  }

  // Set all visited background pixels to completely transparent (alpha = 0)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const pIndex = y * width + x;
      const idx = pIndex * 4;

      if (visited[pIndex]) {
        data[idx + 3] = 0; // 100% transparent!
      } else {
        // Check if adjacent to transparent pixel for smooth edge feathering
        let hasTransparentNeighbor = false;
        const checkOffsets = [
          [x + 1, y],
          [x - 1, y],
          [x, y + 1],
          [x, y - 1]
        ];
        for (const [cx, cy] of checkOffsets) {
          if (cx >= 0 && cx < width && cy >= 0 && cy < height) {
            if (visited[cy * width + cx]) {
              hasTransparentNeighbor = true;
              break;
            }
          }
        }

        if (hasTransparentNeighbor) {
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          const avg = (r + g + b) / 3;
          if (avg > 210) {
            data[idx + 3] = Math.max(0, Math.min(255, Math.round(255 - (avg - 210) * 5)));
          }
        }
      }
    }
  }

  const outBuffer = PNG.sync.write(png);
  fs.writeFileSync(outputPath, outBuffer);
  console.log(`Processed ${outputPath}: ${queue.length / 2} pixels made transparent.`);
}

// Process the raw assets
processImage('./src/assets/images/eletrodemaix_nobg_logo_1790693468341.jpg', './public/eletrodemaix-logo.png');
processImage('./src/assets/images/favicon_transparent_1790693448568.jpg', './public/favicon.png');
processImage('./public/favicon.png', './public/favicon.ico');
processImage('./public/favicon.png', './src/assets/images/favicon.png');
processImage('./public/eletrodemaix-logo.png', './src/assets/images/eletrodemaix-logo.png');
