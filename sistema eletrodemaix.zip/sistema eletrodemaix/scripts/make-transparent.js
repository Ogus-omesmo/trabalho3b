import fs from 'fs';
import jpeg from 'jpeg-js';
import { PNG } from 'pngjs';

function processImage(inputJpgPath, outputPngPath) {
  const jpegData = fs.readFileSync(inputJpgPath);
  const rawImageData = jpeg.decode(jpegData, { useTArray: true });

  const width = rawImageData.width;
  const height = rawImageData.height;
  const png = new PNG({ width, height });

  // Scan and make white / near-white pixels completely transparent
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (width * y + x) << 2;
      const r = rawImageData.data[idx];
      const g = rawImageData.data[idx + 1];
      const b = rawImageData.data[idx + 2];

      // If near white (background)
      if (r > 238 && g > 238 && b > 238) {
        png.data[idx] = 255;
        png.data[idx + 1] = 255;
        png.data[idx + 2] = 255;
        png.data[idx + 3] = 0; // Completely transparent!
      } else if (r > 220 && g > 220 && b > 220) {
        // Anti-aliasing edge
        const alpha = Math.max(0, Math.min(255, 255 - ((r + g + b) / 3 - 220) * 14));
        png.data[idx] = r;
        png.data[idx + 1] = g;
        png.data[idx + 2] = b;
        png.data[idx + 3] = Math.round(alpha);
      } else {
        png.data[idx] = r;
        png.data[idx + 1] = g;
        png.data[idx + 2] = b;
        png.data[idx + 3] = 255; // Fully opaque
      }
    }
  }

  const buffer = PNG.sync.write(png);
  fs.writeFileSync(outputPngPath, buffer);
  console.log(`Saved transparent PNG to ${outputPngPath}`);
}

processImage('./src/assets/images/favicon_transparent_1790693448568.jpg', './public/favicon.png');
processImage('./src/assets/images/favicon_transparent_1790693448568.jpg', './public/favicon.ico');
processImage('./src/assets/images/eletrodemaix_nobg_logo_1790693468341.jpg', './public/eletrodemaix-logo.png');
processImage('./src/assets/images/favicon_transparent_1790693448568.jpg', './src/assets/images/favicon.png');
processImage('./src/assets/images/eletrodemaix_nobg_logo_1790693468341.jpg', './src/assets/images/eletrodemaix-logo.png');
