# Como Rodar o Sistema Médico Hospitalar no XAMPP (CRUD PHP + MySQL)

Este sistema foi construído para rodar perfeitamente no **XAMPP** com **PHP (7.4, 8.0, 8.1, 8.2 ou 8.3)** e **MySQL / MariaDB**.

---

### Passo 1: Instalar e Abrir o XAMPP
1. Caso ainda não tenha, baixe e instale o [XAMPP](https://www.apachefriends.org/).
2. Abra o **XAMPP Control Panel**.
3. Clique em **Start** nos módulos **Apache** e **MySQL**. Ambos devem ficar com a cor verde ("Running").

---

### Passo 2: Copiar os Arquivos para a pasta `htdocs`
1. Acesse o diretório de instalação do XAMPP (por padrão em `C:\xampp\htdocs\`).
2. Crie uma pasta chamada `hospital` (ou cole a pasta `crud-bootstrap-php-main` renomeada para `hospital`).
3. O caminho final dos arquivos deve ser:
   ```
   C:\xampp\htdocs\hospital\
   ├── conexao.php
   ├── api.php
   ├── index.php
   ├── sistema_hospitalar_xampp.sql
   └── ...
   ```

---

### Passo 3: Criar e Importar o Banco de Dados no phpMyAdmin
1. No seu navegador, abra o **phpMyAdmin**:
   ```
   http://localhost/phpmyadmin
   ```
2. Clique no menu superior **Importar** (Import).
3. Clique em **Escolher arquivo** e selecione o arquivo:
   `C:\xampp\htdocs\hospital\sistema_hospitalar_xampp.sql`
4. Role até o final da página e clique em **Executar** (Go).
5. O banco `hospital_db` será criado com todas as tabelas (`usuarios`, `fila_pacientes`, `fichas`, `remedios`, `historico_saidas`, `atendimentos`) e os registros iniciais já preenchidos.

---

### Passo 4: Acessar o Sistema
Abra seu navegador e acesse:
```
http://localhost/hospital/
```

---

### Credenciais Pré-configuradas no Banco de Dados:

| Perfil | Usuário | Senha | Função no Sistema |
| :--- | :--- | :--- | :--- |
| **Médico (Corpo Clínico)** | `DR. Gustavo` | `2108` | Fila com corte de prioridade, Ficha com aplicação de remédio, Histórico diário, Remédios e Atendimento |
| **Atendente (Recepção)** | `Mirella` | `3107` | Triagem, geração de senhas automáticas e gerenciamento da fila com corte de risco |
| **Enfermeiro** | `Enfermeiro` | `1111` | Atendimento clínico, sinais vitais e dispensação farmacológica |

---

### Operações CRUD Ativas via PHP + MySQL:
1. **Fila de Pacientes (Recepção):**
   - **Create:** Cadastra paciente com Grau de Importância (Simples, Cuidado, Urgente) gerando senhas automáticas (`SIMP-XXX`, `CUID-XXX`, `URG-XXX`). Urgentes cortam a fila para o topo.
   - **Read:** Listagem em tempo real ordenada pelo corte de fila e horário.
   - **Update:** Altera status para 'Chamado' ou altera o grau de urgência.
   - **Delete/Cancelar:** Marca como cancelado ou remove da fila ativa.

2. **Fichas e Prontuários (Consultório Médico):**
   - **Create:** Emite Ficha Clínica, Laudo, Atestado ou Outros com código único auto-gerado.
   - **Aplicação de Medicamento:** Permite escolher remédio do estoque e aplicar diretamente ao paciente, deduzindo a quantidade do banco de dados MySQL e registrando em `historico_saidas`.
   - **Conclusão:** Ao concluir, o paciente sai da fila ativa e a ficha vai para o Histórico.
   - **Read:** Calendário de atendimentos com ordenação cronológica diária (do mais cedo no topo ao mais tarde no fim).

3. **Remédios e Farmácia:**
   - **Create:** Cadastra novo medicamento com dosagem, apresentação, lote, validade e estoque (sem princípio ativo).
   - **Read:** Busca e consulta com saldo de estoque em tempo real.
   - **Update / Dispensar:** Deduz unidades do estoque e grava histórico de saída com paciente e profissional.
   - **Delete:** Remove medicamento do banco de dados.

4. **Atendimento ao Paciente:**
   - Registro de procedimentos, aferição de sinais vitais (PA, FC, Temp, SatO2, Glicemia) e evolução do paciente.
