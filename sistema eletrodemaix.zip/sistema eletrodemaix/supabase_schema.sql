-- ====================================================================
-- BANCO DE DADOS SUPABASE (PostgreSQL) - LOJAS ELETRÔNICOS DEMAIS
-- Execute este script no "SQL Editor" do seu painel Supabase
-- ====================================================================

-- 1. TABELA DE FUNCIONÁRIOS
CREATE TABLE IF NOT EXISTS public.funcionarios (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    usuario TEXT NOT NULL UNIQUE,
    senha TEXT NOT NULL,
    nome TEXT NOT NULL,
    cargo TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'vendedor',
    matricula TEXT,
    email TEXT,
    telefone TEXT,
    criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 2. TABELA DE PRODUTOS / ELETRODOMÉSTICOS (Estoque)
CREATE TABLE IF NOT EXISTS public.produtos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE, -- Padrão: ELTDMS - XXXX
    nome TEXT NOT NULL,
    categoria TEXT NOT NULL,
    marca TEXT NOT NULL,
    modelo TEXT,
    voltagem TEXT NOT NULL DEFAULT '110V',
    cor TEXT DEFAULT 'Padrão',
    preco_custo NUMERIC(10,2) DEFAULT 0.00,
    preco_venda NUMERIC(10,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0,
    estoque_minimo INT NOT NULL DEFAULT 4,
    localizacao TEXT DEFAULT 'Depósito Principal',
    garantia_meses INT DEFAULT 12,
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 3. TABELA DE VENDAS
CREATE TABLE IF NOT EXISTS public.vendas (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    numero TEXT NOT NULL UNIQUE,
    data_hora TEXT NOT NULL,
    vendedor_id TEXT,
    vendedor_nome TEXT NOT NULL,
    cliente_nome TEXT NOT NULL,
    cliente_cpf TEXT,
    cliente_telefone TEXT,
    subtotal NUMERIC(10,2) NOT NULL,
    desconto NUMERIC(10,2) DEFAULT 0.00,
    total NUMERIC(10,2) NOT NULL,
    forma_pagamento TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'concluida',
    criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 4. TABELA DE ITENS DA VENDA
CREATE TABLE IF NOT EXISTS public.itens_venda (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    venda_id UUID REFERENCES public.vendas(id) ON DELETE CASCADE,
    produto_id UUID REFERENCES public.produtos(id) ON DELETE SET NULL,
    codigo TEXT NOT NULL,
    nome TEXT NOT NULL,
    marca TEXT,
    voltagem TEXT,
    quantidade INT NOT NULL,
    preco_unitario NUMERIC(10,2) NOT NULL,
    subtotal NUMERIC(10,2) NOT NULL
);

-- 5. TABELA DE PEDIDOS ONLINE
CREATE TABLE IF NOT EXISTS public.pedidos_online (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    numero TEXT NOT NULL UNIQUE,
    data_hora TEXT NOT NULL,
    cliente_nome TEXT NOT NULL,
    cliente_telefone TEXT,
    endereco TEXT NOT NULL,
    cidade TEXT NOT NULL,
    total NUMERIC(10,2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'Aguardando Separação',
    pagamento TEXT NOT NULL,
    criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- 6. TABELA DE ENVIOS (Logística)
CREATE TABLE IF NOT EXISTS public.envios (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    codigo_rastreio TEXT NOT NULL UNIQUE,
    pedido_numero TEXT NOT NULL,
    destinatario TEXT NOT NULL,
    endereco_entrega TEXT NOT NULL,
    cidade TEXT NOT NULL,
    transportadora TEXT NOT NULL,
    data_despacho TEXT,
    previsao_entrega TEXT,
    status TEXT NOT NULL DEFAULT 'Aguardando Coleta',
    criado_em TIMESTAMPTZ DEFAULT NOW()
);

-- ====================================================================
-- POLÍTICAS DE ACESSO (Row Level Security - RLS)
-- Permite leitura e escrita pelo frontend conectado com a chave anon
-- ====================================================================
ALTER TABLE public.funcionarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_venda ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pedidos_online ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.envios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Acesso publico funcionarios" ON public.funcionarios FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso publico produtos" ON public.produtos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso publico vendas" ON public.vendas FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso publico itens_venda" ON public.itens_venda FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso publico pedidos_online" ON public.pedidos_online FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso publico envios" ON public.envios FOR ALL USING (true) WITH CHECK (true);

-- ====================================================================
-- DADOS INICIAIS DE TESTE
-- ====================================================================

-- Usuário Principal Gustavo (senha: 2108)
INSERT INTO public.funcionarios (usuario, senha, nome, cargo, role, matricula, email)
VALUES ('Gustavo', '2108', 'Gustavo', 'Gerente da Loja', 'gerente', 'ELD-001', 'gustavo@eletronicosdemais.com.br')
ON CONFLICT (usuario) DO NOTHING;

-- Eletrodomésticos Iniciais no Padrão ELTDMS - XXXX
INSERT INTO public.produtos (codigo, nome, categoria, marca, modelo, voltagem, preco_custo, preco_venda, estoque, localizacao)
VALUES 
('ELTDMS - 1001', 'Geladeira Brastemp Frost Free Duplex 375L', 'Refrigeração', 'Brastemp', 'BRM44HK', '110V', 2150.00, 2899.90, 14, 'Corredor 1'),
('ELTDMS - 1002', 'Geladeira Brastemp Frost Free Duplex 375L', 'Refrigeração', 'Brastemp', 'BRM44HK-220', '220V', 2150.00, 2899.90, 8, 'Corredor 1'),
('ELTDMS - 1003', 'Geladeira Electrolux French Door 590L Inox', 'Refrigeração', 'Electrolux', 'DM84X', '220V', 4600.00, 6199.00, 4, 'Corredor 2'),
('ELTDMS - 1004', 'Máquina de Lavar Electrolux 14kg Essential Care', 'Lavanderia', 'Electrolux', 'LED14', '110V', 1450.00, 1999.00, 12, 'Corredor 1'),
('ELTDMS - 1005', 'Lava e Seca Samsung EcoBubble 11kg / 7kg', 'Lavanderia', 'Samsung', 'WD11M', '110V', 2800.00, 3799.00, 6, 'Corredor 2'),
('ELTDMS - 1006', 'Fogão Brastemp 4 Bocas com Timer Digital', 'Cocção', 'Brastemp', 'BFO4NAB', 'Bivolt', 950.00, 1349.00, 18, 'Corredor 1'),
('ELTDMS - 1007', 'Cooktop Consul 5 Bocas Vidro Temperado', 'Cocção', 'Consul', 'CD075AE', 'Bivolt', 380.00, 589.90, 22, 'Corredor 2'),
('ELTDMS - 1008', 'Micro-ondas Consul 32L com Função Descongelar', 'Cocção', 'Consul', 'CMS46AR', '110V', 520.00, 749.90, 16, 'Corredor 3'),
('ELTDMS - 1009', 'Fritadeira Elétrica Air Fryer Mondial 4L Inox', 'Eletroportáteis', 'Mondial', 'AFN-40-BI', '110V', 210.00, 349.90, 35, 'Prateleira 1'),
('ELTDMS - 1010', 'Ar Condicionado Split LG Dual Inverter Voice 12.000 BTUs', 'Climatização', 'LG', 'S4-Q12JA31F', '220V', 1980.00, 2699.00, 9, 'Corredor 1')
ON CONFLICT (codigo) DO NOTHING;
