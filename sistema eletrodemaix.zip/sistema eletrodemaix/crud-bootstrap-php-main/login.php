<?php
include_once 'config.php';
include_once DBAPI;

// Troca rápida de perfil por parâmetro GET
if (isset($_GET['switch'])) {
    $switch = $_GET['switch'];
    if ($switch === 'medico') {
        $_SESSION['user'] = [
            'id'          => 1,
            'nome'        => 'Dr. Carlos Roberto',
            'email'       => 'carlos.medico@hospital.com',
            'role'        => ROLE_MEDICO,
            'registro'    => 'CRM/SP 45210',
            'paciente_id' => null
        ];
        $_SESSION['message'] = 'Sessão iniciada como Médico (Dr. Carlos Roberto).';
        $_SESSION['type'] = 'success';
    } elseif ($switch === 'enfermeiro') {
        $_SESSION['user'] = [
            'id'          => 2,
            'nome'        => 'Enfª Mariana Souza',
            'email'       => 'mariana.enfermeira@hospital.com',
            'role'        => ROLE_ENFERMEIRO,
            'registro'    => 'COREN/SP 184592',
            'paciente_id' => null
        ];
        $_SESSION['message'] = 'Sessão iniciada como Enfermeira (Enfª Mariana Souza).';
        $_SESSION['type'] = 'success';
    } elseif ($switch === 'cliente') {
        $_SESSION['user'] = [
            'id'          => 3,
            'nome'        => 'Ana Clara Lima',
            'email'       => 'anaclara.cliente@email.com',
            'role'        => ROLE_CLIENTE,
            'registro'    => 'CPF: 123.456.789-00',
            'paciente_id' => 1
        ];
        $_SESSION['message'] = 'Sessão iniciada como Cliente / Paciente (Ana Clara Lima).';
        $_SESSION['type'] = 'success';
    }
    header('Location: ' . BASEURL . 'index.php');
    exit;
}

// Processa formulário de login tradicional
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $perfil = $_POST['perfil'] ?? 'medico';
    
    if ($perfil === 'medico') {
        $_SESSION['user'] = [
            'id'          => 1,
            'nome'        => 'Dr. Carlos Roberto',
            'email'       => 'carlos.medico@hospital.com',
            'role'        => ROLE_MEDICO,
            'registro'    => 'CRM/SP 45210',
            'paciente_id' => null
        ];
    } elseif ($perfil === 'enfermeiro') {
        $_SESSION['user'] = [
            'id'          => 2,
            'nome'        => 'Enfª Mariana Souza',
            'email'       => 'mariana.enfermeira@hospital.com',
            'role'        => ROLE_ENFERMEIRO,
            'registro'    => 'COREN/SP 184592',
            'paciente_id' => null
        ];
    } else {
        $_SESSION['user'] = [
            'id'          => 3,
            'nome'        => 'Ana Clara Lima',
            'email'       => 'anaclara.cliente@email.com',
            'role'        => ROLE_CLIENTE,
            'registro'    => 'CPF: 123.456.789-00',
            'paciente_id' => 1
        ];
    }
    $_SESSION['message'] = 'Bem-vindo ao MedControl!';
    $_SESSION['type'] = 'success';
    header('Location: ' . BASEURL . 'index.php');
    exit;
}

include_once HEADER_TEMPLATE;
?>

<div class="row justify-content-center my-5">
    <div class="col-md-8 col-lg-6">
        <div class="card card-custom p-4 shadow-sm border-0 bg-white">
            <div class="text-center mb-4">
                <i class="fa-solid fa-hospital-user text-primary fa-3x mb-2"></i>
                <h3 class="fw-bold">Acesso ao MedControl</h3>
                <p class="text-muted">Selecione o perfil de usuário para autenticar:</p>
            </div>

            <form method="POST" action="login.php">
                <div class="list-group mb-4">
                    <label class="list-group-item list-group-item-action d-flex align-items-center gap-3 p-3">
                        <input class="form-check-input flex-shrink-0" type="radio" name="perfil" value="medico" checked>
                        <div class="flex-grow-1">
                            <h6 class="mb-0 fw-bold text-primary"><i class="fa-solid fa-user-doctor me-1"></i> Médico (Dr. Carlos Roberto)</h6>
                            <small class="text-muted">Permissão para emitir receitas médicas e diagnósticos clínicos.</small>
                        </div>
                    </label>

                    <label class="list-group-item list-group-item-action d-flex align-items-center gap-3 p-3">
                        <input class="form-check-input flex-shrink-0" type="radio" name="perfil" value="enfermeiro">
                        <div class="flex-grow-1">
                            <h6 class="mb-0 fw-bold text-success"><i class="fa-solid fa-user-nurse me-1"></i> Enfermeiro (Enfª Mariana Souza)</h6>
                            <small class="text-muted">Acesso a controle de remédios, escala de trabalho e pacientes.</small>
                        </div>
                    </label>

                    <label class="list-group-item list-group-item-action d-flex align-items-center gap-3 p-3">
                        <input class="form-check-input flex-shrink-0" type="radio" name="perfil" value="cliente">
                        <div class="flex-grow-1">
                            <h6 class="mb-0 fw-bold text-info"><i class="fa-solid fa-hospital-user me-1"></i> Cliente / Paciente (Ana Clara Lima)</h6>
                            <small class="text-muted">Visualização exclusiva do histórico e agendamentos personalizados.</small>
                        </div>
                    </label>
                </div>

                <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                    <i class="fa-solid fa-right-to-bracket me-2"></i> Entrar no Sistema
                </button>
            </form>
        </div>
    </div>
</div>

<?php include_once FOOTER_TEMPLATE; ?>
