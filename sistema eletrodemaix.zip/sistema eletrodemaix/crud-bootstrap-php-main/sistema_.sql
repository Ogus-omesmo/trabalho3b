-- ==============================================================
-- MedControl - Sistema Médico Hospitalar
-- Script de Criação do Banco de Dados e Carga Inicial de Dados
-- Suporta Perfis: Médico, Enfermeiro e Cliente/Paciente
-- ==============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `sistema_medico` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sistema_medico`;

-- --------------------------------------------------------
-- 1. Tabela de Usuários do Sistema
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL UNIQUE,
  `senha` varchar(255) NOT NULL,
  `role` enum('medico','enfermeiro','cliente') NOT NULL,
  `registro` varchar(50) DEFAULT NULL COMMENT 'CRM ou COREN ou CPF',
  `paciente_id` int(11) DEFAULT NULL COMMENT 'Vinculado se role for cliente',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `role`, `registro`, `paciente_id`, `created`, `modified`) VALUES
(1, 'Dr. Carlos Roberto', 'carlos.medico@hospital.com', '123456', 'medico', 'CRM/SP 45210', NULL, NOW(), NOW()),
(2, 'Enfª Mariana Souza', 'mariana.enfermeira@hospital.com', '123456', 'enfermeiro', 'COREN/SP 184592', NULL, NOW(), NOW()),
(3, 'Ana Clara Lima', 'anaclara.cliente@email.com', '123456', 'cliente', '123.456.789-00', 1, NOW(), NOW());

-- --------------------------------------------------------
-- 2. Tabela de Pacientes
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pacientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `data_nascimento` date NOT NULL,
  `telefone` varchar(30) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `convenio` varchar(100) DEFAULT 'Particular',
  `tipo_sanguineo` varchar(5) DEFAULT NULL,
  `alergias` text DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pacientes` (`id`, `nome`, `cpf`, `data_nascimento`, `telefone`, `email`, `convenio`, `tipo_sanguineo`, `alergias`, `endereco`, `cidade`, `created`, `modified`) VALUES
(1, 'Ana Clara Lima', '123.456.789-00', '1994-05-18', '(11) 98765-4321', 'anaclara.cliente@email.com', 'Unimed Nacional', 'O+', 'Dipirona e Frutos do Mar', 'Av. das Flores, 450 - Apto 32', 'São Paulo / SP', NOW(), NOW()),
(2, 'Roberto Silveira Rocha', '234.567.890-11', '1982-11-03', '(11) 97654-3210', 'roberto.silveira@email.com', 'Bradesco Saúde', 'A+', 'Penicilina', 'Rua dos Pinheiros, 120', 'São Paulo / SP', NOW(), NOW()),
(3, 'Juliana Castro Freitas', '345.678.901-22', '2001-08-25', '(11) 96543-2109', 'juliana.castro@email.com', 'SulAmérica', 'B-', 'Nenhuma alergia conhecida', 'Rua Bela Cintra, 890', 'São Paulo / SP', NOW(), NOW());

-- --------------------------------------------------------
-- 3. Tabela de Medicamentos / Remédios (Farmácia Hospitalar)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `medicamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `nome` varchar(255) NOT NULL,
  `principio_ativo` varchar(255) DEFAULT NULL,
  `apresentacao` varchar(100) NOT NULL COMMENT 'ex: Comprimido 500mg, Ampola 2ml',
  `laboratorio` varchar(100) DEFAULT NULL,
  `lote` varchar(50) NOT NULL,
  `quantidade` int(11) NOT NULL DEFAULT 0,
  `estoque_minimo` int(11) NOT NULL DEFAULT 15,
  `validade` date NOT NULL,
  `via` varchar(50) DEFAULT 'Oral',
  `indicacao` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `medicamentos` (`id`, `nome`, `principio_ativo`, `apresentacao`, `laboratorio`, `lote`, `quantidade`, `estoque_minimo`, `validade`, `via`, `indicacao`, `created`, `modified`) VALUES
(1, 'Amoxicilina + Clavulanato 875mg', 'Amoxicilina tri-hidratada', 'Comprimido revestido', 'EMS Pharma', 'LOTE-AMX-2026', 120, 20, '2027-08-30', 'Oral', 'Antibiótico para infecções bacterianas do trato respiratório e urinário.', NOW(), NOW()),
(2, 'Dipirona Sódica 500mg/ml', 'Dipirona monoidratada', 'Ampola injetável 2ml', 'Farmace', 'LOTE-DIP-998', 8, 25, '2027-03-15', 'Intravenosa', 'Analgésico e antitérmico para dor e febre aguda. ATENÇÃO: Estoque crítico!', NOW(), NOW()),
(3, 'Losartana Potássica 50mg', 'Losartana potássica', 'Comprimido 50mg', 'Medley', 'LOTE-LOS-450', 250, 30, '2028-01-20', 'Oral', 'Anti-hipertensivo indicado para controle da pressão arterial.', NOW(), NOW()),
(4, 'Omeprazol 20mg', 'Omeprazol sódico', 'Cápsula gelatinosa dura', 'Eurofarma', 'LOTE-OMP-112', 85, 20, '2027-10-10', 'Oral', 'Inibidor de bomba de prótons para gastrite e refluxo gastroesofágico.', NOW(), NOW());

-- --------------------------------------------------------
-- 4. Tabela de Escalas de Trabalho (Plantões e Turnos)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `escalas` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `profissional_nome` varchar(255) NOT NULL,
  `registro_profissional` varchar(50) DEFAULT NULL,
  `cargo` varchar(100) NOT NULL,
  `setor` varchar(100) NOT NULL,
  `turno` varchar(100) NOT NULL,
  `data_plantao` date NOT NULL,
  `observacoes` text DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `escalas` (`id`, `profissional_nome`, `registro_profissional`, `cargo`, `setor`, `turno`, `data_plantao`, `observacoes`, `created`, `modified`) VALUES
(1, 'Enfª Mariana Souza', 'COREN/SP 184592', 'Enfermeiro(a) Chefe', 'UTI Geral Adulto', 'Plantão 12x36 Diurno', CURDATE(), 'Responsável técnica pelo setor de terapia intensiva durante o dia.', NOW(), NOW()),
(2, 'Tec. Marcos Vinicius', 'COREN/SP 549811', 'Técnico(a) de Enfermagem', 'Pronto Socorro / Triagem', 'Manhã (07:00 às 13:00)', CURDATE(), 'Aferição de sinais vitais e acolhimento Manchester.', NOW(), NOW()),
(3, 'Dr. Carlos Roberto', 'CRM/SP 45210', 'Médico(a) Plantonista', 'Emergência Clínica', 'Tarde (13:00 às 19:00)', CURDATE(), 'Atendimento ambulatorial e intercorrências de enfermaria.', NOW(), NOW());

-- --------------------------------------------------------
-- 5. Tabela de Diagnósticos Clínicos (Exclusivo Médico)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `diagnosticos` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `paciente_id` int(11) NOT NULL,
  `paciente_nome` varchar(255) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `medico_nome` varchar(255) NOT NULL,
  `medico_crm` varchar(50) NOT NULL,
  `cid10` varchar(20) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `prioridade` varchar(50) DEFAULT 'Moderada',
  `anamnese` text NOT NULL,
  `exame_fisico` text DEFAULT NULL,
  `conduta` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `diagnosticos` (`id`, `paciente_id`, `paciente_nome`, `medico_id`, `medico_nome`, `medico_crm`, `cid10`, `titulo`, `prioridade`, `anamnese`, `exame_fisico`, `conduta`, `created`) VALUES
(1, 1, 'Ana Clara Lima', 1, 'Dr. Carlos Roberto', 'CRM/SP 45210', 'J06.9', 'Faringoamigdalite bacteriana aguda', 'Moderada', 'Paciente refere dor de garganta intensa há 3 dias com odinofagia, febre aferida em 38.4°C e mal-estar geral. Nega tosse.', 'Oroscopia com amígdalas hipertrofiadas e exsudato purulento bilateral. Ausculta pulmonar sem alterações.', 'Prescrito antibiótico Amoxicilina por 7 dias, antitérmico para dor e febre, repouso e hidratação oral.', NOW() - INTERVAL 5 DAY),
(2, 1, 'Ana Clara Lima', 1, 'Dr. Carlos Roberto', 'CRM/SP 45210', 'R51', 'Cefaleia tensional episódica', 'Baixa', 'Queixa de cefaleia em aperto bilateral, holocraniana, pior no final da tarde. Relacionada a estresse ocupacional.', 'Pressão arterial 118x78 mmHg, sem déficits neurológicos focais.', 'Orientação de ergonomia, higiene do sono e analgésico de resgate se necessário.', NOW() - INTERVAL 25 DAY);

-- --------------------------------------------------------
-- 6. Tabela de Receitas Médicas (Exclusivo Médico)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `receitas` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `paciente_id` int(11) NOT NULL,
  `paciente_nome` varchar(255) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `medico_nome` varchar(255) NOT NULL,
  `medico_crm` varchar(50) NOT NULL,
  `medicamentos` varchar(255) NOT NULL,
  `via` varchar(50) DEFAULT 'Uso Oral',
  `tipo` varchar(100) DEFAULT 'Receituário Simples',
  `posologia` text NOT NULL,
  `orientacoes` text DEFAULT NULL,
  `validade` date NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `receitas` (`id`, `paciente_id`, `paciente_nome`, `medico_id`, `medico_nome`, `medico_crm`, `medicamentos`, `via`, `tipo`, `posologia`, `orientacoes`, `validade`, `created`) VALUES
(1, 1, 'Ana Clara Lima', 1, 'Dr. Carlos Roberto', 'CRM/SP 45210', 'Amoxicilina + Clavulanato 875mg', 'Uso Oral', 'Antimicrobiano (Retenção de via)', '1) Tomar 1 comprimido por via oral a cada 12 horas por 7 dias ininterruptos.\n2) Paracetamol 750mg: Tomar 1 comprimido a cada 6 horas se dor ou febre.', 'Ingerir com bastante água após refeições. Não ingerir bebidas alcoólicas durante o uso.', DATE_ADD(CURDATE(), INTERVAL 25 DAY), NOW());

-- --------------------------------------------------------
-- 7. Tabela de Agendamentos (Consultas Marcadas)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `agendamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `paciente_id` int(11) NOT NULL,
  `paciente_nome` varchar(255) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `medico_nome` varchar(255) NOT NULL,
  `especialidade` varchar(100) NOT NULL,
  `data_consulta` date NOT NULL,
  `hora_consulta` varchar(10) NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Agendado',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `agendamentos` (`id`, `paciente_id`, `paciente_nome`, `medico_id`, `medico_nome`, `especialidade`, `data_consulta`, `hora_consulta`, `motivo`, `status`, `created`, `modified`) VALUES
(1, 1, 'Ana Clara Lima', 1, 'Dr. Carlos Roberto (CRM/SP 45210)', 'Clínica Geral', DATE_ADD(CURDATE(), INTERVAL 3 DAY), '14:00', 'Consulta de retorno e avaliação da faringite', 'Agendado', NOW(), NOW()),
(2, 1, 'Ana Clara Lima', 1, 'Dr. Carlos Roberto (CRM/SP 45210)', 'Clínica Geral', DATE_SUB(CURDATE(), INTERVAL 5 DAY), '10:00', 'Quadro febril e dor de garganta aguda', 'Realizado', NOW(), NOW()),
(3, 2, 'Roberto Silveira Rocha', 1, 'Dr. Carlos Roberto (CRM/SP 45210)', 'Cardiologia', DATE_ADD(CURDATE(), INTERVAL 1 DAY), '09:00', 'Acompanhamento de hipertensão arterial', 'Agendado', NOW(), NOW());

-- --------------------------------------------------------
-- 8. Tabela de Triagens e Sinais Vitais (Enfermagem)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `triagens` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `paciente_id` int(11) NOT NULL,
  `enfermeiro_id` int(11) NOT NULL,
  `enfermeiro_nome` varchar(255) NOT NULL,
  `pressao` varchar(20) NOT NULL,
  `temperatura` varchar(10) NOT NULL,
  `saturacao` varchar(10) NOT NULL,
  `fc` varchar(10) NOT NULL,
  `classificacao_nome` varchar(50) NOT NULL,
  `classificacao_cor` varchar(20) NOT NULL,
  `queixa` text DEFAULT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `triagens` (`id`, `paciente_id`, `enfermeiro_id`, `enfermeiro_nome`, `pressao`, `temperatura`, `saturacao`, `fc`, `classificacao_nome`, `classificacao_cor`, `queixa`, `created`) VALUES
(1, 1, 2, 'Enfª Mariana Souza', '120/80', '38.4', '98', '84', 'Pouco Urgente (Verde)', 'success', 'Dor de garganta moderada e febre há 3 dias', NOW() - INTERVAL 5 DAY);
