<?php
require_once('../config.php');
require_once(DBAPI);

$user = current_user();
if (!$user || $user['role'] !== ROLE_CLIENTE) {
    // Se não for cliente, redireciona para login de cliente
    header('Location: ' . BASEURL . 'login.php?switch=cliente');
    exit;
}

$paciente_id = intval($user['paciente_id'] ?? 1);
$paciente     = find('pacientes', $paciente_id);
$diagnosticos = find_where('diagnosticos', "paciente_id = {$paciente_id}", "id DESC");
$receitas     = find_where('receitas', "paciente_id = {$paciente_id}", "id DESC");
$agendamentos = find_where('agendamentos', "paciente_id = {$paciente_id}", "data_consulta DESC");

include(HEADER_TEMPLATE);
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0">
            <i class="fa-solid fa-clock-rotate-left text-info me-2"></i>Meu Histórico Médico Personalizado
        </h2>
        <small class="text-muted">Área Exclusiva do Paciente: Laudos, Prescrições e Consultas</small>
    </div>
    <div class="d-flex gap-2 mt-2 mt-md-0">
        <a href="../agendamentos/add.php" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-calendar-plus me-1"></i> Nova Consulta
        </a>
        <a href="../index.php" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-arrow-left me-1"></i> Voltar ao Início
        </a>
    </div>
</div>

<hr>

<!-- Cartão Informativo do Paciente -->
<div class="card border-0 shadow-sm rounded-3 p-4 bg-white mb-4">
    <div class="row align-items-center g-3">
        <div class="col-md-2 text-center">
            <div class="d-inline-flex align-items-center justify-content-center bg-info-subtle text-info rounded-circle" style="width: 80px; height: 80px;">
                <i class="fa-solid fa-user-check fa-3x"></i>
            </div>
        </div>
        <div class="col-md-6">
            <h4 class="fw-bold mb-1"><?= htmlspecialchars($user['nome']) ?></h4>
            <div class="text-muted small mb-2">
                <span>CPF: <?= htmlspecialchars($user['registro'] ?? '123.456.789-00') ?></span> &bull;
                <span>Convênio: <strong class="text-info"><?= htmlspecialchars($paciente['convenio'] ?? 'Unimed Saúde') ?></strong></span>
            </div>
            <div class="d-flex gap-2">
                <span class="badge bg-danger"><i class="fa-solid fa-droplet me-1"></i> Tipo Sang.: <?= htmlspecialchars($paciente['tipo_sanguineo'] ?? 'O+') ?></span>
                <span class="badge bg-secondary-subtle text-secondary border">Cadastro Ativo</span>
            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 bg-danger-subtle text-danger-emphasis rounded">
                <small class="fw-bold d-block mb-1 text-uppercase"><i class="fa-solid fa-triangle-exclamation me-1"></i>Alergias Registradas:</small>
                <span><?= !empty($paciente['alergias']) ? htmlspecialchars($paciente['alergias']) : 'Nenhuma alergia conhecida.' ?></span>
            </div>
        </div>
    </div>
</div>

<!-- Abas do Portal do Paciente -->
<div class="card border-0 shadow-sm rounded-3">
    <div class="card-header bg-white border-bottom p-0">
        <ul class="nav nav-tabs card-header-tabs m-0 px-3" id="historicoClienteTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active py-3" data-bs-toggle="tab" data-bs-target="#tabMeusDiagnosticos">
                    <i class="fa-solid fa-file-medical text-primary me-2"></i>Meus Diagnósticos (<?= count($diagnosticos) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabMinhasReceitas">
                    <i class="fa-solid fa-receipt text-success me-2"></i>Minhas Receitas Médicas (<?= count($receitas) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabMeusAgendamentos">
                    <i class="fa-solid fa-calendar-alt text-info me-2"></i>Meus Agendamentos (<?= count($agendamentos) ?>)
                </button>
            </li>
        </ul>
    </div>

    <div class="card-body p-4">
        <div class="tab-content" id="historicoTabsContent">
            
            <!-- ABA 1: MEUS DIAGNÓSTICOS -->
            <div class="tab-pane fade show active" id="tabMeusDiagnosticos">
                <?php if (!empty($diagnosticos)): ?>
                    <div class="row g-3">
                        <?php foreach ($diagnosticos as $d): ?>
                            <div class="col-md-6">
                                <div class="card h-100 border p-3 rounded-3 shadow-none">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="badge bg-primary"><?= htmlspecialchars($d['cid10']) ?></span>
                                        <small class="text-muted"><?= date('d/m/Y H:i', strtotime($d['created'])) ?></small>
                                    </div>
                                    <h5 class="fw-bold mb-1 text-dark"><?= htmlspecialchars($d['titulo']) ?></h5>
                                    <small class="text-muted mb-2 d-block">
                                        <i class="fa-solid fa-user-doctor me-1 text-primary"></i> <?= htmlspecialchars($d['medico_nome'] ?? 'Dr. Carlos Roberto') ?>
                                    </small>
                                    
                                    <div class="p-2 bg-light rounded small mb-3">
                                        <strong>Conduta &amp; Tratamento:</strong><br>
                                        <?= nl2br(htmlspecialchars($d['conduta'])) ?>
                                    </div>

                                    <div class="mt-auto text-end">
                                        <a href="../diagnosticos/view.php?id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fa-solid fa-eye me-1"></i> Ver Laudo Completo
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fa-solid fa-file-circle-check fa-3x mb-2 text-secondary"></i>
                        <p class="mb-0">Você não possui nenhum diagnóstico registrado até o momento.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ABA 2: MINHAS RECEITAS MÉDICAS -->
            <div class="tab-pane fade" id="tabMinhasReceitas">
                <?php if (!empty($receitas)): ?>
                    <div class="row g-3">
                        <?php foreach ($receitas as $r): ?>
                            <div class="col-md-6">
                                <div class="card h-100 border p-3 rounded-3 shadow-none">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">
                                            Válida até <?= date('d/m/Y', strtotime($r['validade'])) ?>
                                        </span>
                                        <small class="text-muted">Emitida em: <?= date('d/m/Y', strtotime($r['created'])) ?></small>
                                    </div>
                                    <h5 class="fw-bold mb-1 text-dark"><?= htmlspecialchars($r['medicamentos']) ?></h5>
                                    <small class="text-muted mb-3 d-block">
                                        <i class="fa-solid fa-user-doctor me-1 text-info"></i> <?= htmlspecialchars($r['medico_nome'] ?? 'Dr. Carlos Roberto') ?> (<?= htmlspecialchars($r['medico_crm'] ?? 'CRM/SP 45210') ?>)
                                    </small>

                                    <div class="p-2 bg-light rounded font-monospace small mb-3">
                                        <strong>Posologia:</strong><br>
                                        <?= nl2br(htmlspecialchars($r['posologia'])) ?>
                                    </div>

                                    <div class="mt-auto d-flex justify-content-between align-items-center">
                                        <span class="badge bg-secondary"><?= htmlspecialchars($r['via'] ?? 'Oral') ?></span>
                                        <div class="d-flex gap-2">
                                            <a href="../receitas/view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fa-solid fa-eye me-1"></i> Detalhes
                                            </a>
                                            <a href="../receitas/imprimir.php?id=<?= $r['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                                <i class="fa-solid fa-print me-1"></i> Imprimir
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fa-solid fa-receipt fa-3x mb-2 text-secondary"></i>
                        <p class="mb-0">Você não possui receitas médicas ativas no momento.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ABA 3: MEUS AGENDAMENTOS -->
            <div class="tab-pane fade" id="tabMeusAgendamentos">
                <?php if (!empty($agendamentos)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Data &amp; Horário</th>
                                    <th>Especialidade</th>
                                    <th>Médico Responsável</th>
                                    <th>Motivo da Consulta</th>
                                    <th>Status</th>
                                    <th class="text-end">Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($agendamentos as $ag): ?>
                                    <tr>
                                        <td>
                                            <strong><?= date('d/m/Y', strtotime($ag['data_consulta'])) ?></strong> às <?= htmlspecialchars($ag['hora_consulta']) ?>
                                        </td>
                                        <td><span class="badge bg-info-subtle text-info border"><?= htmlspecialchars($ag['especialidade'] ?? 'Clínica Geral') ?></span></td>
                                        <td><?= htmlspecialchars($ag['medico_nome'] ?? 'Dr. Carlos Roberto') ?></td>
                                        <td><?= htmlspecialchars($ag['motivo'] ?? 'Consulta de rotina') ?></td>
                                        <td>
                                            <span class="badge bg-<?= ($ag['status'] === 'Agendado' ? 'primary' : ($ag['status'] === 'Realizado' ? 'success' : 'danger')) ?>">
                                                <?= htmlspecialchars($ag['status']) ?>
                                            </span>
                                        </td>
                                        <td class="text-end">
                                            <?php if ($ag['status'] === 'Agendado'): ?>
                                                <a href="../agendamentos/cancelar.php?id=<?= $ag['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deseja cancelar esta consulta?');">
                                                    Cancelar
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted small">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fa-solid fa-calendar-xmark fa-3x mb-2 text-secondary"></i>
                        <p class="mb-3">Você não possui consultas agendadas no momento.</p>
                        <a href="../agendamentos/add.php" class="btn btn-primary btn-sm">
                            <i class="fa-solid fa-calendar-plus me-1"></i> Agendar Agora
                        </a>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
