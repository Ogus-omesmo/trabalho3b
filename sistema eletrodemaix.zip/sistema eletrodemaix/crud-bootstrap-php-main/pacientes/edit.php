<?php 
require_once('function.php'); 
check_permission([ROLE_MEDICO, ROLE_ENFERMEIRO]);
edit();
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-user-pen text-primary me-2"></i>Editar Paciente #<?= $paciente['id'] ?? '' ?></h2>
        <small class="text-muted">Atualização de dados cadastrais do paciente</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<?php if (!empty($paciente)): ?>
<form action="edit.php?id=<?= $paciente['id']; ?>" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label fw-semibold">Nome Completo *</label>
            <input type="text" class="form-control" name="paciente['nome']" value="<?= htmlspecialchars($paciente['nome']) ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">CPF *</label>
            <input type="text" class="form-control" name="paciente['cpf']" value="<?= htmlspecialchars($paciente['cpf']) ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Data de Nascimento *</label>
            <input type="date" class="form-control" name="paciente['data_nascimento']" value="<?= htmlspecialchars($paciente['data_nascimento']) ?>" required>
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Telefone / WhatsApp</label>
            <input type="text" class="form-control" name="paciente['telefone']" value="<?= htmlspecialchars($paciente['telefone']) ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">E-mail</label>
            <input type="email" class="form-control" name="paciente['email']" value="<?= htmlspecialchars($paciente['email']) ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Convênio / Plano de Saúde</label>
            <input type="text" class="form-control" name="paciente['convenio']" value="<?= htmlspecialchars($paciente['convenio'] ?? '') ?>">
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold">Tipo Sanguíneo</label>
            <select class="form-select" name="paciente['tipo_sanguineo']">
                <option value="">Não informado</option>
                <?php foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $ts): ?>
                    <option value="<?= $ts ?>" <?= ($paciente['tipo_sanguineo'] ?? '') === $ts ? 'selected' : '' ?>><?= $ts ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-9">
            <label class="form-label fw-semibold text-danger"><i class="fa-solid fa-triangle-exclamation me-1"></i>Alergias Conhecidas</label>
            <input type="text" class="form-control" name="paciente['alergias']" value="<?= htmlspecialchars($paciente['alergias'] ?? '') ?>">
        </div>

        <div class="col-md-8">
            <label class="form-label fw-semibold">Endereço Residencial</label>
            <input type="text" class="form-control" name="paciente['endereco']" value="<?= htmlspecialchars($paciente['endereco']) ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Cidade / UF</label>
            <input type="text" class="form-control" name="paciente['cidade']" value="<?= htmlspecialchars($paciente['cidade']) ?>">
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save me-1"></i> Salvar Alterações</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>
<?php else: ?>
    <div class="alert alert-warning">Paciente não encontrado.</div>
<?php endif; ?>

<?php include(FOOTER_TEMPLATE); ?>
