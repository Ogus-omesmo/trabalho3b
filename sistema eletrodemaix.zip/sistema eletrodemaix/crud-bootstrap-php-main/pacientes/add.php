<?php 
require_once('function.php'); 
check_permission([ROLE_MEDICO, ROLE_ENFERMEIRO]);
add();
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-user-plus text-primary me-2"></i>Novo Paciente</h2>
        <small class="text-muted">Cadastro inicial e prontuário médico</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<form action="add.php" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label fw-semibold">Nome Completo *</label>
            <input type="text" class="form-control" name="paciente['nome']" required placeholder="Ex: Maria dos Santos">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">CPF *</label>
            <input type="text" class="form-control" name="paciente['cpf']" required placeholder="000.000.000-00">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Data de Nascimento *</label>
            <input type="date" class="form-control" name="paciente['data_nascimento']" required>
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Telefone / WhatsApp</label>
            <input type="text" class="form-control" name="paciente['telefone']" placeholder="(00) 00000-0000">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">E-mail</label>
            <input type="email" class="form-control" name="paciente['email']" placeholder="paciente@exemplo.com">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Convênio / Plano de Saúde</label>
            <input type="text" class="form-control" name="paciente['convenio']" placeholder="Ex: Unimed, Bradesco Saúde, Particular">
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold">Tipo Sanguíneo</label>
            <select class="form-select" name="paciente['tipo_sanguineo']">
                <option value="">Não informado</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
            </select>
        </div>
        <div class="col-md-9">
            <label class="form-label fw-semibold text-danger"><i class="fa-solid fa-triangle-exclamation me-1"></i>Alergias Conhecidas</label>
            <input type="text" class="form-control" name="paciente['alergias']" placeholder="Ex: Penicilina, Dipirona, Frutos do mar, Nenhuma">
        </div>

        <div class="col-md-8">
            <label class="form-label fw-semibold">Endereço Residencial</label>
            <input type="text" class="form-control" name="paciente['endereco']" placeholder="Rua, número, complemento">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Cidade / UF</label>
            <input type="text" class="form-control" name="paciente['cidade']" placeholder="Ex: São Paulo / SP">
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save me-1"></i> Salvar Paciente</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
