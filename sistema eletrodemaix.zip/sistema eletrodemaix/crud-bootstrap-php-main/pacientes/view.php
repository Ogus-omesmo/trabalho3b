<?php 
require_once('function.php'); 
check_permission([ROLE_MEDICO, ROLE_ENFERMEIRO]);
view($_GET['id'] ?? null);

$diagnosticos = find_where('diagnosticos', 'paciente_id = ' . intval($paciente['id'] ?? 0));
$receitas     = find_where('receitas', 'paciente_id = ' . intval($paciente['id'] ?? 0));
$triagens     = find_where('triagens', 'paciente_id = ' . intval($paciente['id'] ?? 0));

include(HEADER_TEMPLATE); 
$user = current_user();
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0">
            <i class="fa-solid fa-id-card text-primary me-2"></i>Prontuário Médico: <?= htmlspecialchars($paciente['nome'] ?? 'Paciente') ?>
        </h2>
        <small class="text-muted">Ficha clínica integrada e histórico médico do paciente</small>
    </div>
    <div class="d-flex gap-2 mt-2 mt-md-0">
        <?php if ($user['role'] === ROLE_MEDICO): ?>
            <a href="../diagnosticos/add.php?paciente_id=<?= $paciente['id'] ?>" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-stethoscope me-1"></i> Emitir Diagnóstico
            </a>
            <a href="../receitas/add.php?paciente_id=<?= $paciente['id'] ?>" class="btn btn-info text-white btn-sm">
                <i class="fa-solid fa-receipt me-1"></i> Emitir Receita
            </a>
        <?php endif; ?>
        <a href="edit.php?id=<?= $paciente['id'] ?>" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-pen me-1"></i> Editar</a>
        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<!-- Informações Cadastrais do Paciente -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card p-3 shadow-sm border-0 bg-white h-100">
            <h6 class="text-muted text-uppercase small fw-bold mb-3"><i class="fa-solid fa-user me-1 text-primary"></i> Identificação</h6>
            <p class="mb-1"><strong>CPF:</strong> <?= htmlspecialchars($paciente['cpf'] ?? '-') ?></p>
            <p class="mb-1"><strong>Data Nasc:</strong> <?= !empty($paciente['data_nascimento']) ? date('d/m/Y', strtotime($paciente['data_nascimento'])) : '-' ?></p>
            <p class="mb-1"><strong>Tipo Sanguíneo:</strong> <span class="badge bg-danger"><?= htmlspecialchars($paciente['tipo_sanguineo'] ?? 'N/I') ?></span></p>
            <p class="mb-0"><strong>Convênio:</strong> <span class="badge bg-info text-dark"><?= htmlspecialchars($paciente['convenio'] ?? 'Particular') ?></span></p>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-3 shadow-sm border-0 bg-white h-100">
            <h6 class="text-muted text-uppercase small fw-bold mb-3"><i class="fa-solid fa-address-book me-1 text-primary"></i> Contato &amp; Local</h6>
            <p class="mb-1"><strong>Telefone:</strong> <?= htmlspecialchars($paciente['telefone'] ?? '-') ?></p>
            <p class="mb-1"><strong>E-mail:</strong> <?= htmlspecialchars($paciente['email'] ?? '-') ?></p>
            <p class="mb-0"><strong>Endereço:</strong> <?= htmlspecialchars($paciente['endereco'] ?? '-') ?> - <?= htmlspecialchars($paciente['cidade'] ?? '') ?></p>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-3 shadow-sm border-0 bg-white h-100 border-start border-danger border-4">
            <h6 class="text-danger text-uppercase small fw-bold mb-2"><i class="fa-solid fa-triangle-exclamation me-1"></i> Alertas Clínicos &amp; Alergias</h6>
            <div class="p-2 bg-danger-subtle text-danger-emphasis rounded mb-2">
                <strong>Alergias relatadas:</strong><br>
                <?= !empty($paciente['alergias']) ? htmlspecialchars($paciente['alergias']) : 'Nenhuma alergia conhecida relatada pelo paciente.' ?>
            </div>
            <small class="text-muted">Cadastrado em: <?= date('d/m/Y', strtotime($paciente['created'] ?? 'now')) ?></small>
        </div>
    </div>
</div>

<!-- Abas de Prontuário Clínico: Diagnósticos, Receitas e Triagens -->
<div class="card border-0 shadow-sm rounded-3">
    <div class="card-header bg-white border-bottom p-0">
        <ul class="nav nav-tabs card-header-tabs m-0 px-3" id="prontuarioTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active py-3" data-bs-toggle="tab" data-bs-target="#tabDiagnosticos">
                    <i class="fa-solid fa-stethoscope text-primary me-1"></i> Diagnósticos Clínicos (<?= count($diagnosticos) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabReceitas">
                    <i class="fa-solid fa-prescription text-info me-1"></i> Receitas Médicas (<?= count($receitas) ?>)
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link py-3" data-bs-toggle="tab" data-bs-target="#tabTriagens">
                    <i class="fa-solid fa-heart-pulse text-success me-1"></i> Sinais Vitais &amp; Triagem (<?= count($triagens) ?>)
                </button>
            </li>
        </ul>
    </div>

    <div class="card-body p-4">
        <div class="tab-content" id="prontuarioTabsContent">
            <!-- ABA DIAGNÓSTICOS -->
            <div class="tab-pane fade show active" id="tabDiagnosticos">
                <?php if (!empty($diagnosticos)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Data</th>
                                    <th>CID-10</th>
                                    <th>Diagnóstico / Hipótese</th>
                                    <th>Médico Responsável</th>
                                    <th>Conduta</th>
                                    <th class="text-end">Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($diagnosticos as $d): ?>
                                    <tr>
                                        <td><?= date('d/m/Y H:i', strtotime($d['created'])) ?></td>
                                        <td><span class="badge bg-primary"><?= htmlspecialchars($d['cid10']) ?></span></td>
                                        <td><strong><?= htmlspecialchars($d['titulo']) ?></strong></td>
                                        <td><?= htmlspecialchars($d['medico_nome'] ?? 'Dr. Carlos Roberto') ?></td>
                                        <td><?= htmlspecialchars(substr($d['conduta'] ?? '', 0, 50)) ?>...</td>
                                        <td class="text-end">
                                            <a href="../diagnosticos/view.php?id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-primary">Ver Laudo</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-4">Nenhum diagnóstico emitido para este paciente ainda.</p>
                <?php endif; ?>
            </div>

            <!-- ABA RECEITAS -->
            <div class="tab-pane fade" id="tabReceitas">
                <?php if (!empty($receitas)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Data</th>
                                    <th>Medicamentos Prescritos</th>
                                    <th>Médico Prescritor</th>
                                    <th>Validade</th>
                                    <th class="text-end">Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($receitas as $r): ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($r['created'])) ?></td>
                                        <td><strong><?= htmlspecialchars($r['medicamentos']) ?></strong></td>
                                        <td><?= htmlspecialchars($r['medico_nome'] ?? 'Dr. Carlos Roberto') ?></td>
                                        <td><span class="badge bg-success"><?= date('d/m/Y', strtotime($r['validade'])) ?></span></td>
                                        <td class="text-end">
                                            <a href="../receitas/view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary">Detalhes</a>
                                            <a href="../receitas/imprimir.php?id=<?= $r['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                                <i class="fa-solid fa-print"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-4">Nenhuma receita prescrita para este paciente ainda.</p>
                <?php endif; ?>
            </div>

            <!-- ABA TRIAGENS & SINAIS VITAIS -->
            <div class="tab-pane fade" id="tabTriagens">
                <?php if (!empty($triagens)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Data/Hora</th>
                                    <th>Pressão (PA)</th>
                                    <th>Temp.</th>
                                    <th>Sat. O2</th>
                                    <th>Freq. Cardíaca</th>
                                    <th>Classificação</th>
                                    <th>Enfermeiro(a)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($triagens as $t): ?>
                                    <tr>
                                        <td><?= date('d/m/Y H:i', strtotime($t['created'])) ?></td>
                                        <td><strong><?= htmlspecialchars($t['pressao']) ?></strong> mmHg</td>
                                        <td><?= htmlspecialchars($t['temperatura']) ?> &deg;C</td>
                                        <td><?= htmlspecialchars($t['saturacao']) ?>%</td>
                                        <td><?= htmlspecialchars($t['fc']) ?> bpm</td>
                                        <td>
                                            <span class="badge bg-<?= $t['classificacao_cor'] ?? 'primary' ?>">
                                                <?= htmlspecialchars($t['classificacao_nome'] ?? 'Normal') ?>
                                            </span>
                                        </td>
                                        <td><?= htmlspecialchars($t['enfermeiro_nome'] ?? 'Enfª Mariana') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-4">Nenhum registro de triagem/sinais vitais cadastrado.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
