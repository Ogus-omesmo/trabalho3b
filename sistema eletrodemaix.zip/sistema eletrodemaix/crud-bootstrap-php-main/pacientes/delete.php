<?php 
require_once('function.php'); 
check_permission([ROLE_MEDICO, ROLE_ENFERMEIRO]);

if (isset($_GET['id'])) {
    delete($_GET['id']);
} else {
    die("ERRO: ID não definido.");
}
