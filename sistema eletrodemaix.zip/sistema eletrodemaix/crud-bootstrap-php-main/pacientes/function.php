<?php
require_once('../config.php');
require_once(DBAPI);

$pacientes = null;
$paciente  = null;

/**
 * Listagem de Pacientes
 */
function index() {
    global $pacientes;
    $pacientes = find_all('pacientes');
    if (!$pacientes) {
        $pacientes = [];
    }
}

/**
 * Cadastro de Pacientes
 */
function add() {
    if (!empty($_POST['paciente'])) {
        $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $paciente = $_POST['paciente'];
        $paciente['created'] = $today->format("Y-m-d H:i:s");
        $paciente['modified'] = $today->format("Y-m-d H:i:s");
        
        save('pacientes', $paciente);
        header('Location: index.php');
        exit;
    }
}

/**
 * Atualização de Pacientes
 */
function edit() {
    $now = date_create('now', new DateTimeZone('America/Sao_Paulo'));
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        if (isset($_POST['paciente'])) {
            $paciente = $_POST['paciente'];
            $paciente['modified'] = $now->format("Y-m-d H:i:s");
            update('pacientes', $id, $paciente);
            header('Location: index.php');
            exit;
        } else {
            global $paciente;
            $paciente = find('pacientes', $id);
        }
    } else {
        header('Location: index.php');
        exit;
    }
}

/**
 * Visualização do Paciente e seu Histórico
 */
function view($id = null) {
    global $paciente;
    $paciente = find('pacientes', $id);
}

/**
 * Exclusão de Paciente
 */
function delete($id = null) {
    if ($id) {
        remove('pacientes', $id);
        header('Location: index.php');
        exit;
    }
}
