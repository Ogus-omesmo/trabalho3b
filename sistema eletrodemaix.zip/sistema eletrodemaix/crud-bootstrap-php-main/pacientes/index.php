<?php
require_once('function.php');
check_permission([ROLE_MEDICO, ROLE_ENFERMEIRO]);
index();
include(HEADER_TEMPLATE);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-user-injured text-primary me-2"></i>Pacientes Cadastrados</h2>
        <small class="text-muted">Gestão de prontuários, fichas cadastrais e triagem hospitalar</small>
    </div>
    <div>
        <a class="btn btn-primary" href="add.php"><i class="fa-solid fa-user-plus me-1"></i> Novo Paciente</a>
        <a class="btn btn-outline-secondary" href="../index.php"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<!-- Barra de Busca Rápida -->
<div class="row mb-3">
    <div class="col-md-6">
        <div class="input-group">
            <span class="input-group-text bg-white"><i class="fa-solid fa-magnifying-glass text-muted"></i></span>
            <input type="text" id="filtroTabela" class="form-control" placeholder="Buscar por nome, CPF ou convênio...">
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" id="tabelaPacientes">
            <thead class="table-light">
                <tr>
                    <th width="5%">ID</th>
                    <th width="25%">Nome do Paciente</th>
                    <th width="15%">CPF</th>
                    <th width="15%">Telefone</th>
                    <th width="15%">Convênio</th>
                    <th width="10%">Tipo Sang.</th>
                    <th width="15%" class="text-end">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($pacientes)): ?>
                    <?php foreach ($pacientes as $p): ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border"><?= $p['id'] ?></span></td>
                            <td>
                                <strong class="text-dark"><?= htmlspecialchars($p['nome']) ?></strong>
                                <?php if (!empty($p['alergias'])): ?>
                                    <br><small class="text-danger"><i class="fa-solid fa-triangle-exclamation"></i> Alergia: <?= htmlspecialchars($p['alergias']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($p['cpf']) ?></td>
                            <td><?= htmlspecialchars($p['telefone']) ?></td>
                            <td><span class="badge bg-info-subtle text-info border border-info-subtle"><?= htmlspecialchars($p['convenio'] ?? 'Particular') ?></span></td>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($p['tipo_sanguineo'] ?? 'N/I') ?></span></td>
                            <td class="text-end">
                                <a href="view.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary" title="Ver Prontuário">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <a href="edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Editar Cadastro">
                                    <i class="fa-solid fa-pen"></i>
                                </a>
                                <a href="delete.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deseja realmente remover este paciente?');" title="Excluir">
                                    <i class="fa-solid fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">
                            <i class="fa-solid fa-folder-open fa-2x mb-2 d-block"></i>
                            Nenhum paciente cadastrado no sistema.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
