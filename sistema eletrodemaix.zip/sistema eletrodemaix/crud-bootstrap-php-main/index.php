<?php
include_once 'config.php';
include_once DBAPI;
include_once HEADER_TEMPLATE;

$user = current_user();
?>

<!-- Header de Boas-Vindas com Informação de Perfil -->
<div class="row mb-4 align-items-center">
    <div class="col-md-8">
        <h2 class="fw-bold mb-1">
            <i class="fa-solid fa-hospital text-primary me-2"></i>Painel do Sistema Médico
        </h2>
        <p class="text-muted mb-0">
            Conectado como: <strong><?= htmlspecialchars($user['nome']) ?></strong> 
            <span class="badge badge-role-<?= $user['role'] ?> text-uppercase ms-2"><?= $user['role'] ?></span>
            <?php if (!empty($user['registro'])): ?>
                <span class="badge bg-secondary ms-1"><?= $user['registro'] ?></span>
            <?php endif; ?>
        </p>
    </div>
    <div class="col-md-4 text-md-end mt-3 mt-md-0">
        <div class="btn-group">
            <button type="button" class="btn btn-outline-primary dropdown-toggle btn-sm" data-bs-toggle="dropdown">
                <i class="fa-solid fa-user-gear me-1"></i> Alternar Perfil
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow">
                <li><h6 class="dropdown-header">Selecione para Testar Permissões:</h6></li>
                <li><a class="dropdown-item" href="login.php?switch=medico"><i class="fa-solid fa-user-doctor text-primary me-2"></i>Médico (Diagnósticos e Receitas)</a></li>
                <li><a class="dropdown-item" href="login.php?switch=enfermeiro"><i class="fa-solid fa-user-nurse text-success me-2"></i>Enfermeiro (Remédios e Escala)</a></li>
                <li><a class="dropdown-item" href="login.php?switch=cliente"><i class="fa-solid fa-hospital-user text-purple me-2"></i>Cliente (Histórico e Agendamentos)</a></li>
            </ul>
        </div>
    </div>
</div>

<hr class="mb-4">

<!-- CONTEÚDO CONDICIONAL CONFORME O PERFIL DO USUÁRIO -->

<?php if ($user['role'] === ROLE_MEDICO): ?>
    <!-- ==================== DASHBOARD DO MÉDICO ==================== -->
    <div class="alert alert-primary d-flex align-items-center mb-4" role="alert">
        <i class="fa-solid fa-user-doctor fs-3 me-3 text-primary"></i>
        <div>
            <strong>Espaço Clínico do Médico:</strong> Você possui autorização para emitir <strong>Diagnósticos</strong>, prescrever <strong>Receitas Médicas</strong>, consultar prontuários e gerenciar suas consultas.
        </div>
    </div>

    <div class="row g-4 mb-5">
        <!-- Emitir Diagnóstico -->
        <div class="col-sm-6 col-lg-3">
            <div class="card card-custom h-100 border-start border-primary border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-primary-subtle text-primary fw-semibold">Exclusivo Médico</span>
                    <i class="fa-solid fa-stethoscope fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold mb-2">Diagnósticos</h5>
                <p class="text-muted small mb-4">Emita novos diagnósticos com CID-10, anamnese, sintomas e conduta médica.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="diagnosticos/add.php" class="btn btn-primary btn-sm">
                        <i class="fa-solid fa-plus-circle me-1"></i> Emitir Diagnóstico
                    </a>
                    <a href="diagnosticos/" class="btn btn-outline-secondary btn-sm">
                        <i class="fa-solid fa-list me-1"></i> Ver Histórico
                    </a>
                </div>
            </div>
        </div>

        <!-- Emitir Receita Médica -->
        <div class="col-sm-6 col-lg-3">
            <div class="card card-custom h-100 border-start border-info border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-info-subtle text-info fw-semibold">Exclusivo Médico</span>
                    <i class="fa-solid fa-receipt fa-2x text-info"></i>
                </div>
                <h5 class="fw-bold mb-2">Receitas Médicas</h5>
                <p class="text-muted small mb-4">Prescreva medicamentos, dosagens e orientações com carimbo e impressão.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="receitas/add.php" class="btn btn-info text-white btn-sm">
                        <i class="fa-solid fa-pen-nib me-1"></i> Emitir Receita
                    </a>
                    <a href="receitas/" class="btn btn-outline-secondary btn-sm">
                        <i class="fa-solid fa-list me-1"></i> Ver Receitas
                    </a>
                </div>
            </div>
        </div>

        <!-- Pacientes / Prontuários -->
        <div class="col-sm-6 col-lg-3">
            <div class="card card-custom h-100 border-start border-secondary border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-secondary-subtle text-secondary fw-semibold">Prontuário Geral</span>
                    <i class="fa-solid fa-user-injured fa-2x text-secondary"></i>
                </div>
                <h5 class="fw-bold mb-2">Pacientes</h5>
                <p class="text-muted small mb-4">Consulte fichas de atendimento, histórico clínico e alergias dos pacientes.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="pacientes/" class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-users me-1"></i> Acessar Pacientes
                    </a>
                </div>
            </div>
        </div>

        <!-- Agendamentos / Consultas -->
        <div class="col-sm-6 col-lg-3">
            <div class="card card-custom h-100 border-start border-dark border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-dark-subtle text-dark fw-semibold">Consultório</span>
                    <i class="fa-solid fa-calendar-check fa-2x text-dark"></i>
                </div>
                <h5 class="fw-bold mb-2">Agendamentos</h5>
                <p class="text-muted small mb-4">Visualize as consultas marcadas para o dia e horários de atendimento.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="agendamentos/" class="btn btn-dark btn-sm">
                        <i class="fa-solid fa-calendar me-1"></i> Ver Minhas Consultas
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php elseif ($user['role'] === ROLE_ENFERMEIRO): ?>
    <!-- ==================== DASHBOARD DO ENFERMEIRO ==================== -->
    <div class="alert alert-success d-flex align-items-center mb-4" role="alert">
        <i class="fa-solid fa-user-nurse fs-3 me-3 text-success"></i>
        <div>
            <strong>Espaço da Enfermagem:</strong> Acesso completo ao controle de <strong>Remédios / Farmácia</strong>, gestão da <strong>Escala de Trabalho e Plantões</strong>, e triagem de <strong>Pacientes</strong>.
        </div>
    </div>

    <div class="row g-4 mb-5">
        <!-- Remédios e Medicamentos -->
        <div class="col-sm-6 col-lg-4">
            <div class="card card-custom h-100 border-start border-success border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-success-subtle text-success fw-semibold">Gestão de Farmácia</span>
                    <i class="fa-solid fa-pills fa-2x text-success"></i>
                </div>
                <h5 class="fw-bold mb-2">Remédios &amp; Estoque</h5>
                <p class="text-muted small mb-4">Controle de lotes, validades, quantidades em estoque e dispensação de fármacos.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="remedios/" class="btn btn-success btn-sm">
                        <i class="fa-solid fa-boxes-stacked me-1"></i> Controlar Remédios
                    </a>
                    <a href="remedios/add.php" class="btn btn-outline-success btn-sm">
                        <i class="fa-solid fa-plus me-1"></i> Cadastrar Remédio
                    </a>
                </div>
            </div>
        </div>

        <!-- Escala de Trabalho -->
        <div class="col-sm-6 col-lg-4">
            <div class="card card-custom h-100 border-start border-warning border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-warning-subtle text-warning fw-semibold">Turnos &amp; Plantões</span>
                    <i class="fa-solid fa-calendar-week fa-2x text-warning"></i>
                </div>
                <h5 class="fw-bold mb-2">Escala de Trabalho</h5>
                <p class="text-muted small mb-4">Acompanhe a distribuição de plantões, turnos (Manhã/Tarde/Noite) e setores (UTI/Emergência).</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="escalas/" class="btn btn-warning text-dark btn-sm">
                        <i class="fa-solid fa-calendar-days me-1"></i> Ver Escalas
                    </a>
                    <a href="escalas/add.php" class="btn btn-outline-warning text-dark btn-sm">
                        <i class="fa-solid fa-plus me-1"></i> Nova Alocação
                    </a>
                </div>
            </div>
        </div>

        <!-- Pacientes & Triagem -->
        <div class="col-sm-6 col-lg-4">
            <div class="card card-custom h-100 border-start border-primary border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-primary-subtle text-primary fw-semibold">Triagem Clínica</span>
                    <i class="fa-solid fa-heart-pulse fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold mb-2">Pacientes &amp; Triagem</h5>
                <p class="text-muted small mb-4">Registro de sinais vitais (PA, Temperatura, O2), triagem de prioridade e observações.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="pacientes/" class="btn btn-primary btn-sm">
                        <i class="fa-solid fa-user-nurse me-1"></i> Lista de Pacientes
                    </a>
                    <a href="pacientes/add.php" class="btn btn-outline-primary btn-sm">
                        <i class="fa-solid fa-user-plus me-1"></i> Cadastrar Paciente
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php elseif ($user['role'] === ROLE_CLIENTE): ?>
    <!-- ==================== DASHBOARD DO CLIENTE / PACIENTE ==================== -->
    <div class="alert alert-info d-flex align-items-center mb-4" role="alert">
        <i class="fa-solid fa-hospital-user fs-3 me-3 text-info"></i>
        <div>
            <strong>Portal do Paciente:</strong> Aqui você visualiza exclusivamente o <strong>seu histórico de diagnósticos</strong>, suas <strong>receitas médicas ativas</strong> e seus <strong>agendamentos de consultas</strong>.
        </div>
    </div>

    <div class="row g-4 mb-5">
        <!-- Meu Histórico Clínico -->
        <div class="col-sm-6 col-lg-4">
            <div class="card card-custom h-100 border-start border-info border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-info-subtle text-info fw-semibold">Área do Paciente</span>
                    <i class="fa-solid fa-clock-rotate-left fa-2x text-info"></i>
                </div>
                <h5 class="fw-bold mb-2">Meu Histórico</h5>
                <p class="text-muted small mb-4">Consulte os diagnósticos emitidos pelos médicos nas suas consultas anteriores.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="meu-historico/" class="btn btn-info text-white btn-sm">
                        <i class="fa-solid fa-folder-open me-1"></i> Visualizar Histórico
                    </a>
                </div>
            </div>
        </div>

        <!-- Minhas Receitas -->
        <div class="col-sm-6 col-lg-4">
            <div class="card card-custom h-100 border-start border-success border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-success-subtle text-success fw-semibold">Prescrições</span>
                    <i class="fa-solid fa-receipt fa-2x text-success"></i>
                </div>
                <h5 class="fw-bold mb-2">Minhas Receitas</h5>
                <p class="text-muted small mb-4">Acesse receitas ativas com posologia de remédios e opção de imprimir via digital.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="meu-historico/#receitas" class="btn btn-success btn-sm">
                        <i class="fa-solid fa-print me-1"></i> Ver Minhas Receitas
                    </a>
                </div>
            </div>
        </div>

        <!-- Meus Agendamentos -->
        <div class="col-sm-6 col-lg-4">
            <div class="card card-custom h-100 border-start border-primary border-4 p-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="badge bg-primary-subtle text-primary fw-semibold">Consultas Marcadas</span>
                    <i class="fa-solid fa-calendar-alt fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold mb-2">Meus Agendamentos</h5>
                <p class="text-muted small mb-4">Verifique datas de retorno, especialidades médicas e agende nova consulta.</p>
                <div class="mt-auto d-grid gap-2">
                    <a href="agendamentos/" class="btn btn-primary btn-sm">
                        <i class="fa-solid fa-calendar-check me-1"></i> Meus Agendamentos
                    </a>
                    <a href="agendamentos/add.php" class="btn btn-outline-primary btn-sm">
                        <i class="fa-solid fa-calendar-plus me-1"></i> Solicitar Consulta
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Resumo Informativo das Regras de Negócio e Permissões -->
<div class="card border-0 bg-white p-4 shadow-sm rounded-3">
    <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-shield-halved text-primary me-2"></i>Matriz de Permissões do Sistema Médico</h5>
    <div class="table-responsive">
        <table class="table table-bordered table-sm align-middle text-center mb-0">
            <thead class="table-light">
                <tr>
                    <th class="text-start">Funcionalidade / Módulo</th>
                    <th><i class="fa-solid fa-user-doctor text-primary me-1"></i> Médico</th>
                    <th><i class="fa-solid fa-user-nurse text-success me-1"></i> Enfermeiro</th>
                    <th><i class="fa-solid fa-hospital-user text-purple me-1"></i> Cliente / Paciente</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-start fw-semibold">Emitir Receitas Médicas</td>
                    <td><span class="badge bg-success"><i class="fa-solid fa-check"></i> Permitido (Emissão &amp; Impressão)</span></td>
                    <td><span class="badge bg-light text-muted border">Não Permitido</span></td>
                    <td><span class="badge bg-info text-dark">Visualiza Somente as Suas</span></td>
                </tr>
                <tr>
                    <td class="text-start fw-semibold">Emitir Diagnósticos (CID-10)</td>
                    <td><span class="badge bg-success"><i class="fa-solid fa-check"></i> Permitido (Laudo &amp; Conduta)</span></td>
                    <td><span class="badge bg-light text-muted border">Não Permitido</span></td>
                    <td><span class="badge bg-info text-dark">Visualiza Somente os Seus</span></td>
                </tr>
                <tr>
                    <td class="text-start fw-semibold">Controle de Remédios &amp; Estoque</td>
                    <td><span class="badge bg-light text-secondary border">Consulta</span></td>
                    <td><span class="badge bg-success"><i class="fa-solid fa-check"></i> Acesso Total (Estoque/Lotes)</span></td>
                    <td><span class="badge bg-light text-muted border">Sem Acesso</span></td>
                </tr>
                <tr>
                    <td class="text-start fw-semibold">Gestão da Escala de Trabalho</td>
                    <td><span class="badge bg-light text-secondary border">Consulta Escala</span></td>
                    <td><span class="badge bg-success"><i class="fa-solid fa-check"></i> Acesso Total (Plantões &amp; Turnos)</span></td>
                    <td><span class="badge bg-light text-muted border">Sem Acesso</span></td>
                </tr>
                <tr>
                    <td class="text-start fw-semibold">Pacientes &amp; Prontuários</td>
                    <td><span class="badge bg-success"><i class="fa-solid fa-check"></i> Prontuário Geral</span></td>
                    <td><span class="badge bg-success"><i class="fa-solid fa-check"></i> Triagem &amp; Sinais Vitais</span></td>
                    <td><span class="badge bg-light text-muted border">Sem Acesso a Terceiros</span></td>
                </tr>
                <tr>
                    <td class="text-start fw-semibold">Histórico &amp; Agendamentos Personalizados</td>
                    <td><span class="badge bg-primary">Consultas do Médico</span></td>
                    <td><span class="badge bg-light text-muted border">Sem Acesso</span></td>
                    <td><span class="badge bg-success"><i class="fa-solid fa-check"></i> Acesso Personalizado Exclusivo</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include_once FOOTER_TEMPLATE; ?>
