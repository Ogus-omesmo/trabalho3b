<?php
/**
 * API REST / CRUD para o Sistema Hospitalar no XAMPP
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/conexao.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Ler payload JSON se enviado via fetch
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

try {
    switch ($action) {
        case 'login':
            $usuario = trim($input['usuario'] ?? '');
            $senha = trim($input['senha'] ?? '');

            $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE LOWER(usuario) = LOWER(:usuario) AND senha = :senha LIMIT 1");
            $stmt->execute([':usuario' => $usuario, ':senha' => $senha]);
            $user = $stmt->fetch();

            if ($user) {
                unset($user['senha']);
                echo json_encode(['success' => true, 'user' => $user]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Usuário ou senha inválidos.']);
            }
            break;

        case 'obter_dados':
            $fila = $pdo->query("SELECT * FROM fila_pacientes ORDER BY 
                CASE grau WHEN 'Urgente' THEN 1 WHEN 'Cuidado' THEN 2 ELSE 3 END ASC, 
                chegada_hora ASC")->fetchAll();

            $fichas = $pdo->query("SELECT * FROM fichas ORDER BY data DESC, hora DESC")->fetchAll();
            $remedios = $pdo->query("SELECT * FROM remedios ORDER BY nome ASC")->fetchAll();
            $saidas = $pdo->query("SELECT * FROM historico_saidas ORDER BY id DESC")->fetchAll();
            $atendimentos = $pdo->query("SELECT * FROM atendimentos ORDER BY id DESC")->fetchAll();

            echo json_encode([
                'success' => true,
                'fila' => $fila,
                'fichas' => $fichas,
                'remedios' => $remedios,
                'historico_saidas' => $saidas,
                'atendimentos' => $atendimentos
            ]);
            break;

        case 'adicionar_fila':
            $grau = $input['grau'] ?? 'Simples';
            $prefix = ($grau === 'Urgente') ? 'URG' : (($grau === 'Cuidado') ? 'CUID' : 'SIMP');
            
            $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM fila_pacientes WHERE codigo LIKE :prefix");
            $stmtCount->execute([':prefix' => "{$prefix}-%"]);
            $total = (int)$stmtCount->fetchColumn() + 1;
            $codigo = sprintf("%s-%03d", $prefix, $total);
            $chegada = date('H:i');

            $stmt = $pdo->prepare("INSERT INTO fila_pacientes 
                (codigo, paciente_nome, paciente_documento, dn, idade, chegada_hora, motivo, sintomas, grau, status) 
                VALUES (:codigo, :nome, :doc, :dn, :idade, :chegada, :motivo, :sintomas, :grau, 'Aguardando')");
            
            $stmt->execute([
                ':codigo' => $codigo,
                ':nome' => $input['paciente_nome'] ?? '',
                ':doc' => $input['paciente_documento'] ?? '',
                ':dn' => $input['dn'] ?? '',
                ':idade' => $input['idade'] ?? '',
                ':chegada' => $chegada,
                ':motivo' => $input['motivo'] ?? '',
                ':sintomas' => $input['sintomas'] ?? '',
                ':grau' => $grau
            ]);

            $id = $pdo->lastInsertId();
            echo json_encode(['success' => true, 'id' => $id, 'codigo' => $codigo, 'chegada_hora' => $chegada]);
            break;

        case 'atualizar_status_fila':
            $id = (int)($input['id'] ?? 0);
            $status = $input['status'] ?? 'Aguardando';
            $chamado_por = $input['chamado_por'] ?? null;

            $stmt = $pdo->prepare("UPDATE fila_pacientes SET status = :status, chamado_por = COALESCE(:chamado_por, chamado_por) WHERE id = :id");
            $stmt->execute([':status' => $status, ':chamado_por' => $chamado_por, ':id' => $id]);
            echo json_encode(['success' => true]);
            break;

        case 'alterar_grau_fila':
            $id = (int)($input['id'] ?? 0);
            $grau = $input['grau'] ?? 'Simples';

            $stmt = $pdo->prepare("UPDATE fila_pacientes SET grau = :grau WHERE id = :id");
            $stmt->execute([':grau' => $grau, ':id' => $id]);
            echo json_encode(['success' => true]);
            break;

        case 'salvar_ficha':
            $ano = date('Y');
            $seq = rand(1000, 9999);
            $codigo = "DOC-{$ano}-{$seq}";
            $data = $input['data'] ?? date('Y-m-d');
            $hora = $input['hora'] ?? date('H:i');

            // Se aplicou medicamento no atendimento, baixa do estoque e registra saída
            $remedioId = !empty($input['remedio_aplicado_id']) ? (int)$input['remedio_aplicado_id'] : null;
            $remedioNome = $input['remedio_aplicado_nome'] ?? null;
            $remedioQtd = (int)($input['remedio_aplicado_qtd'] ?? 1);

            if ($remedioId) {
                // Atualiza estoque
                $stmtRemedio = $pdo->prepare("UPDATE remedios SET quantidade_estoque = GREATEST(0, quantidade_estoque - :qtd) WHERE id = :id");
                $stmtRemedio->execute([':qtd' => $remedioQtd, ':id' => $remedioId]);

                // Registra em historico_saidas
                $stmtSaida = $pdo->prepare("INSERT INTO historico_saidas 
                    (data_hora, paciente_nome, remedio_nome, quantidade, profissional_responsavel, motivo_observacao) 
                    VALUES (:data_hora, :paciente, :remedio, :qtd, :prof, :obs)");
                $stmtSaida->execute([
                    ':data_hora' => "{$data} {$hora}",
                    ':paciente' => $input['paciente_nome'] ?? '',
                    ':remedio' => $remedioNome,
                    ':qtd' => $remedioQtd,
                    ':prof' => $input['medico_nome'] ?? 'Dr. Gustavo',
                    ':obs' => 'Aplicação direta durante consulta clínica.'
                ]);
            }

            // Insere ficha
            $stmt = $pdo->prepare("INSERT INTO fichas 
                (codigo, tipo, tipo_customizado, paciente_nome, paciente_documento, dn, idade, data, hora, 
                 diagnostico_hipotese, cid10, prescricao_medicamentos, orientacoes_cuidados, dias_afastamento, 
                 medico_nome, medico_crm, medicamento_aplicado_id, medicamento_aplicado_nome, medicamento_aplicado_qtd, 
                 enviado_enfermaria, data_envio, status_enfermaria) 
                VALUES 
                (:codigo, :tipo, :tipo_custom, :nome, :doc, :dn, :idade, :data, :hora, 
                 :diag, :cid, :presc, :orient, :dias, 
                 :medico, :crm, :rem_id, :rem_nome, :rem_qtd, 
                 :enviado, :data_envio, :status_enf)");

            $enviado = !empty($input['enviado_enfermaria']) ? 1 : 0;
            $stmt->execute([
                ':codigo' => $codigo,
                ':tipo' => $input['tipo'] ?? 'Ficha Clínica',
                ':tipo_custom' => $input['tipo_customizado'] ?? null,
                ':nome' => $input['paciente_nome'] ?? '',
                ':doc' => $input['paciente_documento'] ?? '',
                ':dn' => $input['dn'] ?? null,
                ':idade' => $input['idade'] ?? '',
                ':data' => $data,
                ':hora' => $hora,
                ':diag' => $input['diagnostico_hipotese'] ?? '',
                ':cid' => $input['cid10'] ?? null,
                ':presc' => $input['prescricao_medicamentos'] ?? '',
                ':orient' => $input['orientacoes_cuidados'] ?? '',
                ':dias' => !empty($input['dias_afastamento']) ? (int)$input['dias_afastamento'] : null,
                ':medico' => $input['medico_nome'] ?? 'Dr. Gustavo',
                ':crm' => $input['medico_crm'] ?? 'CRM/SP 58912',
                ':rem_id' => $remedioId,
                ':rem_nome' => $remedioNome,
                ':rem_qtd' => $remedioId ? $remedioQtd : null,
                ':enviado' => $enviado,
                ':data_envio' => $enviado ? "{$data} {$hora}" : null,
                ':status_enf' => $enviado ? 'Aguardando Atendimento' : null
            ]);

            // Se o paciente estava na fila, baixa como Atendido (e ele some da fila ativa)
            $stmtFila = $pdo->prepare("UPDATE fila_pacientes SET status = 'Atendido', chamado_por = :medico WHERE LOWER(TRIM(paciente_nome)) = LOWER(TRIM(:nome))");
            $stmtFila->execute([':medico' => $input['medico_nome'] ?? 'Dr. Gustavo', ':nome' => $input['paciente_nome'] ?? '']);

            echo json_encode(['success' => true, 'codigo' => $codigo, 'id' => $pdo->lastInsertId()]);
            break;

        case 'salvar_remedio':
            $cod = "MED-" . rand(100, 999);
            $stmt = $pdo->prepare("INSERT INTO remedios 
                (codigo, nome, dosagem, apresentacao, laboratorio, lote, validade, quantidade_estoque, via, indicacoes, contraindicacoes) 
                VALUES (:codigo, :nome, :dosagem, :apres, :lab, :lote, :val, :qtd, :via, :ind, :contra)");
            $stmt->execute([
                ':codigo' => $cod,
                ':nome' => $input['nome'] ?? '',
                ':dosagem' => $input['dosagem'] ?? '',
                ':apres' => $input['apresentacao'] ?? '',
                ':lab' => $input['laboratorio'] ?? '',
                ':lote' => $input['lote'] ?? '',
                ':val' => $input['validade'] ?? '',
                ':qtd' => (int)($input['quantidade_estoque'] ?? 0),
                ':via' => $input['via'] ?? 'Oral',
                ':ind' => $input['indicacoes'] ?? '',
                ':contra' => $input['contraindicacoes'] ?? ''
            ]);
            echo json_encode(['success' => true, 'codigo' => $cod, 'id' => $pdo->lastInsertId()]);
            break;

        case 'dispensar_remedio':
            $id = (int)($input['remedio_id'] ?? 0);
            $qtd = (int)($input['quantidade'] ?? 1);
            $paciente = $input['paciente_nome'] ?? '';
            $obs = $input['observacao'] ?? '';
            $prof = $input['profissional'] ?? 'Dr. Gustavo';

            // Busca nome
            $stmtR = $pdo->prepare("SELECT nome, dosagem, quantidade_estoque FROM remedios WHERE id = :id");
            $stmtR->execute([':id' => $id]);
            $med = $stmtR->fetch();

            if (!$med || $med['quantidade_estoque'] < $qtd) {
                echo json_encode(['success' => false, 'message' => 'Estoque insuficiente.']);
                exit;
            }

            // Baixa no estoque
            $stmtUp = $pdo->prepare("UPDATE remedios SET quantidade_estoque = quantidade_estoque - :qtd WHERE id = :id");
            $stmtUp->execute([':qtd' => $qtd, ':id' => $id]);

            // Registra saída
            $stmtS = $pdo->prepare("INSERT INTO historico_saidas 
                (data_hora, paciente_nome, remedio_nome, quantidade, profissional_responsavel, motivo_observacao) 
                VALUES (:data_hora, :paciente, :remedio, :qtd, :prof, :obs)");
            $stmtS->execute([
                ':data_hora' => date('Y-m-d H:i'),
                ':paciente' => $paciente,
                ':remedio' => "{$med['nome']} ({$med['dosagem']})",
                ':qtd' => $qtd,
                ':prof' => $prof,
                ':obs' => $obs
            ]);

            echo json_encode(['success' => true]);
            break;

        case 'excluir_remedio':
            $id = (int)($input['id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM remedios WHERE id = :id");
            $stmt->execute([':id' => $id]);
            echo json_encode(['success' => true]);
            break;

        case 'salvar_atendimento':
            $cod = "ATN-" . rand(100, 999);
            $stmt = $pdo->prepare("INSERT INTO atendimentos 
                (codigo, data_hora, paciente_nome, paciente_documento, idade, queixa, pa, temp, fc, spo2, glicemia, procedimento_realizado, medicacao_administrada, observacoes, profissional_responsavel, status) 
                VALUES (:cod, :data_hora, :nome, :doc, :idade, :queixa, :pa, :temp, :fc, :spo2, :glic, :proc, :med, :obs, :prof, 'Concluído')");
            $stmt->execute([
                ':cod' => $cod,
                ':data_hora' => date('Y-m-d H:i'),
                ':nome' => $input['paciente_nome'] ?? '',
                ':doc' => $input['paciente_documento'] ?? '',
                ':idade' => $input['idade'] ?? '',
                ':queixa' => $input['queixa'] ?? '',
                ':pa' => $input['pa'] ?? '',
                ':temp' => $input['temp'] ?? '',
                ':fc' => $input['fc'] ?? '',
                ':spo2' => $input['spo2'] ?? '',
                ':glic' => $input['glicemia'] ?? '',
                ':proc' => $input['procedimento_realizado'] ?? '',
                ':med' => $input['medicacao_administrada'] ?? '',
                ':obs' => $input['observacoes'] ?? '',
                ':prof' => $input['profissional_responsavel'] ?? 'Dr. Gustavo'
            ]);
            echo json_encode(['success' => true, 'id' => $pdo->lastInsertId(), 'codigo' => $cod]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Ação não reconhecida.']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
