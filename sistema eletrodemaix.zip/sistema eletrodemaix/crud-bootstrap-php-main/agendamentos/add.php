<?php 
require_once('function.php'); 
add();

$user = current_user();
$pacientes = find_all('pacientes') ?: [];

include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-calendar-plus text-primary me-2"></i>Agendar Consulta Médica</h2>
        <small class="text-muted">Marcação de atendimento presencial ou retorno</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<form action="add.php" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <?php if ($user['role'] === ROLE_CLIENTE): ?>
            <!-- Cliente já tem seu ID fixado -->
            <div class="col-md-12">
                <div class="p-3 bg-light rounded">
                    <strong>Paciente:</strong> <?= htmlspecialchars($user['nome']) ?> (<?= htmlspecialchars($user['registro'] ?? 'Cliente') ?>)
                </div>
            </div>
        <?php else: ?>
            <div class="col-md-6">
                <label class="form-label fw-semibold">Paciente *</label>
                <select class="form-select" name="agendamento['paciente_id']" required>
                    <option value="">Selecione o paciente...</option>
                    <?php foreach ($pacientes as $p): ?>
                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nome']) ?> (CPF: <?= htmlspecialchars($p['cpf']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Especialidade Médica *</label>
            <select class="form-select" name="agendamento['especialidade']" required id="selectEspec">
                <option value="Clínica Geral">Clínica Geral</option>
                <option value="Cardiologia">Cardiologia</option>
                <option value="Pediatria">Pediatria</option>
                <option value="Ortopedia">Ortopedia</option>
                <option value="Dermatologia">Dermatologia</option>
                <option value="Ginecologia">Ginecologia</option>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Médico Responsável *</label>
            <select class="form-select" name="agendamento['medico_nome']" required>
                <option value="Dr. Carlos Roberto (CRM/SP 45210)">Dr. Carlos Roberto (CRM/SP 45210)</option>
                <option value="Dra. Juliana Mendes (CRM/SP 58921)">Dra. Juliana Mendes (CRM/SP 58921)</option>
                <option value="Dr. Fernando Alves (CRM/SP 31204)">Dr. Fernando Alves (CRM/SP 31204)</option>
            </select>
            <input type="hidden" name="agendamento['medico_id']" value="1">
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Data da Consulta *</label>
            <input type="date" class="form-control" name="agendamento['data_consulta']" required value="<?= date('Y-m-d', strtotime('+1 day')) ?>">
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Horário Preferencial *</label>
            <select class="form-select" name="agendamento['hora_consulta']" required>
                <option value="08:00">08:00</option>
                <option value="09:00">09:00</option>
                <option value="10:00">10:00</option>
                <option value="11:00">11:00</option>
                <option value="14:00" selected>14:00</option>
                <option value="15:00">15:00</option>
                <option value="16:00">16:00</option>
                <option value="17:00">17:00</option>
            </select>
        </div>

        <div class="col-md-8">
            <label class="form-label fw-semibold">Motivo da Consulta / Sintomas Iniciais</label>
            <input type="text" class="form-control" name="agendamento['motivo']" placeholder="Ex: Checkup de rotina, dores de cabeça constantes, retorno de exames...">
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-check me-1"></i> Confirmar Agendamento</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
