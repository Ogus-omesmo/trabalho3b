<?php
require_once('../config.php');
require_once(DBAPI);

$agendamentos = null;
$agendamento  = null;

/**
 * Listagem de Agendamentos / Consultas
 * Filtro personalizado automático para clientes!
 */
function index() {
    global $agendamentos;
    $user = current_user();
    
    if ($user && $user['role'] === ROLE_CLIENTE) {
        $paciente_id = intval($user['paciente_id'] ?? 1);
        $agendamentos = find_where('agendamentos', "paciente_id = {$paciente_id}", "data_consulta ASC, hora_consulta ASC");
    } elseif ($user && $user['role'] === ROLE_MEDICO) {
        $medico_id = intval($user['id'] ?? 1);
        $agendamentos = find_where('agendamentos', "medico_id = {$medico_id}", "data_consulta ASC, hora_consulta ASC");
    } else {
        $agendamentos = find_all('agendamentos');
    }
    
    if (!$agendamentos) {
        $agendamentos = [];
    }
}

/**
 * Criar Agendamento
 */
function add() {
    if (!empty($_POST['agendamento'])) {
        $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $agendamento = $_POST['agendamento'];
        $user = current_user();
        
        // Se for cliente agendando para si próprio:
        if ($user && $user['role'] === ROLE_CLIENTE) {
            $agendamento['paciente_id']   = $user['paciente_id'] ?? 1;
            $agendamento['paciente_nome'] = $user['nome'] ?? 'Cliente';
        } else {
            // Se for médico ou recepcionista/enfermeiro selecionando paciente:
            $pac = find('pacientes', $agendamento['paciente_id'] ?? 1);
            if ($pac) {
                $agendamento['paciente_nome'] = $pac['nome'];
            }
        }
        
        $agendamento['status']   = 'Agendado';
        $agendamento['created']  = $today->format("Y-m-d H:i:s");
        $agendamento['modified'] = $today->format("Y-m-d H:i:s");
        
        save('agendamentos', $agendamento);
        header('Location: index.php');
        exit;
    }
}

/**
 * Cancelar Agendamento
 */
function cancelar($id = null) {
    if ($id) {
        update('agendamentos', $id, ['status' => 'Cancelado']);
        header('Location: index.php');
        exit;
    }
}
