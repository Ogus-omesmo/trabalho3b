<?php 
require_once('function.php'); 

if (isset($_GET['id'])) {
    cancelar($_GET['id']);
} else {
    die("ERRO: ID não definido.");
}
