<?php
require_once('function.php');
index();
include(HEADER_TEMPLATE);
$user = current_user();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0">
            <i class="fa-solid fa-calendar-check text-primary me-2"></i>
            <?= ($user['role'] === ROLE_CLIENTE) ? 'Meus Agendamentos Personalizados' : 'Consultas & Agendamentos' ?>
        </h2>
        <small class="text-muted">
            <?= ($user['role'] === ROLE_CLIENTE) ? 'Consultas marcadas exclusivamente para o seu perfil de paciente' : 'Agenda de consultas clínicas e retornos' ?>
        </small>
    </div>
    <div>
        <a class="btn btn-primary" href="add.php"><i class="fa-solid fa-calendar-plus me-1"></i> Agendar Consulta</a>
        <a class="btn btn-outline-secondary" href="../index.php"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<?php if ($user['role'] === ROLE_CLIENTE): ?>
    <div class="alert alert-info py-2 mb-3">
        <i class="fa-solid fa-lock me-2"></i><strong>Privacidade:</strong> Você está visualizando unicamente os agendamentos vinculados ao seu cadastro de paciente.
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm rounded-3">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" id="tabelaAgendamentos">
            <thead class="table-light">
                <tr>
                    <th width="5%">ID</th>
                    <th width="15%">Data &amp; Horário</th>
                    <?php if ($user['role'] !== ROLE_CLIENTE): ?>
                        <th width="20%">Paciente</th>
                    <?php endif; ?>
                    <th width="20%">Médico / Especialidade</th>
                    <th width="20%">Motivo / Sintoma Principal</th>
                    <th width="10%">Status</th>
                    <th width="10%" class="text-end">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($agendamentos)): ?>
                    <?php foreach ($agendamentos as $a): ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border"><?= $a['id'] ?></span></td>
                            <td>
                                <strong><?= date('d/m/Y', strtotime($a['data_consulta'])) ?></strong><br>
                                <small class="text-muted"><i class="fa-regular fa-clock me-1"></i><?= htmlspecialchars($a['hora_consulta']) ?></small>
                            </td>
                            <?php if ($user['role'] !== ROLE_CLIENTE): ?>
                                <td>
                                    <strong><?= htmlspecialchars($a['paciente_nome'] ?? ('Paciente #' . $a['paciente_id'])) ?></strong>
                                </td>
                            <?php endif; ?>
                            <td>
                                <i class="fa-solid fa-user-doctor text-primary me-1"></i>
                                <?= htmlspecialchars($a['medico_nome'] ?? 'Dr. Carlos Roberto') ?><br>
                                <span class="badge bg-secondary-subtle text-secondary"><?= htmlspecialchars($a['especialidade'] ?? 'Clínica Geral') ?></span>
                            </td>
                            <td><?= htmlspecialchars($a['motivo'] ?? 'Consulta de rotina / retorno') ?></td>
                            <td>
                                <?php if ($a['status'] === 'Agendado'): ?>
                                    <span class="badge bg-primary">Agendado</span>
                                <?php elseif ($a['status'] === 'Realizado'): ?>
                                    <span class="badge bg-success">Realizado</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><?= htmlspecialchars($a['status']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if ($a['status'] === 'Agendado'): ?>
                                    <a href="cancelar.php?id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deseja realmente cancelar esta consulta?');">
                                        Cancelar
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">
                            <i class="fa-solid fa-calendar-xmark fa-2x mb-2 d-block"></i>
                            Nenhuma consulta agendada encontrada.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
