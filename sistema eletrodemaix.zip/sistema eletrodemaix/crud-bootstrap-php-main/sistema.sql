-- ==============================================================
-- SISTEMA HOSPITALAR - BANCO DE DADOS XAMPP (MySQL / MariaDB)
-- Compatível com phpMyAdmin e MySQL 5.7+ / 8.0+
-- ==============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `hospital_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `hospital_db`;

-- --------------------------------------------------------
-- 1. Tabela de Usuários do Sistema
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `usuario` VARCHAR(100) NOT NULL UNIQUE,
  `senha` VARCHAR(255) NOT NULL,
  `nome` VARCHAR(255) NOT NULL,
  `role` ENUM('medico', 'atendente', 'enfermeiro') NOT NULL,
  `registro` VARCHAR(50) DEFAULT NULL COMMENT 'CRM, COREN ou Matrícula',
  `setor` VARCHAR(100) DEFAULT NULL,
  `email` VARCHAR(255) DEFAULT NULL,
  `telefone` VARCHAR(30) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Credenciais solicitadas:
-- Médico: DR. Gustavo | Senha: 2108
-- Atendente: Mirella | Senha: 3107
INSERT INTO `usuarios` (`id`, `usuario`, `senha`, `nome`, `role`, `registro`, `setor`, `email`, `telefone`) VALUES
(1, 'DR. Gustavo', '2108', 'Dr. Gustavo', 'medico', 'CRM/SP 58912', 'Corpo Clínico Geral', 'dr.gustavo@hospital.med.br', '(11) 98765-4321'),
(2, 'Mirella', '3107', 'Mirella (Recepção)', 'atendente', 'REC-3107', 'Recepção e Triagem', 'mirella.recepcao@hospital.med.br', '(11) 98111-2233'),
(3, 'Enfermeiro', '1111', 'Enfª Mariana Rios Duarte', 'enfermeiro', 'COREN/SP 88412', 'Enfermaria e Posto', 'mariana.rios@hospital.med.br', '(11) 97654-3210')
ON DUPLICATE KEY UPDATE `senha` = VALUES(`senha`);

-- --------------------------------------------------------
-- 2. Tabela da Fila de Pacientes (Recepção & Triagem)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `fila_pacientes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `codigo` VARCHAR(30) NOT NULL COMMENT 'Senha gerada: ex: URG-001, CUID-001, SIMP-001',
  `paciente_nome` VARCHAR(255) NOT NULL,
  `paciente_documento` VARCHAR(50) NOT NULL,
  `dn` VARCHAR(30) DEFAULT NULL COMMENT 'Data de nascimento',
  `idade` VARCHAR(30) DEFAULT NULL,
  `chegada_hora` VARCHAR(10) NOT NULL COMMENT 'Horário de chegada HH:MM',
  `motivo` TEXT NOT NULL COMMENT 'Queixa principal',
  `sintomas` TEXT DEFAULT NULL,
  `grau` ENUM('Simples', 'Cuidado', 'Urgente') NOT NULL DEFAULT 'Simples' COMMENT 'Corte de fila',
  `status` ENUM('Aguardando', 'Chamado', 'Atendido', 'Cancelado') NOT NULL DEFAULT 'Aguardando',
  `chamado_por` VARCHAR(150) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fila_pacientes` (`id`, `codigo`, `paciente_nome`, `paciente_documento`, `dn`, `idade`, `chegada_hora`, `motivo`, `sintomas`, `grau`, `status`) VALUES
(1, 'URG-001', 'Marcos Vinicius Freitas', '789.012.345-66', '1976-02-14', '50 anos', '09:15', 'Pico febril alto e forte dor torácica', 'Febre de 39.5°C, sudorese fria, dor precordial com irradiação', 'Urgente', 'Aguardando'),
(2, 'CUID-001', 'Beatriz Vasconcelos', '678.901.234-55', '1955-08-30', '71 anos', '09:00', 'Falta de ar moderada e tosse contínua', 'Dispneia aos médios esforços, saturação de 92%, tosse produtiva', 'Cuidado', 'Aguardando'),
(3, 'SIMP-001', 'Carlos Eduardo Mendes', '567.890.123-44', '1988-11-05', '38 anos', '08:40', 'Dor na coluna pós-esforço', 'Lombalgia sem irradiação, desconforto lombar ao sentar', 'Simples', 'Aguardando'),
(4, 'SIMP-002', 'Juliana Paes Cavalcanti', '890.123.456-77', '1995-07-22', '31 anos', '09:30', 'Alergia na pele após alimentação', 'Placas eritematosas pruriginosas sem sinais respiratórios', 'Simples', 'Aguardando');

-- --------------------------------------------------------
-- 3. Tabela de Medicamentos / Remédios (Sem Princípio Ativo)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `remedios` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `codigo` VARCHAR(30) NOT NULL UNIQUE COMMENT 'ex: MED-101',
  `nome` VARCHAR(255) NOT NULL,
  `dosagem` VARCHAR(100) NOT NULL,
  `apresentacao` VARCHAR(100) NOT NULL,
  `laboratorio` VARCHAR(100) DEFAULT NULL,
  `lote` VARCHAR(50) NOT NULL,
  `validade` VARCHAR(20) NOT NULL,
  `quantidade_estoque` INT(11) NOT NULL DEFAULT 0,
  `via` VARCHAR(50) DEFAULT 'Oral',
  `indicacoes` TEXT DEFAULT NULL,
  `contraindicacoes` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `remedios` (`id`, `codigo`, `nome`, `dosagem`, `apresentacao`, `laboratorio`, `lote`, `validade`, `quantidade_estoque`, `via`, `indicacoes`, `contraindicacoes`) VALUES
(1, 'MED-101', 'Dipirona Monoidratada', '500mg/mL', 'Ampola 2mL Solução Injetável', 'Teuto', 'LT-2026-01', '2027-08', 120, 'Intravenosa (IV) / Intramuscular (IM)', 'Analgésico e antipirético potente', 'Hipersensibilidade a pirazolonas e porfiria hepática'),
(2, 'MED-102', 'Paracetamol', '750mg', 'Comprimido Revestido', 'Medley', 'LT-2026-02', '2027-11', 250, 'Oral (VO)', 'Dores de intensidade leve a moderada e febre', 'Doença hepática grave ativa'),
(3, 'MED-103', 'Amoxicilina + Clavulanato', '875mg + 125mg', 'Comprimido Revestido', 'EMS', 'LT-2026-03', '2026-12', 80, 'Oral (VO)', 'Infecções bacterianas do trato respiratório e urinário', 'Alergia conhecida a penicilinas e beta-lactâmicos'),
(4, 'MED-104', 'Cetoprofeno', '100mg IV', 'Frasco pó liofilizado para solução injetável', 'Sanofi', 'LT-2026-04', '2027-06', 35, 'Intravenosa (IV)', 'Processos inflamatórios agudos e dor severa', 'Úlcera péptica ativa'),
(5, 'MED-105', 'Omeprazol', '40mg', 'Frasco-ampola IV', 'Aché', 'LT-2026-05', '2027-04', 45, 'Intravenosa (IV)', 'Profilaxia de hemorragia digestiva e gastrite severa', 'Hipersensibilidade ao princípio ativo'),
(6, 'MED-106', 'Bromoprida', '10mg/2mL', 'Ampola 2mL', 'União Química', 'LT-2026-06', '2027-09', 60, 'Intravenosa (IV) / Oral', 'Anti-emético e procinético para náuseas e vômitos', 'Obstrução ou perfuração gastrintestinal');

-- --------------------------------------------------------
-- 4. Tabela de Fichas e Documentos Clínicos
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `fichas` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `codigo` VARCHAR(50) NOT NULL UNIQUE COMMENT 'ex: DOC-2026-001',
  `tipo` ENUM('Ficha Clínica', 'Laudo Médico', 'Atestado Médico', 'Outros') NOT NULL,
  `tipo_customizado` VARCHAR(150) DEFAULT NULL,
  `paciente_nome` VARCHAR(255) NOT NULL,
  `paciente_documento` VARCHAR(50) NOT NULL,
  `dn` VARCHAR(30) DEFAULT NULL,
  `idade` VARCHAR(30) NOT NULL,
  `data` DATE NOT NULL,
  `hora` VARCHAR(10) NOT NULL,
  `diagnostico_hipotese` TEXT NOT NULL,
  `cid10` VARCHAR(20) DEFAULT NULL,
  `prescricao_medicamentos` TEXT NOT NULL,
  `orientacoes_cuidados` TEXT NOT NULL,
  `dias_afastamento` INT(11) DEFAULT NULL,
  `medico_nome` VARCHAR(255) NOT NULL,
  `medico_crm` VARCHAR(50) DEFAULT NULL,
  `medicamento_aplicado_id` INT(11) DEFAULT NULL,
  `medicamento_aplicado_nome` VARCHAR(255) DEFAULT NULL,
  `medicamento_aplicado_qtd` INT(11) DEFAULT NULL,
  `enviado_enfermaria` TINYINT(1) NOT NULL DEFAULT 0,
  `data_envio` VARCHAR(50) DEFAULT NULL,
  `status_enfermaria` VARCHAR(100) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fichas` (`id`, `codigo`, `tipo`, `paciente_nome`, `paciente_documento`, `dn`, `idade`, `data`, `hora`, `diagnostico_hipotese`, `cid10`, `prescricao_medicamentos`, `orientacoes_cuidados`, `medico_nome`, `medico_crm`) VALUES
(1, 'FCH-2026-000', 'Ficha Clínica', 'Mariana Duarte Souza', '456.789.012-33', '1961-04-12', '65 anos', '2026-09-28', '07:50', 'Avaliação clínica cardiológica e renovação de receituário contínuo.', 'I11.9', '1. Hidroclorotiazida 25mg - 1 cp VO pela manhã.\n2. Enalapril 10mg - 1 cp VO 12/12h.', 'Dieta hipossódica e caminhada diária de 30 minutos.', 'Dr. Gustavo', 'CRM/SP 58912'),
(2, 'FCH-2026-001', 'Ficha Clínica', 'Roberto Silveira Rocha', '123.456.789-00', '1984-06-20', '42 anos', '2026-09-28', '08:30', 'Hipertensão Arterial Sistêmica Estágio 2 com queixa de cefaleia occipital.', 'I10', '1. Losartana Potássica 50mg - 1 comprimido VO às 08h.\n2. Dipirona Monoidratada 1g - 1 comprimido VO se dor forte.', 'Monitorar pressão arterial 2x ao dia. Repouso relativo.', 'Dr. Gustavo', 'CRM/SP 58912'),
(3, 'FCH-2026-002', 'Laudo Médico', 'Ana Clara Lima Santos', '234.567.890-11', '1997-09-15', '29 anos', '2026-09-28', '09:15', 'Amigdalite Bacteriana Aguda com hipertermia (38.5°C).', 'J03.9', '1. Amoxicilina + Clavulanato 875mg - 1 cp VO de 12/12h por 7 dias.\n2. Cetoprofeno 100mg - 1 cp VO a cada 12h após refeições.', 'Repouso e hidratação oral intensa. Retorno se persistir a febre.', 'Dr. Gustavo', 'CRM/SP 58912');

-- --------------------------------------------------------
-- 5. Tabela de Histórico de Saídas de Remédios
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `historico_saidas` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `data_hora` VARCHAR(30) NOT NULL,
  `paciente_nome` VARCHAR(255) NOT NULL,
  `remedio_nome` VARCHAR(255) NOT NULL,
  `quantidade` INT(11) NOT NULL,
  `profissional_responsavel` VARCHAR(255) NOT NULL,
  `motivo_observacao` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `historico_saidas` (`id`, `data_hora`, `paciente_nome`, `remedio_nome`, `quantidade`, `profissional_responsavel`, `motivo_observacao`) VALUES
(1, '2026-09-28 09:40', 'Ana Clara Lima Santos', 'Cetoprofeno (100mg IV)', 1, 'Dr. Gustavo', 'Administração para alívio térmico e dor aguda.'),
(2, '2026-09-28 08:35', 'Roberto Silveira Rocha', 'Dipirona Monoidratada (500mg/mL)', 1, 'Dr. Gustavo', 'Aplicação direta no consultório durante atendimento.');

-- --------------------------------------------------------
-- 6. Tabela de Atendimentos de Cuidados / Enfermagem
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `atendimentos` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `codigo` VARCHAR(30) NOT NULL,
  `data_hora` VARCHAR(30) NOT NULL,
  `paciente_nome` VARCHAR(255) NOT NULL,
  `paciente_documento` VARCHAR(50) NOT NULL,
  `idade` VARCHAR(30) DEFAULT NULL,
  `queixa` TEXT DEFAULT NULL,
  `pa` VARCHAR(20) DEFAULT NULL,
  `temp` VARCHAR(20) DEFAULT NULL,
  `fc` VARCHAR(20) DEFAULT NULL,
  `spo2` VARCHAR(20) DEFAULT NULL,
  `glicemia` VARCHAR(20) DEFAULT NULL,
  `procedimento_realizado` TEXT NOT NULL,
  `medicacao_administrada` TEXT DEFAULT NULL,
  `observacoes` TEXT DEFAULT NULL,
  `profissional_responsavel` VARCHAR(255) NOT NULL,
  `status` ENUM('Em Atendimento', 'Concluído') NOT NULL DEFAULT 'Concluído',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `atendimentos` (`id`, `codigo`, `data_hora`, `paciente_nome`, `paciente_documento`, `idade`, `queixa`, `pa`, `temp`, `fc`, `spo2`, `glicemia`, `procedimento_realizado`, `medicacao_administrada`, `observacoes`, `profissional_responsavel`, `status`) VALUES
(1, 'ATN-001', '2026-09-28 08:35', 'Roberto Silveira Rocha', '123.456.789-00', '42 anos', 'Cefaleia e mal-estar', '150/95', '36.8', '84', '98', '105', 'Aferição de sinais vitais e administração de medicação conforme prescrição.', 'Dipirona 500mg IV', 'Paciente repousou por 20 minutos no leito de observação. Sem queixas adicionais.', 'Dr. Gustavo', 'Concluído');
