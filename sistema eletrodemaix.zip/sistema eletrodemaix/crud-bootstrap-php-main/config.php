<?php
/**
 * Configuração Geral do Sistema Médico Hospitalar
 * Suporta 3 Perfis: Médico, Enfermeiro e Cliente/Paciente
 */

// Inicializa a sessão caso não esteja ativa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Configurações do Banco de Dados MySQL */
const DB_NAME = "sistema_medico";
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

/** Caminhos do Sistema **/
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

if (!defined('BASEURL')) {
    // Altere para '/' ou '/crud-bootstrap-php-main/' de acordo com seu ambiente XAMPP/WAMP
    define('BASEURL', '/crud-bootstrap-php-main/');
}

if (!defined('DBAPI')) {
    define("DBAPI", ABSPATH . 'inc/database.php');
}

const HEADER_TEMPLATE = ABSPATH . "inc/header.php";
const FOOTER_TEMPLATE = ABSPATH . "inc/footer.php";

/** Definições de Perfis de Usuários (Roles) **/
const ROLE_MEDICO     = 'medico';
const ROLE_ENFERMEIRO = 'enfermeiro';
const ROLE_CLIENTE    = 'cliente';

// Define usuário de demonstração padrão se não estiver autenticado
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = [
        'id'        => 1,
        'nome'      => 'Dr. Carlos Roberto',
        'email'     => 'carlos.medico@hospital.com',
        'role'      => ROLE_MEDICO,
        'registro'  => 'CRM/SP 45210',
        'paciente_id' => null
    ];
}
