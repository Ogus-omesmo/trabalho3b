<?php
/**
 * Conexão com o Banco de Dados MySQL no XAMPP via PDO
 * Host padrão: localhost
 * Usuário padrão: root
 * Senha padrão: (vazia)
 * Banco: hospital_db
 */

header('Content-Type: text/html; charset=utf-8');

$host = 'localhost';
$dbname = 'hospital_db';
$usuario = 'root';
$senha = '';

try {
    // Tenta conectar ao banco hospital_db
    $pdo = new PDO("mysql:host={$host};dbname={$dbname};charset=utf8mb4", $usuario, $senha, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    // Se o banco ainda não existe, tenta conectar ao MySQL raiz para criá-lo automaticamente
    try {
        $pdoRoot = new PDO("mysql:host={$host};charset=utf8mb4", $usuario, $senha);
        $pdoRoot->exec("CREATE DATABASE IF NOT EXISTS `{$dbname}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        $pdo = new PDO("mysql:host={$host};dbname={$dbname};charset=utf8mb4", $usuario, $senha, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        
        // Importa o script caso as tabelas não existam
        $sqlPath = __DIR__ . '/sistema_hospitalar_xampp.sql';
        if (file_exists($sqlPath)) {
            $sqlContent = file_get_contents($sqlPath);
            $pdo->exec($sqlContent);
        }
    } catch (PDOException $ex) {
        die("Erro ao conectar ao banco de dados no XAMPP: " . $ex->getMessage() . 
            "<br><br>Verifique se o serviço MySQL está 'Running' no Painel de Controle do XAMPP e se o banco 'hospital_db' foi criado no phpMyAdmin.");
    }
}
