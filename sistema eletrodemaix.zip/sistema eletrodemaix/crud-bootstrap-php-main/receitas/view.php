<?php 
require_once('function.php'); 
view($_GET['id'] ?? null);
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-receipt text-info me-2"></i>Receita Médica #<?= $receita['id'] ?? '' ?></h2>
        <small class="text-muted">Prescrição terapêutica emitida</small>
    </div>
    <div class="d-flex gap-2">
        <a href="imprimir.php?id=<?= $receita['id'] ?>" target="_blank" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-print me-1"></i> Imprimir Receituário
        </a>
        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<?php if (!empty($receita)): ?>
<div class="card p-4 shadow-sm border-0 bg-white">
    <div class="border-bottom pb-3 mb-4 d-flex justify-content-between align-items-center">
        <div>
            <span class="badge bg-info-subtle text-info border border-info-subtle fs-6 mb-1">
                <?= htmlspecialchars($receita['tipo'] ?? 'Receituário') ?>
            </span>
            <h4 class="fw-bold mb-0 text-dark"><?= htmlspecialchars($receita['medicamentos']) ?></h4>
            <small class="text-muted">Via: <?= htmlspecialchars($receita['via'] ?? 'Oral') ?></small>
        </div>
        <div class="text-end text-muted small">
            <div>Emissão: <strong><?= date('d/m/Y', strtotime($receita['created'])) ?></strong></div>
            <div>Validade: <strong class="text-success"><?= date('d/m/Y', strtotime($receita['validade'])) ?></strong></div>
        </div>
    </div>

    <!-- Paciente -->
    <div class="bg-light p-3 rounded mb-4">
        <h6 class="text-uppercase text-muted small fw-bold mb-1">Paciente</h6>
        <h5 class="fw-bold text-dark mb-0"><?= htmlspecialchars($receita['paciente_nome'] ?? ('Paciente #' . $receita['paciente_id'])) ?></h5>
    </div>

    <!-- Posologia -->
    <div class="mb-4">
        <h6 class="fw-bold text-primary border-start border-primary border-3 ps-2">Posologia e Instruções de Uso</h6>
        <div class="p-3 bg-light rounded font-monospace fs-6">
            <?= nl2br(htmlspecialchars($receita['posologia'])) ?>
        </div>
    </div>

    <!-- Orientações -->
    <?php if (!empty($receita['orientacoes'])): ?>
    <div class="mb-4">
        <h6 class="fw-bold text-secondary border-start border-secondary border-3 ps-2">Orientações Gerais</h6>
        <p class="ps-3 text-secondary"><?= nl2br(htmlspecialchars($receita['orientacoes'])) ?></p>
    </div>
    <?php endif; ?>

    <!-- Carimbo do Médico -->
    <div class="row mt-5 pt-4 border-top">
        <div class="col-md-6 offset-md-3 text-center">
            <div class="border-top border-dark w-75 mx-auto pt-2">
                <strong class="d-block"><?= htmlspecialchars($receita['medico_nome'] ?? 'Dr. Carlos Roberto') ?></strong>
                <span class="text-muted small"><?= htmlspecialchars($receita['medico_crm'] ?? 'CRM/SP 45210') ?></span>
                <div class="text-muted small text-uppercase">Assinatura do Médico Prescritor</div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
    <div class="alert alert-warning">Receita não encontrada.</div>
<?php endif; ?>

<?php include(FOOTER_TEMPLATE); ?>
