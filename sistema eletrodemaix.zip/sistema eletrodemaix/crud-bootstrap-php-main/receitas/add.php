<?php 
require_once('function.php'); 
check_permission([ROLE_MEDICO]);
add();

$pacientes = find_all('pacientes') ?: [];
$medicamentos_disponiveis = find_all('medicamentos') ?: [];
$paciente_selecionado = $_GET['paciente_id'] ?? null;

include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-pen-nib text-info me-2"></i>Emitir Receita Médica</h2>
        <small class="text-muted"><span class="badge bg-primary">Permissão Médica</span> Prescrição farmacológica oficial e orientações ao paciente</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<form action="add.php" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <!-- Seleção do Paciente -->
        <div class="col-md-7">
            <label class="form-label fw-semibold">Paciente *</label>
            <select class="form-select" name="receita['paciente_id']" required id="selectPaciente">
                <option value="">Selecione o paciente recebedor...</option>
                <?php foreach ($pacientes as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= ($paciente_selecionado == $p['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['nome']) ?> (CPF: <?= htmlspecialchars($p['cpf']) ?>)
                        <?= !empty($p['alergias']) ? ' [ALERGIA: ' . htmlspecialchars($p['alergias']) . ']' : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-5">
            <label class="form-label fw-semibold">Validade da Receita *</label>
            <input type="date" class="form-control" name="receita['validade']" required value="<?= date('Y-m-d', strtotime('+30 days')) ?>">
            <small class="text-muted">Padrão: 30 dias para uso contínuo/antibióticos</small>
        </div>

        <!-- Prescrição de Fármacos -->
        <div class="col-12">
            <label class="form-label fw-semibold text-primary">Medicamentos Prescritos &amp; Dosagem *</label>
            <input type="text" class="form-control fw-semibold" name="receita['medicamentos']" required placeholder="Ex: Amoxicilina + Clavulanato 875mg / Paracetamol 750mg" list="listaRemedios">
            <datalist id="listaRemedios">
                <?php foreach ($medicamentos_disponiveis as $m): ?>
                    <option value="<?= htmlspecialchars($m['nome']) ?> (<?= htmlspecialchars($m['apresentacao']) ?>)">
                <?php endforeach; ?>
            </datalist>
            <small class="text-muted">Dica: Digite o nome ou selecione um medicamento disponível no estoque da farmácia.</small>
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Via de Administração</label>
            <select class="form-select" name="receita['via']">
                <option value="Uso Oral" selected>Uso Oral</option>
                <option value="Uso Tópico">Uso Tópico</option>
                <option value="Uso Inalatório">Uso Inalatório</option>
                <option value="Uso Oftálmico">Uso Oftálmico</option>
                <option value="Uso Otológico">Uso Otológico</option>
                <option value="Uso Injetável (IM/IV)">Uso Injetável (IM/IV)</option>
            </select>
        </div>

        <div class="col-md-8">
            <label class="form-label fw-semibold">Tipo de Receituário</label>
            <select class="form-select" name="receita['tipo']">
                <option value="Simples" selected>Receituário Simples (Branco)</option>
                <option value="Controle Especial (2 vias)">Controle Especial (2 vias)</option>
                <option value="Antimicrobiano (Retenção de via)">Antimicrobiano (Retenção de via)</option>
            </select>
        </div>

        <!-- Posologia Detalhada -->
        <div class="col-12">
            <label class="form-label fw-semibold text-primary">Posologia &amp; Modo de Uso *</label>
            <textarea class="form-control" name="receita['posologia']" rows="4" required placeholder="Exemplo:&#10;1) Amoxicilina 875mg: Tomar 1 comprimido por via oral a cada 12 horas durante 7 dias.&#10;2) Paracetamol 750mg: Tomar 1 comprimido a cada 6 horas se houver febre ou dor intensa."></textarea>
        </div>

        <!-- Orientações Gerais -->
        <div class="col-12">
            <label class="form-label fw-semibold">Orientações Gerais ao Paciente</label>
            <textarea class="form-control" name="receita['orientacoes']" rows="2" placeholder="Ex: Ingerir com bastante líquido após as refeições. Não interromper o tratamento antes do prazo estipulado."></textarea>
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-info text-white"><i class="fa-solid fa-stamp me-1"></i> Emitir Receita Médica</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
