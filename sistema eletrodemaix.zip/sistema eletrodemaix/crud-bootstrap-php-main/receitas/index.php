<?php
require_once('function.php');
check_permission([ROLE_MEDICO, ROLE_ENFERMEIRO]);
index();
include(HEADER_TEMPLATE);
$user = current_user();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-receipt text-info me-2"></i>Receitas Médicas Prescritas</h2>
        <small class="text-muted">Prescrições farmacológicas digitais e emissão com CRM</small>
    </div>
    <div>
        <?php if ($user['role'] === ROLE_MEDICO): ?>
            <a class="btn btn-info text-white" href="add.php"><i class="fa-solid fa-pen-nib me-1"></i> Emitir Nova Receita</a>
        <?php endif; ?>
        <a class="btn btn-outline-secondary" href="../index.php"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<div class="card border-0 shadow-sm rounded-3">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" id="tabelaReceitas">
            <thead class="table-light">
                <tr>
                    <th width="5%">ID</th>
                    <th width="12%">Data Emissão</th>
                    <th width="20%">Paciente</th>
                    <th width="25%">Prescrição (Fármacos &amp; Dosagem)</th>
                    <th width="15%">Médico Prescritor</th>
                    <th width="11%">Validade</th>
                    <th width="12%" class="text-end">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($receitas)): ?>
                    <?php foreach ($receitas as $r): ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border"><?= $r['id'] ?></span></td>
                            <td><?= date('d/m/Y', strtotime($r['created'])) ?></td>
                            <td><strong><?= htmlspecialchars($r['paciente_nome'] ?? ('Paciente #' . $r['paciente_id'])) ?></strong></td>
                            <td>
                                <strong><?= htmlspecialchars($r['medicamentos']) ?></strong>
                                <?php if (!empty($r['posologia'])): ?>
                                    <br><small class="text-muted"><?= htmlspecialchars(substr($r['posologia'], 0, 50)) ?>...</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <i class="fa-solid fa-user-doctor text-muted me-1"></i>
                                <?= htmlspecialchars($r['medico_nome'] ?? 'Dr. Carlos Roberto') ?>
                            </td>
                            <td>
                                <span class="badge bg-success-subtle text-success border border-success-subtle">
                                    Até <?= date('d/m/Y', strtotime($r['validade'])) ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <a href="view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary" title="Visualizar Receita">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <a href="imprimir.php?id=<?= $r['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="Imprimir Receituário">
                                    <i class="fa-solid fa-print"></i>
                                </a>
                                <?php if ($user['role'] === ROLE_MEDICO): ?>
                                    <a href="delete.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deseja excluir esta receita?');" title="Excluir">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">
                            <i class="fa-solid fa-receipt fa-2x mb-2 d-block"></i>
                            Nenhuma receita médica prescrita até o momento.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
