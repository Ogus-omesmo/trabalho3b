<?php
require_once('function.php');
view($_GET['id'] ?? null);

if (empty($receita)) {
    die("Receita não encontrada.");
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Receituário Médico - <?= htmlspecialchars($receita['paciente_nome'] ?? 'Paciente') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            background-color: #ffffff;
            color: #111827;
            font-family: 'Times New Roman', Times, serif, sans-serif;
            padding: 40px;
        }
        .receita-box {
            border: 2px solid #000000;
            padding: 35px;
            max-width: 800px;
            margin: 0 auto;
            position: relative;
        }
        .receita-header {
            border-bottom: 2px solid #000000;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .watermark {
            position: absolute;
            top: 45%;
            left: 50%;
            transform: translate(-50%, -50%);
            opacity: 0.05;
            font-size: 140px;
            pointer-events: none;
            z-index: 0;
        }
        .posologia-box {
            min-height: 280px;
            font-size: 1.15rem;
            line-height: 1.8;
            position: relative;
            z-index: 1;
        }
        @media print {
            body {
                padding: 0;
            }
            .no-print {
                display: none !important;
            }
            .receita-box {
                border: 2px solid #000;
            }
        }
    </style>
</head>
<body>
    <div class="no-print text-center mb-4">
        <button onclick="window.print()" class="btn btn-primary px-4 py-2 me-2">
            <i class="fa-solid fa-print me-1"></i> Imprimir Receituário
        </button>
        <button onclick="window.close()" class="btn btn-outline-secondary px-4 py-2">
            Fechar Janela
        </button>
    </div>

    <div class="receita-box">
        <div class="watermark">
            <i class="fa-solid fa-staff-snake"></i>
        </div>

        <!-- Cabeçalho Oficial -->
        <div class="receita-header d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold mb-0 text-uppercase">HOSPITAL &amp; CENTRO MÉDICO</h3>
                <small class="text-muted">Serviço de Atendimento Médico &amp; Farmacológico Especializado</small><br>
                <small class="text-muted">Av. Paulista, 1000 - Bela Vista, São Paulo/SP - Fone: (11) 3456-7890</small>
            </div>
            <div class="text-end">
                <span class="badge bg-dark text-white p-2 text-uppercase fs-6">
                    <?= htmlspecialchars($receita['tipo'] ?? 'RECEITUÁRIO MÉDICO') ?>
                </span>
                <div class="small text-muted mt-1">Via do Paciente</div>
            </div>
        </div>

        <!-- Dados do Paciente -->
        <div class="mb-4 pb-2 border-bottom">
            <div class="row">
                <div class="col-8">
                    <strong>PACIENTE:</strong> <span class="fs-5 text-uppercase"><?= htmlspecialchars($receita['paciente_nome'] ?? 'Paciente') ?></span>
                </div>
                <div class="col-4 text-end">
                    <strong>DATA:</strong> <?= date('d/m/Y', strtotime($receita['created'])) ?>
                </div>
            </div>
        </div>

        <!-- Prescrição & Posologia -->
        <div class="posologia-box mb-4">
            <h5 class="fw-bold mb-3"><i class="fa-solid fa-prescription me-2"></i>PRESCRIÇÃO TERAPÊUTICA:</h5>
            <div class="fw-bold text-dark fs-5 mb-2">
                <?= htmlspecialchars($receita['medicamentos']) ?>
            </div>
            <div style="white-space: pre-line;">
                <?= htmlspecialchars($receita['posologia']) ?>
            </div>

            <?php if (!empty($receita['orientacoes'])): ?>
                <div class="mt-4 pt-3 border-top">
                    <strong>Orientações ao paciente:</strong><br>
                    <?= nl2br(htmlspecialchars($receita['orientacoes'])) ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Validade e Carimbo -->
        <div class="row mt-5 pt-4 align-items-end">
            <div class="col-6">
                <small class="text-muted d-block">Receita válida até:</small>
                <strong class="fs-6"><?= date('d/m/Y', strtotime($receita['validade'])) ?></strong>
            </div>
            <div class="col-6 text-center">
                <div class="border-top border-dark pt-2">
                    <strong class="d-block"><?= htmlspecialchars($receita['medico_nome'] ?? 'Dr. Carlos Roberto') ?></strong>
                    <span><?= htmlspecialchars($receita['medico_crm'] ?? 'CRM/SP 45210') ?></span><br>
                    <small class="text-muted">Assinatura e Carimbo Médico</small>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
