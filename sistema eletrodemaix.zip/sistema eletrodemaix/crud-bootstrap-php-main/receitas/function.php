<?php
require_once('../config.php');
require_once(DBAPI);

$receitas = null;
$receita  = null;

/**
 * Listagem de Receitas Médicas
 */
function index() {
    global $receitas;
    $user = current_user();
    if ($user && $user['role'] === ROLE_CLIENTE) {
        // Paciente vê somente as suas
        $paciente_id = intval($user['paciente_id'] ?? 0);
        $receitas = find_where('receitas', "paciente_id = {$paciente_id}");
    } else {
        $receitas = find_all('receitas');
    }
    if (!$receitas) {
        $receitas = [];
    }
}

/**
 * Emissão de Receita Médica (Exclusivo Médico)
 */
function add() {
    check_permission([ROLE_MEDICO]);
    
    if (!empty($_POST['receita'])) {
        $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $receita = $_POST['receita'];
        
        $user = current_user();
        $receita['medico_id']   = $user['id'] ?? 1;
        $receita['medico_nome'] = $user['nome'] ?? 'Dr. Carlos Roberto';
        $receita['medico_crm']  = $user['registro'] ?? 'CRM/SP 45210';
        $receita['created']     = $today->format("Y-m-d H:i:s");
        
        // Pega o nome do paciente
        $pac = find('pacientes', $receita['paciente_id']);
        if ($pac) {
            $receita['paciente_nome'] = $pac['nome'];
        }

        save('receitas', $receita);
        header('Location: index.php');
        exit;
    }
}

/**
 * Visualização de Receita Médica
 */
function view($id = null) {
    global $receita;
    $receita = find('receitas', $id);
}

/**
 * Exclusão de Receita Médica
 */
function delete($id = null) {
    check_permission([ROLE_MEDICO]);
    if ($id) {
        remove('receitas', $id);
        header('Location: index.php');
        exit;
    }
}
