<?php
include_once 'config.php';
unset($_SESSION['user']);
session_destroy();
header('Location: ' . BASEURL . 'login.php');
exit;
