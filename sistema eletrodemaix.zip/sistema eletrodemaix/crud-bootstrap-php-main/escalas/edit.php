<?php 
require_once('function.php'); 
check_permission([ROLE_ENFERMEIRO]);
edit();
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-pen text-warning me-2"></i>Editar Escala #<?= $escala['id'] ?? '' ?></h2>
        <small class="text-muted">Ajuste de horário ou setor de plantão</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<?php if (!empty($escala)): ?>
<form action="edit.php?id=<?= $escala['id']; ?>" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label fw-semibold">Nome do Profissional *</label>
            <input type="text" class="form-control" name="escala['profissional_nome']" value="<?= htmlspecialchars($escala['profissional_nome']) ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Registro Profissional</label>
            <input type="text" class="form-control" name="escala['registro_profissional']" value="<?= htmlspecialchars($escala['registro_profissional'] ?? '') ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Cargo / Função *</label>
            <select class="form-select" name="escala['cargo']" required>
                <?php foreach (['Enfermeiro(a) Chefe', 'Enfermeiro(a) Assistencial', 'Técnico(a) de Enfermagem', 'Médico(a) Plantonista', 'Fisioterapeuta Hospitalar'] as $c): ?>
                    <option value="<?= $c ?>" <?= ($escala['cargo'] ?? '') === $c ? 'selected' : '' ?>><?= $c ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Setor Hospitalar *</label>
            <select class="form-select" name="escala['setor']" required>
                <?php foreach (['Pronto Socorro / Triagem', 'UTI Geral Adulto', 'Ala Pediátrica', 'Centro Cirúrgico', 'Maternidade & Berçário', 'Enfermaria Clínica'] as $s): ?>
                    <option value="<?= $s ?>" <?= ($escala['setor'] ?? '') === $s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Turno de Trabalho *</label>
            <select class="form-select" name="escala['turno']" required>
                <?php foreach (['Manhã (07:00 às 13:00)', 'Tarde (13:00 às 19:00)', 'Noturno (19:00 às 07:00)', 'Plantão 12x36 Diurno', 'Plantão 12x36 Noturno'] as $t): ?>
                    <option value="<?= $t ?>" <?= ($escala['turno'] ?? '') === $t ? 'selected' : '' ?>><?= $t ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Data do Plantão *</label>
            <input type="date" class="form-control" name="escala['data_plantao']" value="<?= htmlspecialchars($escala['data_plantao'] ?? '') ?>" required>
        </div>

        <div class="col-12">
            <label class="form-label fw-semibold">Observações</label>
            <textarea class="form-control" name="escala['observacoes']" rows="2"><?= htmlspecialchars($escala['observacoes'] ?? '') ?></textarea>
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-warning text-dark"><i class="fa-solid fa-save me-1"></i> Salvar Alterações</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>
<?php else: ?>
    <div class="alert alert-warning">Escala não encontrada.</div>
<?php endif; ?>

<?php include(FOOTER_TEMPLATE); ?>
