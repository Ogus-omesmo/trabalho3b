<?php
require_once('../config.php');
require_once(DBAPI);

$escalas = null;
$escala  = null;

/**
 * Listagem das Escalas de Trabalho e Plantões
 */
function index() {
    global $escalas;
    $escalas = find_all('escalas');
    if (!$escalas) {
        $escalas = [];
    }
}

/**
 * Cadastrar Novo Plantão / Escala
 */
function add() {
    if (!empty($_POST['escala'])) {
        $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $escala = $_POST['escala'];
        $escala['created'] = $today->format("Y-m-d H:i:s");
        $escala['modified'] = $today->format("Y-m-d H:i:s");
        
        save('escalas', $escala);
        header('Location: index.php');
        exit;
    }
}

/**
 * Editar Plantão / Escala
 */
function edit() {
    $now = date_create('now', new DateTimeZone('America/Sao_Paulo'));
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        if (isset($_POST['escala'])) {
            $escala = $_POST['escala'];
            $escala['modified'] = $now->format("Y-m-d H:i:s");
            update('escalas', $id, $escala);
            header('Location: index.php');
            exit;
        } else {
            global $escala;
            $escala = find('escalas', $id);
        }
    } else {
        header('Location: index.php');
        exit;
    }
}

/**
 * Exclusão de Escala
 */
function delete($id = null) {
    if ($id) {
        remove('escalas', $id);
        header('Location: index.php');
        exit;
    }
}
