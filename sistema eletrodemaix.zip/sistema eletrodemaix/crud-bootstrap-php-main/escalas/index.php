<?php
require_once('function.php');
check_permission([ROLE_ENFERMEIRO, ROLE_MEDICO]);
index();
include(HEADER_TEMPLATE);
$user = current_user();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-calendar-week text-warning me-2"></i>Escala de Trabalho &amp; Plantões</h2>
        <small class="text-muted">Distribuição de turnos, setores hospitalares e equipes assistenciais</small>
    </div>
    <div>
        <?php if ($user['role'] === ROLE_ENFERMEIRO): ?>
            <a class="btn btn-warning text-dark" href="add.php"><i class="fa-solid fa-plus me-1"></i> Nova Alocação</a>
        <?php endif; ?>
        <a class="btn btn-outline-secondary" href="../index.php"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<!-- Tabela de Escalas de Plantão -->
<div class="card border-0 shadow-sm rounded-3">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" id="tabelaEscalas">
            <thead class="table-light">
                <tr>
                    <th width="5%">ID</th>
                    <th width="20%">Profissional</th>
                    <th width="15%">Cargo / Função</th>
                    <th width="15%">Setor Hospitalar</th>
                    <th width="15%">Turno / Horário</th>
                    <th width="12%">Data</th>
                    <th width="8%">Status</th>
                    <?php if ($user['role'] === ROLE_ENFERMEIRO): ?>
                        <th width="10%" class="text-end">Ações</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($escalas)): ?>
                    <?php foreach ($escalas as $e): ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border"><?= $e['id'] ?></span></td>
                            <td>
                                <strong><?= htmlspecialchars($e['profissional_nome']) ?></strong>
                                <?php if (!empty($e['registro_profissional'])): ?>
                                    <br><small class="text-muted"><?= htmlspecialchars($e['registro_profissional']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-secondary-subtle text-secondary border"><?= htmlspecialchars($e['cargo']) ?></span></td>
                            <td>
                                <i class="fa-solid fa-hospital-user text-muted me-1"></i>
                                <?= htmlspecialchars($e['setor']) ?>
                            </td>
                            <td>
                                <span class="badge bg-info-subtle text-info border">
                                    <i class="fa-regular fa-clock me-1"></i> <?= htmlspecialchars($e['turno']) ?>
                                </span>
                            </td>
                            <td><?= !empty($e['data_plantao']) ? date('d/m/Y', strtotime($e['data_plantao'])) : '-' ?></td>
                            <td>
                                <span class="badge bg-success">Confirmado</span>
                            </td>
                            <?php if ($user['role'] === ROLE_ENFERMEIRO): ?>
                                <td class="text-end">
                                    <a href="edit.php?id=<?= $e['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Editar">
                                        <i class="fa-solid fa-pen"></i>
                                    </a>
                                    <a href="delete.php?id=<?= $e['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deseja excluir esta alocação de escala?');" title="Remover">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-muted">
                            <i class="fa-solid fa-calendar-xmark fa-2x mb-2 d-block"></i>
                            Nenhuma escala cadastrada no momento.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
