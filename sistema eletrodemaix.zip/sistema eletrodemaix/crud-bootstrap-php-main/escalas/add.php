<?php 
require_once('function.php'); 
check_permission([ROLE_ENFERMEIRO]);
add();
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-calendar-plus text-warning me-2"></i>Nova Alocação de Escala</h2>
        <small class="text-muted">Escalonamento de plantão e setor de atendimento</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<form action="add.php" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label fw-semibold">Nome do Profissional *</label>
            <input type="text" class="form-control" name="escala['profissional_nome']" required placeholder="Ex: Enfª Mariana Souza, Tec. Roberto Costa">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Registro Profissional (COREN/CRM)</label>
            <input type="text" class="form-control" name="escala['registro_profissional']" placeholder="Ex: COREN 184592">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Cargo / Função *</label>
            <select class="form-select" name="escala['cargo']" required>
                <option value="Enfermeiro(a) Chefe">Enfermeiro(a) Chefe</option>
                <option value="Enfermeiro(a) Assistencial" selected>Enfermeiro(a) Assistencial</option>
                <option value="Técnico(a) de Enfermagem">Técnico(a) de Enfermagem</option>
                <option value="Médico(a) Plantonista">Médico(a) Plantonista</option>
                <option value="Fisioterapeuta Hospitalar">Fisioterapeuta Hospitalar</option>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Setor Hospitalar *</label>
            <select class="form-select" name="escala['setor']" required>
                <option value="Pronto Socorro / Triagem">Pronto Socorro / Triagem</option>
                <option value="UTI Geral Adulto">UTI Geral Adulto</option>
                <option value="Ala Pediátrica">Ala Pediátrica</option>
                <option value="Centro Cirúrgico">Centro Cirúrgico</option>
                <option value="Maternidade &amp; Berçário">Maternidade &amp; Berçário</option>
                <option value="Enfermaria Clínica">Enfermaria Clínica</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Turno de Trabalho *</label>
            <select class="form-select" name="escala['turno']" required>
                <option value="Manhã (07:00 às 13:00)">Manhã (07:00 às 13:00)</option>
                <option value="Tarde (13:00 às 19:00)">Tarde (13:00 às 19:00)</option>
                <option value="Noturno (19:00 às 07:00)">Noturno (19:00 às 07:00)</option>
                <option value="Plantão 12x36 Diurno">Plantão 12x36 Diurno (07:00 às 19:00)</option>
                <option value="Plantão 12x36 Noturno">Plantão 12x36 Noturno (19:00 às 07:00)</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Data do Plantão *</label>
            <input type="date" class="form-control" name="escala['data_plantao']" required value="<?= date('Y-m-d') ?>">
        </div>

        <div class="col-12">
            <label class="form-label fw-semibold">Observações / Trocas de Plantão</label>
            <textarea class="form-control" name="escala['observacoes']" rows="2" placeholder="Observações de cobertura, substituição autorizada ou ramal de contato..."></textarea>
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-warning text-dark"><i class="fa-solid fa-save me-1"></i> Salvar na Escala</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
