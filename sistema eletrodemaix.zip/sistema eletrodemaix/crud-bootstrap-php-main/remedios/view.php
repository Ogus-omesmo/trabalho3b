<?php 
require_once('function.php'); 
check_permission([ROLE_ENFERMEIRO, ROLE_MEDICO]);
view($_GET['id'] ?? null);
include(HEADER_TEMPLATE); 
$user = current_user();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-pills text-success me-2"></i><?= htmlspecialchars($medicamento['nome'] ?? 'Medicamento') ?></h2>
        <small class="text-muted">Ficha técnica do fármaco e posição de estoque</small>
    </div>
    <div class="d-flex gap-2">
        <?php if ($user['role'] === ROLE_ENFERMEIRO): ?>
            <a href="edit.php?id=<?= $medicamento['id'] ?>" class="btn btn-outline-success btn-sm"><i class="fa-solid fa-pen me-1"></i> Repor / Editar</a>
        <?php endif; ?>
        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<?php if (!empty($medicamento)): ?>
    <?php 
        $estoqueBaixo = ($medicamento['quantidade'] <= ($medicamento['estoque_minimo'] ?? 15));
    ?>
    <div class="row g-4">
        <div class="col-md-8">
            <div class="card p-4 shadow-sm border-0 bg-white">
                <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-circle-info text-primary me-2"></i>Especificações Técnicas</h5>
                <dl class="row mb-0">
                    <dt class="col-sm-4 text-muted">Princípio Ativo:</dt>
                    <dd class="col-sm-8 fw-semibold"><?= htmlspecialchars($medicamento['principio_ativo'] ?? 'Não informado') ?></dd>

                    <dt class="col-sm-4 text-muted">Apresentação / Forma:</dt>
                    <dd class="col-sm-8"><?= htmlspecialchars($medicamento['apresentacao'] ?? '-') ?></dd>

                    <dt class="col-sm-4 text-muted">Via de Administração:</dt>
                    <dd class="col-sm-8"><span class="badge bg-secondary"><?= htmlspecialchars($medicamento['via'] ?? 'Oral') ?></span></dd>

                    <dt class="col-sm-4 text-muted">Fabricante:</dt>
                    <dd class="col-sm-8"><?= htmlspecialchars($medicamento['laboratorio'] ?? 'Indústria Farmacêutica') ?></dd>

                    <dt class="col-sm-4 text-muted">Indicações e Cuidados:</dt>
                    <dd class="col-sm-8 text-secondary"><?= nl2br(htmlspecialchars($medicamento['indicacao'] ?? 'Armazenar em local seco, arejado e protegido da luz solar direta.')) ?></dd>
                </dl>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card p-4 shadow-sm border-0 bg-white">
                <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-boxes-stacked text-success me-2"></i>Posição de Estoque</h5>
                
                <div class="p-3 <?= $estoqueBaixo ? 'bg-danger-subtle text-danger-emphasis' : 'bg-success-subtle text-success-emphasis' ?> rounded text-center mb-3">
                    <span class="fs-1 fw-bold"><?= $medicamento['quantidade'] ?></span>
                    <span class="d-block small text-uppercase fw-semibold">Unidades Disponíveis</span>
                </div>

                <ul class="list-group list-group-flush small">
                    <li class="list-group-item d-flex justify-content-between px-0">
                        <span>Estoque Mínimo de Alerta:</span>
                        <strong><?= $medicamento['estoque_minimo'] ?? 15 ?> un.</strong>
                    </li>
                    <li class="list-group-item d-flex justify-content-between px-0">
                        <span>Lote de Fabricação:</span>
                        <code><?= htmlspecialchars($medicamento['lote'] ?? '-') ?></code>
                    </li>
                    <li class="list-group-item d-flex justify-content-between px-0">
                        <span>Data de Validade:</span>
                        <strong><?= !empty($medicamento['validade']) ? date('d/m/Y', strtotime($medicamento['validade'])) : '-' ?></strong>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-warning">Medicamento não encontrado.</div>
<?php endif; ?>

<?php include(FOOTER_TEMPLATE); ?>
