<?php
require_once('function.php');
check_permission([ROLE_ENFERMEIRO, ROLE_MEDICO]);
index();
include(HEADER_TEMPLATE);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-pills text-success me-2"></i>Controle de Remédios &amp; Farmácia</h2>
        <small class="text-muted">Gestão de estoque hospitalar, lotes, dosagens e validade</small>
    </div>
    <div>
        <a class="btn btn-success" href="add.php"><i class="fa-solid fa-plus me-1"></i> Cadastrar Remédio</a>
        <a class="btn btn-outline-secondary" href="../index.php"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<!-- Barra de Busca -->
<div class="row mb-3">
    <div class="col-md-6">
        <div class="input-group">
            <span class="input-group-text bg-white"><i class="fa-solid fa-magnifying-glass text-muted"></i></span>
            <input type="text" id="filtroTabela" class="form-control" placeholder="Buscar por medicamento, princípio ativo ou lote...">
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-3">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" id="tabelaRemedios">
            <thead class="table-light">
                <tr>
                    <th width="5%">ID</th>
                    <th width="25%">Nome do Medicamento</th>
                    <th width="15%">Dosagem / Apresentação</th>
                    <th width="15%">Lote</th>
                    <th width="12%">Estoque</th>
                    <th width="13%">Validade</th>
                    <th width="15%" class="text-end">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($medicamentos)): ?>
                    <?php foreach ($medicamentos as $m): ?>
                        <?php 
                            $estoqueBaixo = ($m['quantidade'] <= ($m['estoque_minimo'] ?? 15));
                        ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border"><?= $m['id'] ?></span></td>
                            <td>
                                <strong class="text-dark"><?= htmlspecialchars($m['nome']) ?></strong>
                                <?php if (!empty($m['principio_ativo'])): ?>
                                    <br><small class="text-muted"><?= htmlspecialchars($m['principio_ativo']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-secondary-subtle text-dark border"><?= htmlspecialchars($m['apresentacao'] ?? 'Comprimido') ?></span></td>
                            <td><code><?= htmlspecialchars($m['lote'] ?? '-') ?></code></td>
                            <td>
                                <?php if ($estoqueBaixo): ?>
                                    <span class="badge bg-danger">
                                        <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= $m['quantidade'] ?> un. (Crítico)
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success"><?= $m['quantidade'] ?> un.</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php 
                                    $validade = !empty($m['validade']) ? date('d/m/Y', strtotime($m['validade'])) : '-';
                                    echo $validade;
                                ?>
                            </td>
                            <td class="text-end">
                                <a href="view.php?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-primary" title="Ficha do Remédio">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                                <a href="edit.php?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Repor / Editar">
                                    <i class="fa-solid fa-pen"></i>
                                </a>
                                <a href="delete.php?id=<?= $m['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deseja realmente remover este medicamento?');" title="Excluir">
                                    <i class="fa-solid fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">
                            <i class="fa-solid fa-pills fa-2x mb-2 d-block"></i>
                            Nenhum medicamento registrado no estoque da farmácia.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
