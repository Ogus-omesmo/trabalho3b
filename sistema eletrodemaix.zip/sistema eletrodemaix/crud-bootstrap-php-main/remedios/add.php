<?php 
require_once('function.php'); 
check_permission([ROLE_ENFERMEIRO]);
add();
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-plus-circle text-success me-2"></i>Cadastrar Remédio</h2>
        <small class="text-muted">Inclusão de novo medicamento no estoque hospitalar</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<form action="add.php" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label fw-semibold">Nome Comercial do Remédio *</label>
            <input type="text" class="form-control" name="medicamento['nome']" required placeholder="Ex: Amoxicilina 500mg, Dipirona Sódica">
        </div>
        <div class="col-md-6">
            <label class="form-label fw-semibold">Princípio Ativo</label>
            <input type="text" class="form-control" name="medicamento['principio_ativo']" placeholder="Ex: Amoxicilina tri-hidratada">
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Apresentação / Dosagem *</label>
            <input type="text" class="form-control" name="medicamento['apresentacao']" required placeholder="Ex: Comprimido 500mg, Ampola 2ml, Frasco 100ml">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Fabricante / Laboratório</label>
            <input type="text" class="form-control" name="medicamento['laboratorio']" placeholder="Ex: EMS, Medley, Eurofarma">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Número do Lote *</label>
            <input type="text" class="form-control" name="medicamento['lote']" required placeholder="Ex: LOTE-2026-X9">
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold">Quantidade Inicial em Estoque *</label>
            <input type="number" class="form-control" name="medicamento['quantidade']" required min="0" value="50">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Estoque Mínimo (Alerta) *</label>
            <input type="number" class="form-control" name="medicamento['estoque_minimo']" required min="1" value="15">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Data de Validade *</label>
            <input type="date" class="form-control" name="medicamento['validade']" required>
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Via de Administração</label>
            <select class="form-select" name="medicamento['via']">
                <option value="Oral">Oral (Comprimido / Xarope)</option>
                <option value="Intravenosa">Intravenosa (IV)</option>
                <option value="Intramuscular">Intramuscular (IM)</option>
                <option value="Subcutânea">Subcutânea (SC)</option>
                <option value="Tópica">Tópica (Pomada / Creme)</option>
                <option value="Inalatória">Inalatória</option>
            </select>
        </div>

        <div class="col-12">
            <label class="form-label fw-semibold">Indicação Terapêutica &amp; Recomendações de Armazenamento</label>
            <textarea class="form-control" name="medicamento['indicacao']" rows="3" placeholder="Informações de armazenamento (temperatura ambiente, refrigerado), contraindicações..."></textarea>
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-success"><i class="fa-solid fa-save me-1"></i> Cadastrar Medicamento</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
