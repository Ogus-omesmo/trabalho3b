<?php
require_once('../config.php');
require_once(DBAPI);

$medicamentos = null;
$medicamento  = null;

/**
 * Listagem de Medicamentos / Remédios
 */
function index() {
    global $medicamentos;
    $medicamentos = find_all('medicamentos');
    if (!$medicamentos) {
        $medicamentos = [];
    }
}

/**
 * Cadastro de Remédio
 */
function add() {
    if (!empty($_POST['medicamento'])) {
        $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $medicamento = $_POST['medicamento'];
        $medicamento['created'] = $today->format("Y-m-d H:i:s");
        $medicamento['modified'] = $today->format("Y-m-d H:i:s");
        
        save('medicamentos', $medicamento);
        header('Location: index.php');
        exit;
    }
}

/**
 * Edição / Reposição de Estoque de Remédio
 */
function edit() {
    $now = date_create('now', new DateTimeZone('America/Sao_Paulo'));
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        if (isset($_POST['medicamento'])) {
            $medicamento = $_POST['medicamento'];
            $medicamento['modified'] = $now->format("Y-m-d H:i:s");
            update('medicamentos', $id, $medicamento);
            header('Location: index.php');
            exit;
        } else {
            global $medicamento;
            $medicamento = find('medicamentos', $id);
        }
    } else {
        header('Location: index.php');
        exit;
    }
}

/**
 * Visualização de Detalhes do Medicamento
 */
function view($id = null) {
    global $medicamento;
    $medicamento = find('medicamentos', $id);
}

/**
 * Exclusão de Medicamento
 */
function delete($id = null) {
    if ($id) {
        remove('medicamentos', $id);
        header('Location: index.php');
        exit;
    }
}
