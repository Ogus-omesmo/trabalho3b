<?php 
require_once('function.php'); 
check_permission([ROLE_ENFERMEIRO]);
edit();
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-pen text-success me-2"></i>Atualizar Remédio #<?= $medicamento['id'] ?? '' ?></h2>
        <small class="text-muted">Ajuste de estoque, lote ou dosagem do fármaco</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<?php if (!empty($medicamento)): ?>
<form action="edit.php?id=<?= $medicamento['id']; ?>" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label fw-semibold">Nome Comercial do Remédio *</label>
            <input type="text" class="form-control" name="medicamento['nome']" value="<?= htmlspecialchars($medicamento['nome']) ?>" required>
        </div>
        <div class="col-md-6">
            <label class="form-label fw-semibold">Princípio Ativo</label>
            <input type="text" class="form-control" name="medicamento['principio_ativo']" value="<?= htmlspecialchars($medicamento['principio_ativo'] ?? '') ?>">
        </div>

        <div class="col-md-4">
            <label class="form-label fw-semibold">Apresentação / Dosagem *</label>
            <input type="text" class="form-control" name="medicamento['apresentacao']" value="<?= htmlspecialchars($medicamento['apresentacao'] ?? '') ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Fabricante / Laboratório</label>
            <input type="text" class="form-control" name="medicamento['laboratorio']" value="<?= htmlspecialchars($medicamento['laboratorio'] ?? '') ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Número do Lote *</label>
            <input type="text" class="form-control" name="medicamento['lote']" value="<?= htmlspecialchars($medicamento['lote'] ?? '') ?>" required>
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold text-primary">Quantidade em Estoque *</label>
            <input type="number" class="form-control fw-bold fs-5" name="medicamento['quantidade']" value="<?= intval($medicamento['quantidade']) ?>" required min="0">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Estoque Mínimo (Alerta) *</label>
            <input type="number" class="form-control" name="medicamento['estoque_minimo']" value="<?= intval($medicamento['estoque_minimo'] ?? 15) ?>" required min="1">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Data de Validade *</label>
            <input type="date" class="form-control" name="medicamento['validade']" value="<?= htmlspecialchars($medicamento['validade'] ?? '') ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label fw-semibold">Via de Administração</label>
            <select class="form-select" name="medicamento['via']">
                <?php foreach (['Oral', 'Intravenosa', 'Intramuscular', 'Subcutânea', 'Tópica', 'Inalatória'] as $v): ?>
                    <option value="<?= $v ?>" <?= ($medicamento['via'] ?? '') === $v ? 'selected' : '' ?>><?= $v ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12">
            <label class="form-label fw-semibold">Indicação Terapêutica &amp; Recomendações</label>
            <textarea class="form-control" name="medicamento['indicacao']" rows="3"><?= htmlspecialchars($medicamento['indicacao'] ?? '') ?></textarea>
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-success"><i class="fa-solid fa-save me-1"></i> Salvar Alterações</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>
<?php else: ?>
    <div class="alert alert-warning">Medicamento não encontrado.</div>
<?php endif; ?>

<?php include(FOOTER_TEMPLATE); ?>
