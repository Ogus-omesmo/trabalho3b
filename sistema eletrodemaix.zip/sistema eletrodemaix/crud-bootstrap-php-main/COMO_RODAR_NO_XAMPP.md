# Como Rodar o Sistema no XAMPP (PHP + MySQL CRUD)

1. Inicie o Apache e MySQL no XAMPP Control Panel.
2. Copie esta pasta para `C:\xampp\htdocs\hospital`
3. Importe o arquivo `sistema_hospitalar_xampp.sql` no phpMyAdmin (`http://localhost/phpmyadmin`)
4. Acesse `http://localhost/hospital` no navegador

### Usuários e Senhas:
- Médico: `DR. Gustavo` | Senha: `2108`
- Atendente: `Mirella` | Senha: `3107`
