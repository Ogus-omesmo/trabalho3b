# MedControl - Sistema Médico Hospitalar (PHP, JS, CSS & HTML)

Sistema completo com controle de acesso para **3 tipos de usuários**:
1. **Médico**: Emissão de Diagnósticos (CID-10), Prescrição de Receitas Médicas, Consulta de Prontuários e Agendamentos.
2. **Enfermeiro**: Controle de Remédios/Estoque de Farmácia, Gestão de Escala de Trabalho/Plantões, e Pacientes/Triagem.
3. **Cliente / Paciente**: Visualização exclusiva do seu próprio histórico (diagnósticos e receitas ativas) e agendamentos personalizados.

---

## 🚀 Como Executar com XAMPP / WAMP / Apache

1. **Copie a pasta** `crud-bootstrap-php-main` para dentro do diretório `htdocs` (no XAMPP) ou `www` (no WAMP).
   Exemplo: `C:\xampp\htdocs\crud-bootstrap-php-main\`

2. **Inicie os serviços do Apache e MySQL** no painel de controle do XAMPP/WAMP.

3. **Criar e importar o Banco de Dados:**
   - Acesse o phpMyAdmin: `http://localhost/phpmyadmin/`
   - Clique em **Importar** e selecione o arquivo `sistema_medico.sql`.
   - Clique em **Executar**. O banco de dados `sistema_medico` será criado com todas as tabelas e dados de teste.

4. **Acesse no navegador:**
   - URL: `http://localhost/crud-bootstrap-php-main/`

---

## ⚡ Como Executar com o Servidor Embutido do PHP

Caso tenha o PHP instalado no seu terminal:

```bash
cd crud-bootstrap-php-main
php -S localhost:8000
```
Depois abra `http://localhost:8000` no seu navegador!

---

## 👥 Contas de Teste Integradas:
- **Médico:** Dr. Carlos Roberto (CRM/SP 45210)
- **Enfermeira:** Enfª Mariana Souza (COREN/SP 184592)
- **Cliente/Paciente:** Ana Clara Lima (CPF 123.456.789-00)
