<?php
if (!defined('BASEURL')) {
    include_once dirname(__DIR__) . '/config.php';
}
if (!function_exists('current_user')) {
    include_once DBAPI;
}
$currentUser = current_user();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>MedControl - Sistema Médico Hospitalar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Sistema Integrado de Gestão Médica, Enfermagem e Portal do Paciente">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo BASEURL; ?>css/style.css">

    <style>
        :root {
            --med-primary: #0284c7;
            --med-secondary: #0f766e;
            --med-dark: #0f172a;
        }
        body {
            padding-top: 75px;
            padding-bottom: 50px;
            background-color: #f8fafc;
            color: #1e293b;
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        }
        .navbar-med {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .badge-role-medico {
            background-color: #0284c7;
            color: #ffffff;
        }
        .badge-role-enfermeiro {
            background-color: #059669;
            color: #ffffff;
        }
        .badge-role-cliente {
            background-color: #7c3aed;
            color: #ffffff;
        }
        .card-custom {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }
        .card-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08);
        }
    </style>
</head>

<body>
    <!-- Barra de Navegação Superior Responsiva -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-med fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-white" href="<?php echo BASEURL; ?>index.php">
                <i class="fa-solid fa-hospital-user text-info fs-4"></i>
                <span>MedControl</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMedSystem"
                aria-controls="navbarMedSystem" aria-expanded="false" aria-label="Alternar navegação">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMedSystem">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASEURL; ?>index.php">
                            <i class="fa-solid fa-chart-line"></i> Início
                        </a>
                    </li>

                    <?php if ($currentUser && $currentUser['role'] === ROLE_MEDICO): ?>
                        <!-- Menu do Médico -->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASEURL; ?>pacientes/">
                                <i class="fa-solid fa-user-injured"></i> Pacientes
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-info" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-stethoscope"></i> Diagnósticos
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>diagnosticos/add.php"><i class="fa-solid fa-plus-circle text-primary me-2"></i>Emitir Novo Diagnóstico</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>diagnosticos/"><i class="fa-solid fa-file-medical text-secondary me-2"></i>Histórico de Diagnósticos</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-info" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-prescription"></i> Receitas
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>receitas/add.php"><i class="fa-solid fa-pen-nib text-primary me-2"></i>Emitir Nova Receita</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>receitas/"><i class="fa-solid fa-receipt text-secondary me-2"></i>Receitas Emitidas</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASEURL; ?>agendamentos/">
                                <i class="fa-solid fa-calendar-check"></i> Consultas
                            </a>
                        </li>

                    <?php elseif ($currentUser && $currentUser['role'] === ROLE_ENFERMEIRO): ?>
                        <!-- Menu do Enfermeiro -->
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="<?php echo BASEURL; ?>remedios/">
                                <i class="fa-solid fa-pills"></i> Remédios & Estoque
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="<?php echo BASEURL; ?>escalas/">
                                <i class="fa-solid fa-calendar-week"></i> Escala de Trabalho
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASEURL; ?>pacientes/">
                                <i class="fa-solid fa-user-injured"></i> Pacientes & Triagem
                            </a>
                        </li>

                    <?php elseif ($currentUser && $currentUser['role'] === ROLE_CLIENTE): ?>
                        <!-- Menu do Cliente / Paciente -->
                        <li class="nav-item">
                            <a class="nav-link text-info" href="<?php echo BASEURL; ?>meu-historico/">
                                <i class="fa-solid fa-clock-rotate-left"></i> Meu Histórico Médico
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASEURL; ?>agendamentos/">
                                <i class="fa-solid fa-calendar-alt"></i> Meus Agendamentos
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

                <!-- Dropdown de Usuário e Troca Rápida de Perfil -->
                <ul class="navbar-nav ms-auto align-items-lg-center gap-2">
                    <?php if ($currentUser): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center gap-2 p-1 px-2 rounded bg-dark border border-secondary" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-circle-user fs-5 text-info"></i>
                                <span class="d-none d-md-inline fw-semibold text-light"><?php echo htmlspecialchars($currentUser['nome']); ?></span>
                                <span class="badge badge-role-<?php echo $currentUser['role']; ?> text-uppercase px-2 py-1">
                                    <?php echo $currentUser['role']; ?>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow">
                                <li class="dropdown-header text-muted small">MUDAR PERFIL DE TESTE</li>
                                <li>
                                    <a class="dropdown-item d-flex align-items-center gap-2 <?php echo $currentUser['role'] === ROLE_MEDICO ? 'active' : ''; ?>" href="<?php echo BASEURL; ?>login.php?switch=medico">
                                        <i class="fa-solid fa-user-doctor text-primary"></i>
                                        <div>
                                            <div class="fw-semibold">Dr. Carlos Roberto</div>
                                            <small class="text-muted">Médico (Receitas e Diagnósticos)</small>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item d-flex align-items-center gap-2 <?php echo $currentUser['role'] === ROLE_ENFERMEIRO ? 'active' : ''; ?>" href="<?php echo BASEURL; ?>login.php?switch=enfermeiro">
                                        <i class="fa-solid fa-user-nurse text-success"></i>
                                        <div>
                                            <div class="fw-semibold">Enfª Mariana Souza</div>
                                            <small class="text-muted">Enfermeira (Remédios, Escalas, Triagem)</small>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item d-flex align-items-center gap-2 <?php echo $currentUser['role'] === ROLE_CLIENTE ? 'active' : ''; ?>" href="<?php echo BASEURL; ?>login.php?switch=cliente">
                                        <i class="fa-solid fa-hospital-user text-purple"></i>
                                        <div>
                                            <div class="fw-semibold">Ana Clara Lima</div>
                                            <small class="text-muted">Cliente / Paciente (Histórico e Consultas)</small>
                                        </div>
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="<?php echo BASEURL; ?>logout.php">
                                        <i class="fa-solid fa-arrow-right-from-bracket me-2"></i> Encerrar Sessão
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-outline-info btn-sm" href="<?php echo BASEURL; ?>login.php">
                                <i class="fa-solid fa-right-to-bracket me-1"></i> Acessar Sistema
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Conteúdo Principal -->
    <main class="container my-4">
        <!-- Alertas do Sistema -->
        <?php if (!empty($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['type'] ?? 'info'; ?> alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa-solid fa-circle-info me-2"></i>
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['message'], $_SESSION['type']); ?>
        <?php endif; ?>
