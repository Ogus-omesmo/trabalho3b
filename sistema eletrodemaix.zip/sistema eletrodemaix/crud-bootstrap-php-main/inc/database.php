<?php
/**
 * Funções de Banco de Dados e Controle de Acesso (RBAC)
 * Sistema Médico Hospitalar
 */

$mysqli = new mysqli_driver();
$mysqli->report_mode = MYSQLI_REPORT_STRICT | MYSQLI_REPORT_ERROR;

function open_database()
{
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (Exception $e) {
        throw new Exception("Erro ao conectar no banco de dados: " . $e->getMessage());
    }
}

function close_database($conn)
{
    try {
        if ($conn) {
            $conn->close();
        }
    } catch (Exception $e) {
        // Silencia erro ao fechar
    }
}

/**
 * Pesquisa um registro pelo ID ou retorna todos da tabela
 */
function find($table = null, $id = null)
{
    $found = null;
    try {
        $database = open_database();
        if ($id) {
            $id = intval($id);
            $sql = "SELECT * FROM {$table} WHERE id = {$id}";
            $result = $database->query($sql);
            if ($result && $result->num_rows > 0) {
                $found = $result->fetch_assoc();
            }
        } else {
            $sql = "SELECT * FROM {$table}";
            $result = $database->query($sql);
            if ($result && $result->num_rows > 0) {
                $found = $result->fetch_all(MYSQLI_ASSOC);
            }
        }
        close_database($database);
    } catch (Exception $e) {
        $_SESSION['message'] = $e->getMessage();
        $_SESSION['type'] = 'danger';
    }
    return $found;
}

function find_all($table)
{
    return find($table);
}

/**
 * Filtra registros de uma tabela com clausula WHERE
 */
function find_where($table, $where_clause, $order_by = 'id DESC')
{
    $found = [];
    try {
        $database = open_database();
        $sql = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY {$order_by}";
        $result = $database->query($sql);
        if ($result && $result->num_rows > 0) {
            $found = $result->fetch_all(MYSQLI_ASSOC);
        }
        close_database($database);
    } catch (Exception $e) {
        $_SESSION['message'] = $e->getMessage();
        $_SESSION['type'] = 'danger';
    }
    return $found;
}

/**
 * Insere um registro no banco de dados
 */
function save($table = null, $data = null)
{
    try {
        $database = open_database();
        $columns = [];
        $values = [];

        foreach ($data as $key => $value) {
            $col = trim($key, "'` ");
            $columns[] = "`{$col}`";
            $escaped = $database->real_escape_string($value);
            $values[] = "'{$escaped}'";
        }

        $cols_sql = implode(',', $columns);
        $vals_sql = implode(',', $values);
        $sql = "INSERT INTO {$table} ({$cols_sql}) VALUES ({$vals_sql})";
        
        $database->query($sql);
        $insert_id = $database->insert_id;
        close_database($database);

        $_SESSION['message'] = 'Registro cadastrado com sucesso!';
        $_SESSION['type'] = 'success';
        return $insert_id;
    } catch (Exception $e) {
        $_SESSION['message'] = 'Não foi possível realizar a operação: ' . $e->getMessage();
        $_SESSION['type'] = 'danger';
        return false;
    }
}

/**
 * Atualiza um registro no banco de dados
 */
function update($table = null, $id = 0, $data = null)
{
    try {
        $database = open_database();
        $items = [];
        $id = intval($id);

        foreach ($data as $key => $value) {
            $col = trim($key, "'` ");
            $escaped = $database->real_escape_string($value);
            $items[] = "`{$col}` = '{$escaped}'";
        }

        $items_sql = implode(',', $items);
        $sql = "UPDATE {$table} SET {$items_sql} WHERE id = {$id}";

        $database->query($sql);
        close_database($database);

        $_SESSION['message'] = 'Registro atualizado com sucesso!';
        $_SESSION['type'] = 'success';
        return true;
    } catch (Exception $e) {
        $_SESSION['message'] = 'Não foi possível atualizar o registro: ' . $e->getMessage();
        $_SESSION['type'] = 'danger';
        return false;
    }
}

/**
 * Remove um registro da tabela
 */
function remove($table = null, $id = null)
{
    try {
        $database = open_database();
        $id = intval($id);
        if ($id) {
            $sql = "DELETE FROM {$table} WHERE id = {$id}";
            $database->query($sql);
            $_SESSION['message'] = 'Registro excluído com sucesso!';
            $_SESSION['type'] = 'success';
        }
        close_database($database);
        return true;
    } catch (Exception $e) {
        $_SESSION['message'] = $e->getMessage();
        $_SESSION['type'] = 'danger';
        return false;
    }
}

/* ==============================================================
   CONTROLE DE ACESSO E PERMISSÕES (RBAC - MÉDICO, ENFERMEIRO, CLIENTE)
   ============================================================== */

/**
 * Retorna os dados do usuário atualmente conectado
 */
function current_user()
{
    return $_SESSION['user'] ?? null;
}

/**
 * Verifica se o usuário possui algum dos perfis permitidos
 * Caso não possua, bloqueia o acesso e redireciona
 */
function check_permission($allowed_roles = [])
{
    $user = current_user();
    if (!$user) {
        header('Location: ' . BASEURL . 'login.php');
        exit;
    }

    if (!is_array($allowed_roles)) {
        $allowed_roles = [$allowed_roles];
    }

    if (!in_array($user['role'], $allowed_roles)) {
        $_SESSION['message'] = 'Acesso não autorizado para o seu perfil (' . ucfirst($user['role']) . ').';
        $_SESSION['type'] = 'warning';
        header('Location: ' . BASEURL . 'index.php');
        exit;
    }
}

/**
 * Helper para checar se o usuário atual tem determinada role (sem redirecionar)
 */
function has_role($role)
{
    $user = current_user();
    return $user && $user['role'] === $role;
}
