    </main>

    <!-- Rodapé -->
    <footer class="text-center py-4 text-muted border-top mt-5 bg-white">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-between align-items-center">
                <span class="small">&copy; <?php echo date('Y'); ?> MedControl - Sistema Médico Hospitalar</span>
                <span class="badge bg-light text-secondary border">PHP, JS, CSS &amp; HTML</span>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle e jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASEURL; ?>js/main.js"></script>
</body>
</html>
