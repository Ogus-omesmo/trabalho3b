<?php
// Redireciona para o novo módulo de pacientes
header("Location: ../pacientes/");
exit;
