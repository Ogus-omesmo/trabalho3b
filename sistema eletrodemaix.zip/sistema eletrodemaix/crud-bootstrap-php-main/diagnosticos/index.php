<?php
require_once('function.php');
check_permission([ROLE_MEDICO, ROLE_ENFERMEIRO]);
index();
include(HEADER_TEMPLATE);
$user = current_user();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-stethoscope text-primary me-2"></i>Diagnósticos &amp; Prontuários</h2>
        <small class="text-muted">Registro de laudos clínicos, CID-10 e conduta médica</small>
    </div>
    <div>
        <?php if ($user['role'] === ROLE_MEDICO): ?>
            <a class="btn btn-primary" href="add.php"><i class="fa-solid fa-plus-circle me-1"></i> Emitir Novo Diagnóstico</a>
        <?php endif; ?>
        <a class="btn btn-outline-secondary" href="../index.php"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<div class="card border-0 shadow-sm rounded-3">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0" id="tabelaDiagnosticos">
            <thead class="table-light">
                <tr>
                    <th width="5%">ID</th>
                    <th width="12%">Data</th>
                    <th width="20%">Paciente</th>
                    <th width="13%">CID-10</th>
                    <th width="22%">Hipótese / Diagnóstico</th>
                    <th width="16%">Médico</th>
                    <th width="12%" class="text-end">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($diagnosticos)): ?>
                    <?php foreach ($diagnosticos as $d): ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border"><?= $d['id'] ?></span></td>
                            <td><?= date('d/m/Y H:i', strtotime($d['created'])) ?></td>
                            <td><strong><?= htmlspecialchars($d['paciente_nome'] ?? ('Paciente #' . $d['paciente_id'])) ?></strong></td>
                            <td><span class="badge bg-primary-subtle text-primary border border-primary-subtle"><?= htmlspecialchars($d['cid10']) ?></span></td>
                            <td><?= htmlspecialchars($d['titulo']) ?></td>
                            <td>
                                <i class="fa-solid fa-user-doctor text-muted me-1"></i>
                                <?= htmlspecialchars($d['medico_nome'] ?? 'Dr. Carlos') ?>
                            </td>
                            <td class="text-end">
                                <a href="view.php?id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-primary" title="Ver Laudo Completo">
                                    <i class="fa-solid fa-eye"></i> Ver
                                </a>
                                <?php if ($user['role'] === ROLE_MEDICO): ?>
                                    <a href="delete.php?id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Deseja excluir este diagnóstico?');" title="Excluir">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">
                            <i class="fa-solid fa-file-medical fa-2x mb-2 d-block"></i>
                            Nenhum diagnóstico emitido ainda.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
