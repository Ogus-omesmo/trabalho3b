<?php 
require_once('function.php'); 
view($_GET['id'] ?? null);
include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-file-medical text-primary me-2"></i>Laudo Diagnóstico #<?= $diagnostico['id'] ?? '' ?></h2>
        <small class="text-muted">Documento clínico de atendimento médico</small>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-print me-1"></i> Imprimir Laudo</button>
        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
    </div>
</div>

<hr>

<?php if (!empty($diagnostico)): ?>
<div class="card p-4 shadow-sm border-0 bg-white">
    <div class="border-bottom pb-3 mb-4 d-flex justify-content-between align-items-center">
        <div>
            <h4 class="fw-bold mb-1 text-primary"><?= htmlspecialchars($diagnostico['titulo']) ?></h4>
            <span class="badge bg-primary fs-6"><?= htmlspecialchars($diagnostico['cid10']) ?></span>
            <span class="badge bg-secondary ms-1">Prioridade: <?= htmlspecialchars($diagnostico['prioridade'] ?? 'Normal') ?></span>
        </div>
        <div class="text-end text-muted small">
            <div>Data do Atendimento: <strong><?= date('d/m/Y H:i', strtotime($diagnostico['created'])) ?></strong></div>
            <div>Registro Clínico ID: #<?= $diagnostico['id'] ?></div>
        </div>
    </div>

    <!-- Identificação do Paciente -->
    <div class="bg-light p-3 rounded mb-4">
        <h6 class="text-uppercase text-muted small fw-bold mb-2">Identificação do Paciente</h6>
        <div class="row">
            <div class="col-md-6">
                <strong>Nome:</strong> <?= htmlspecialchars($diagnostico['paciente_nome'] ?? ('Paciente #' . $diagnostico['paciente_id'])) ?>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="../pacientes/view.php?id=<?= $diagnostico['paciente_id'] ?>" class="btn btn-sm btn-outline-primary">
                    <i class="fa-solid fa-id-card me-1"></i> Ver Prontuário Geral
                </a>
            </div>
        </div>
    </div>

    <!-- Seções Clínicas -->
    <div class="mb-4">
        <h6 class="fw-bold text-dark border-start border-primary border-3 ps-2">Anamnese &amp; Queixa Principal</h6>
        <p class="text-secondary ps-3"><?= nl2br(htmlspecialchars($diagnostico['anamnese'])) ?></p>
    </div>

    <?php if (!empty($diagnostico['exame_fisico'])): ?>
    <div class="mb-4">
        <h6 class="fw-bold text-dark border-start border-info border-3 ps-2">Exame Físico &amp; Achados Clínicos</h6>
        <p class="text-secondary ps-3"><?= nl2br(htmlspecialchars($diagnostico['exame_fisico'])) ?></p>
    </div>
    <?php endif; ?>

    <div class="mb-4 p-3 bg-primary-subtle rounded">
        <h6 class="fw-bold text-primary mb-2"><i class="fa-solid fa-clipboard-check me-2"></i>Conduta Médica &amp; Plano Terapêutico</h6>
        <p class="mb-0 text-dark"><?= nl2br(htmlspecialchars($diagnostico['conduta'])) ?></p>
    </div>

    <!-- Assinatura Médica -->
    <div class="row mt-5 pt-4 border-top">
        <div class="col-md-6 offset-md-3 text-center">
            <div class="border-top border-dark w-75 mx-auto pt-2">
                <strong class="d-block"><?= htmlspecialchars($diagnostico['medico_nome'] ?? 'Dr. Carlos Roberto') ?></strong>
                <span class="text-muted small"><?= htmlspecialchars($diagnostico['medico_crm'] ?? 'CRM/SP 45210') ?></span>
                <div class="text-muted small text-uppercase">Assinatura Digital Médica Validada</div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
    <div class="alert alert-warning">Diagnóstico não encontrado.</div>
<?php endif; ?>

<?php include(FOOTER_TEMPLATE); ?>
