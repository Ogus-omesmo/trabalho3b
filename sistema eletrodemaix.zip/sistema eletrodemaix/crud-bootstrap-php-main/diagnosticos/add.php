<?php 
require_once('function.php'); 
check_permission([ROLE_MEDICO]);
add();

$pacientes = find_all('pacientes') ?: [];
$paciente_selecionado = $_GET['paciente_id'] ?? null;

include(HEADER_TEMPLATE); 
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="fw-bold mb-0"><i class="fa-solid fa-stethoscope text-primary me-2"></i>Emitir Diagnóstico Clínico</h2>
        <small class="text-muted"><span class="badge bg-primary">Permissão Médica</span> Registro de prontuário, CID-10 e conduta terapêutica</small>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Voltar</a>
</div>

<hr>

<form action="add.php" method="post" class="card p-4 shadow-sm border-0 bg-white">
    <div class="row g-3">
        <!-- Seleção do Paciente -->
        <div class="col-md-6">
            <label class="form-label fw-semibold">Paciente *</label>
            <select class="form-select" name="diagnostico['paciente_id']" required>
                <option value="">Selecione o paciente...</option>
                <?php foreach ($pacientes as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= ($paciente_selecionado == $p['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['nome']) ?> (CPF: <?= htmlspecialchars($p['cpf']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Código CID-10 -->
        <div class="col-md-3">
            <label class="form-label fw-semibold">Código CID-10 *</label>
            <input type="text" class="form-control" name="diagnostico['cid10']" required placeholder="Ex: J06.9, I10, E11.9" list="cidList">
            <datalist id="cidList">
                <option value="J06.9 - Infecção aguda das vias aéreas superiores">
                <option value="I10 - Hipertensão arterial essencial">
                <option value="E11 - Diabetes mellitus não-insulino-dependente">
                <option value="M54.5 - Dor lombar baixa (Lumbago)">
                <option value="K29.7 - Gastrite não especificada">
                <option value="B34.9 - Infecção viral não especificada">
                <option value="R51 - Cefaleia">
                <option value="J20.9 - Bronquite aguda não especificada">
            </datalist>
        </div>

        <div class="col-md-3">
            <label class="form-label fw-semibold">Gravidade / Prioridade</label>
            <select class="form-select" name="diagnostico['prioridade']">
                <option value="Baixa">Baixa (Ambulatorial)</option>
                <option value="Moderada" selected>Moderada</option>
                <option value="Alta">Alta (Acompanhamento Urgente)</option>
            </select>
        </div>

        <!-- Título do Diagnóstico -->
        <div class="col-12">
            <label class="form-label fw-semibold">Hipótese Diagnóstica / Título Clínico *</label>
            <input type="text" class="form-control" name="diagnostico['titulo']" required placeholder="Ex: Faringoamigdalite bacteriana aguda, Crise hipertensiva controlada">
        </div>

        <!-- Anamnese e Sintomas -->
        <div class="col-md-6">
            <label class="form-label fw-semibold">Anamnese &amp; Queixa Principal *</label>
            <textarea class="form-control" name="diagnostico['anamnese']" rows="4" required placeholder="Relato do paciente: início dos sintomas, intensidade da dor, febre, tosse, duração do quadro..."></textarea>
        </div>

        <!-- Exame Físico -->
        <div class="col-md-6">
            <label class="form-label fw-semibold">Exame Físico &amp; Achados Clínicos</label>
            <textarea class="form-control" name="diagnostico['exame_fisico']" rows="4" placeholder="Oroscopia com hiperemia, ausculta pulmonar limpa, murmúrio vesicular presente, sem ruídos adventícios..."></textarea>
        </div>

        <!-- Conduta e Recomendações -->
        <div class="col-12">
            <label class="form-label fw-semibold text-primary">Conduta Médica, Orientações &amp; Plano Terapêutico *</label>
            <textarea class="form-control" name="diagnostico['conduta']" rows="3" required placeholder="Prescrito repouso de 3 dias, hidratação abundante, medicação sintomática. Retorno em caso de piora ou febre persistente."></textarea>
        </div>

        <div class="col-12 mt-4 pt-3 border-top d-flex gap-2">
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-stamp me-1"></i> Emitir e Assinar Diagnóstico</button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
