<?php
require_once('../config.php');
require_once(DBAPI);

$diagnosticos = null;
$diagnostico  = null;

/**
 * Listagem de Diagnósticos
 */
function index() {
    global $diagnosticos;
    $user = current_user();
    if ($user && $user['role'] === ROLE_CLIENTE) {
        // Cliente vê apenas os seus
        $paciente_id = intval($user['paciente_id'] ?? 0);
        $diagnosticos = find_where('diagnosticos', "paciente_id = {$paciente_id}");
    } else {
        $diagnosticos = find_all('diagnosticos');
    }
    if (!$diagnosticos) {
        $diagnosticos = [];
    }
}

/**
 * Emissão de Diagnóstico (Exclusivo Médico)
 */
function add() {
    check_permission([ROLE_MEDICO]);
    
    if (!empty($_POST['diagnostico'])) {
        $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $diagnostico = $_POST['diagnostico'];
        
        $user = current_user();
        $diagnostico['medico_id']   = $user['id'] ?? 1;
        $diagnostico['medico_nome'] = $user['nome'] ?? 'Dr. Carlos Roberto';
        $diagnostico['medico_crm']  = $user['registro'] ?? 'CRM/SP 45210';
        $diagnostico['created']     = $today->format("Y-m-d H:i:s");
        
        // Pega o nome do paciente pelo ID
        $pac = find('pacientes', $diagnostico['paciente_id']);
        if ($pac) {
            $diagnostico['paciente_nome'] = $pac['nome'];
        }

        save('diagnosticos', $diagnostico);
        header('Location: index.php');
        exit;
    }
}

/**
 * Visualização de Laudo de Diagnóstico
 */
function view($id = null) {
    global $diagnostico;
    $diagnostico = find('diagnosticos', $id);
}

/**
 * Exclusão de Diagnóstico
 */
function delete($id = null) {
    check_permission([ROLE_MEDICO]);
    if ($id) {
        remove('diagnosticos', $id);
        header('Location: index.php');
        exit;
    }
}
