/**
 * MedControl - Sistema Médico Hospitalar
 * Scripts JavaScript auxiliares (Filtro dinâmico, máscaras e utilitários)
 */

$(document).ready(function() {
    // Filtro de busca dinâmica em tabelas
    $("#filtroTabela").on("keyup", function() {
        var valor = $(this).val().toLowerCase();
        $("table tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(valor) > -1);
        });
    });

    // Auto-fechamento de alertas após 5 segundos
    setTimeout(function() {
        $(".alert-dismissible").fadeOut('slow');
    }, 5000);

    // Suporte a impressão via tecla de atalho Ctrl+P nas receitas
    $(document).keydown(function(e) {
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 80 && window.location.href.indexOf('imprimir') > -1) {
            window.print();
        }
    });

    // Ativação de abas por hash da URL (ex: #receitas)
    var hash = window.location.hash;
    if (hash) {
        $('.nav-tabs button[data-bs-target="' + hash + '"]').tab('show');
    }
});
