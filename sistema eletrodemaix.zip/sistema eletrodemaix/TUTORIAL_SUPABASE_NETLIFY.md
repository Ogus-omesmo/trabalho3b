# Tutorial Completo: Conectando o Sistema ao Supabase (PostgreSQL) e Publicando no Netlify

Este guia ensina, passo a passo e de forma descomplicada, como hospedar este sistema no **Netlify** e conectar a um banco de dados real no **Supabase** via SQL.

---

## 📌 Visão Geral da Arquitetura
* **Frontend:** Aplicação React + Vite (HTML/CSS/TypeScript) com build estático e rápido, hospedada no **Netlify**.
* **Banco de Dados:** **Supabase** (PostgreSQL na nuvem), acessado diretamente pelo SDK oficial `@supabase/supabase-js` com segurança por chaves anônimas e políticas RLS (Row Level Security).

---

## 🚀 PASSO 1: Criar a Conta e o Projeto no Supabase
1. Acesse: [https://supabase.com](https://supabase.com) e clique em **"Start your project"** (é gratuito).
2. Faça login com o seu GitHub ou crie uma conta com e-mail e senha.
3. Clique em **"New project"** (Novo projeto).
4. Preencha as informações:
   * **Name (Nome):** `eletronicos-demais-db` (ou o nome que desejar)
   * **Database Password:** Crie uma senha forte e anote-a.
   * **Region:** Selecione a região mais próxima do Brasil (ex: `São Paulo (sa-east-1)`).
   * **Pricing Plan:** Selecione o plano **Free** (Gratuito).
5. Clique em **"Create new project"** e aguarde cerca de 1 a 2 minutos enquanto o Supabase prepara o banco.

---

## 🗄️ PASSO 2: Criar as Tabelas SQL no Supabase
No menu lateral esquerdo do Supabase:
1. Clique no ícone do **"SQL Editor"** (ícone que se parece com `>_`).
2. Clique no botão **"New query"** (Nova consulta).
3. Abra o arquivo `supabase_schema.sql` (que já criamos na raiz deste projeto), copie todo o seu conteúdo e cole dentro do editor do Supabase.
4. Clique no botão verde **"Run"** (no canto inferior direito do editor).
5. Você verá a mensagem **"Success. No rows returned"**. Pronto! Todas as tabelas foram criadas:
   * `funcionarios` (com o usuário Gustavo e senha 2108 já cadastrado)
   * `produtos` (com os eletrodomésticos no padrão `ELTDMS - XXXX`)
   * `vendas` e `itens_venda` (para fechamento e histórico)
   * `pedidos_online` e `envios`
   * As permissões **RLS (Row Level Security)** que liberam o frontend para ler e gravar dados.

---

## 🔑 PASSO 3: Pegar as Chaves de Acesso (API Keys)
Ainda no painel do Supabase:
1. No menu lateral esquerdo, clique no ícone de engrenagem **"Project Settings"**.
2. No submenu, clique em **"API"**.
3. Na seção **Project API keys**, você precisará copiar dois valores:
   * **Project URL:** Algo como `https://xyzcompany.supabase.co`
   * **Project API Keys -> `anon` / `public`:** Um código longo (chave pública).

---

## 💻 PASSO 4: Testar Localmente (Opcional)
Se quiser rodar o projeto na sua máquina com o Supabase:
1. Na raiz do projeto, crie um arquivo chamado `.env` (ou duplique o `.env.example`).
2. Preencha com as suas chaves copiadas do Passo 3:
   ```env
   VITE_SUPABASE_URL=https://seu-id-de-projeto.supabase.co
   VITE_SUPABASE_ANON_KEY=sua-chave-anon-publica-aqui
   ```
3. Ao rodar `npm run dev`, o programa se conectará automaticamente ao Supabase!

---

## 🌐 PASSO 5: Publicar o Site no Netlify
Existem duas formas fáceis de jogar o site no Netlify:

### Método A: Pelo GitHub (Recomendado)
1. Suba o código deste projeto para o seu repositório no **GitHub**.
2. Acesse o [https://app.netlify.com](https://app.netlify.com) e clique em **"Add new site" -> "Import an existing project"**.
3. Escolha o GitHub e selecione o repositório do projeto.
4. Na tela de configurações de deploy:
   * **Build command:** `npm run build`
   * **Publish directory:** `dist`
5. **MUITO IMPORTANTE (Variáveis de Ambiente):**
   * Antes de clicar em Deploy, clique em **"Add environment variables"** (ou configure depois em *Site configuration > Environment variables*).
   * Adicione as duas variáveis:
     * Chave: `VITE_SUPABASE_URL` | Valor: *(sua URL do Supabase)*
     * Chave: `VITE_SUPABASE_ANON_KEY` | Valor: *(sua chave anon do Supabase)*
6. Clique em **"Deploy site"**.
7. O Netlify vai compilar a aplicação e fornecer um link público (ex: `https://meu-sistema.netlify.app`).

### Método B: Netlify Drop (Arrastar a Pasta)
1. No seu computador, abra o terminal na pasta do projeto e execute:
   ```bash
   npm run build
   ```
   Isso criará uma pasta chamada `dist`.
2. Acesse [https://app.netlify.com/drop](https://app.netlify.com/drop).
3. Arraste a pasta `dist` para dentro da tela do navegador.
4. Para conectar com o Supabase, vá em **Site configuration -> Environment variables**, cadastre `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`, e faça um novo deploy ("Trigger deploy -> Clear cache and deploy").

---

## 🛠️ Como os Códigos do Projeto Funcionam com o Supabase

### 1. Cliente Supabase (`src/supabaseClient.ts`)
Inicializa a conexão com o banco usando as variáveis de ambiente:
```ts
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(
  supabaseUrl && supabaseAnonKey && supabaseUrl.startsWith('http')
);

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;
```

### 2. Sincronização (`src/supabaseService.ts`)
Faz o mapeamento direto das tabelas SQL com o frontend TypeScript:
* `carregarProdutosSupabase()`: busca os eletrodomésticos com `supabase.from('produtos').select('*')`
* `salvarProdutoSupabase(produto)`: grava novo eletrodoméstico no banco SQL
* `salvarVendaSupabase(venda)`: registra a venda e os itens vendidos nas tabelas `vendas` e `itens_venda`
* `ajustarEstoqueSupabase(...)`: sincroniza a baixa ou devolução de estoque em tempo real

### 3. Redirecionamento Netlify (`public/_redirects`)
Já deixamos configurado para que nenhuma página dê erro 404 ao atualizar:
```text
/*    /index.html   200
```
