import { Funcionario, Eletrodomestico, Cliente, Venda, MovimentacaoEstoque, PedidoOnline, Envio } from './types';

export const funcionariosIniciais: Funcionario[] = [
  {
    id: 'func-gustavo',
    usuario: 'Gustavo',
    senha: '2108',
    nome: 'Gustavo',
    cargo: 'Gerente da Loja',
    role: 'gerente',
    email: 'gustavo@eletronicosdemais.com.br',
    telefone: '(11) 98765-4321',
    matricula: 'ELD-001'
  },
  {
    id: 'func-01',
    usuario: 'marina',
    senha: '123',
    nome: 'Mariana Silva',
    cargo: 'Supervisora de Vendas',
    role: 'gerente',
    email: 'marina.silva@eletronicosdemais.com.br',
    telefone: '(11) 98765-4321',
    matricula: 'ELD-101'
  },
  {
    id: 'func-02',
    usuario: 'carlos',
    senha: '123',
    nome: 'Carlos Eduardo',
    cargo: 'Consultor de Vendas',
    role: 'vendedor',
    email: 'carlos.eduardo@eletronicosdemais.com.br',
    telefone: '(11) 97654-3210',
    matricula: 'ELD-204'
  },
  {
    id: 'func-03',
    usuario: 'roberto',
    senha: '123',
    nome: 'Roberto Rocha',
    cargo: 'Conferente de Estoque',
    role: 'estoquista',
    email: 'roberto.rocha@eletronicosdemais.com.br',
    telefone: '(11) 96543-2109',
    matricula: 'ELD-305'
  }
];

export const eletrodomesticosIniciais: Eletrodomestico[] = [
  {
    id: 'eletro-01',
    codigo: 'ELTDMS - 1001',
    nome: 'Geladeira Brastemp Frost Free Duplex 375L',
    categoria: 'Refrigeração',
    marca: 'Brastemp',
    modelo: 'BRM44HK',
    voltagem: '110V',
    cor: 'Inox',
    precoCusto: 2150.00,
    precoVenda: 2899.90,
    estoque: 14,
    estoqueMinimo: 5,
    localizacao: 'Setor A - Corredor 1',
    garantiaMeses: 12,
    capacidade: '375 Litros',
    descricao: 'Tecnologia Frost Free, compartimento Latas e Long Necks e gavetão de legumes Fresh Zone.',
    ativo: true
  },
  {
    id: 'eletro-02',
    codigo: 'ELTDMS - 1002',
    nome: 'Geladeira Brastemp Frost Free Duplex 375L',
    categoria: 'Refrigeração',
    marca: 'Brastemp',
    modelo: 'BRM44HK-220',
    voltagem: '220V',
    cor: 'Inox',
    precoCusto: 2150.00,
    precoVenda: 2899.90,
    estoque: 8,
    estoqueMinimo: 4,
    localizacao: 'Setor A - Corredor 1',
    garantiaMeses: 12,
    capacidade: '375 Litros',
    descricao: 'Frost Free duplex de alta eficiência energética.',
    ativo: true
  },
  {
    id: 'eletro-03',
    codigo: 'ELTDMS - 1003',
    nome: 'Geladeira Electrolux French Door 590L Inox',
    categoria: 'Refrigeração',
    marca: 'Electrolux',
    modelo: 'DM84X',
    voltagem: '220V',
    cor: 'Inox Premium',
    precoCusto: 4600.00,
    precoVenda: 6199.00,
    estoque: 4,
    estoqueMinimo: 3,
    localizacao: 'Setor A - Corredor 2',
    garantiaMeses: 12,
    capacidade: '590 Litros',
    descricao: 'Portas French Door, gaveta TasteLock com controle de umidade e dispensador de água e gelo.',
    ativo: true
  },
  {
    id: 'eletro-04',
    codigo: 'ELTDMS - 1004',
    nome: 'Máquina de Lavar Electrolux 14kg Essential Care',
    categoria: 'Lavanderia',
    marca: 'Electrolux',
    modelo: 'LED14',
    voltagem: '110V',
    cor: 'Branco',
    precoCusto: 1450.00,
    precoVenda: 1999.00,
    estoque: 12,
    estoqueMinimo: 4,
    localizacao: 'Setor B - Corredor 1',
    garantiaMeses: 12,
    capacidade: '14 Kg',
    descricao: 'Sistema Easy & Clean com filtro pega-fiapos e dispenser autolimpante.',
    ativo: true
  },
  {
    id: 'eletro-05',
    codigo: 'ELTDMS - 1005',
    nome: 'Lava e Seca Samsung EcoBubble 11kg / 7kg',
    categoria: 'Lavanderia',
    marca: 'Samsung',
    modelo: 'WD11M',
    voltagem: '110V',
    cor: 'Inox Look',
    precoCusto: 2800.00,
    precoVenda: 3799.00,
    estoque: 6,
    estoqueMinimo: 3,
    localizacao: 'Setor B - Corredor 2',
    garantiaMeses: 12,
    capacidade: '11kg Lava / 7kg Seca',
    descricao: 'Tecnologia EcoBubble, motor Digital Inverter silencioso com 10 anos de garantia do motor.',
    ativo: true
  },
  {
    id: 'eletro-06',
    codigo: 'ELTDMS - 1006',
    nome: 'Fogão Brastemp 4 Bocas com Timer Digital',
    categoria: 'Cocção',
    marca: 'Brastemp',
    modelo: 'BFO4NAB',
    voltagem: 'Bivolt',
    cor: 'Branco',
    precoCusto: 950.00,
    precoVenda: 1349.00,
    estoque: 18,
    estoqueMinimo: 5,
    localizacao: 'Setor C - Corredor 1',
    garantiaMeses: 12,
    capacidade: 'Forno 61,6L',
    descricao: 'Mesa de inox compartilhada, acendimento automático completo e forno com vidro panorâmico.',
    ativo: true
  },
  {
    id: 'eletro-07',
    codigo: 'ELTDMS - 1007',
    nome: 'Cooktop Consul 5 Bocas Vidro Temperado',
    categoria: 'Cocção',
    marca: 'Consul',
    modelo: 'CD075AE',
    voltagem: 'Bivolt',
    cor: 'Preto',
    precoCusto: 380.00,
    precoVenda: 589.90,
    estoque: 22,
    estoqueMinimo: 6,
    localizacao: 'Setor C - Corredor 2',
    garantiaMeses: 12,
    capacidade: '5 Bocas (1 Queimador Rápido)',
    descricao: 'Mesa em vidro temperado preto, grades individuais de aço esmaltado e botões removíveis.',
    ativo: true
  },
  {
    id: 'eletro-08',
    codigo: 'ELTDMS - 1008',
    nome: 'Micro-ondas Consul 32L com Função Descongelar',
    categoria: 'Cocção',
    marca: 'Consul',
    modelo: 'CMS46AR',
    voltagem: '110V',
    cor: 'Espelhado / Prata',
    precoCusto: 520.00,
    precoVenda: 749.90,
    estoque: 16,
    estoqueMinimo: 5,
    localizacao: 'Setor C - Corredor 3',
    garantiaMeses: 12,
    capacidade: '32 Litros',
    descricao: 'Porta espelhada com puxador embutido, menu fácil e receitas pré-programadas.',
    ativo: true
  },
  {
    id: 'eletro-09',
    codigo: 'ELTDMS - 1009',
    nome: 'Fritadeira Elétrica Air Fryer Mondial 4L Inox',
    categoria: 'Eletroportáteis',
    marca: 'Mondial',
    modelo: 'AFN-40-BI',
    voltagem: '110V',
    cor: 'Preto/Inox',
    precoCusto: 210.00,
    precoVenda: 349.90,
    estoque: 35,
    estoqueMinimo: 10,
    localizacao: 'Setor D - Prateleira 1',
    garantiaMeses: 12,
    capacidade: '4 Litros',
    descricao: 'Cuba antiaderente Duraflon, controle de temperatura até 200°C e timer de 60 minutos.',
    ativo: true
  },
  {
    id: 'eletro-10',
    codigo: 'ELTDMS - 1010',
    nome: 'Ar Condicionado Split LG Dual Inverter Voice 12.000 BTUs',
    categoria: 'Climatização',
    marca: 'LG',
    modelo: 'S4-Q12JA31F',
    voltagem: '220V',
    cor: 'Branco',
    precoCusto: 1980.00,
    precoVenda: 2699.00,
    estoque: 9,
    estoqueMinimo: 4,
    localizacao: 'Setor E - Corredor 1',
    garantiaMeses: 12,
    capacidade: '12.000 BTUs',
    descricao: 'Compressor Dual Inverter com até 70% de economia, conectividade Wi-Fi ThinQ e comando de voz.',
    ativo: true
  },
  {
    id: 'eletro-11',
    codigo: 'ELTDMS - 1011',
    nome: 'Aspirador de Pó Vertical Electrolux 2 em 1 1300W',
    categoria: 'Eletroportáteis',
    marca: 'Electrolux',
    modelo: 'STK15',
    voltagem: '110V',
    cor: 'Azul Denim',
    precoCusto: 140.00,
    precoVenda: 239.90,
    estoque: 25,
    estoqueMinimo: 8,
    localizacao: 'Setor D - Prateleira 2',
    garantiaMeses: 12,
    capacidade: 'Reservatório 1,6L',
    descricao: 'Pode ser usado como vertical ou de mão, filtro HEPA contra ácaros e cabo de 5 metros.',
    ativo: true
  },
  {
    id: 'eletro-12',
    codigo: 'ELTDMS - 1012',
    nome: 'Smart TV Samsung 55" Crystal UHD 4K',
    categoria: 'TVs e Áudio',
    marca: 'Samsung',
    modelo: 'UN55CU7700',
    voltagem: 'Bivolt',
    cor: 'Preto',
    precoCusto: 1850.00,
    precoVenda: 2499.00,
    estoque: 11,
    estoqueMinimo: 4,
    localizacao: 'Setor F - Prateleira Alta',
    garantiaMeses: 12,
    capacidade: '55 Polegadas',
    descricao: 'Painel Crystal UHD com Gaming Hub integrado, assistentes de voz e design sem bordas.',
    ativo: true
  },
  {
    id: 'eletro-13',
    codigo: 'ELTDMS - 1013',
    nome: 'Batedeira Planetária Arno Deluxe 500W',
    categoria: 'Eletroportáteis',
    marca: 'Arno',
    modelo: 'SX71',
    voltagem: '110V',
    cor: 'Vermelho',
    precoCusto: 240.00,
    precoVenda: 379.00,
    estoque: 3,
    estoqueMinimo: 5,
    localizacao: 'Setor D - Prateleira 3',
    garantiaMeses: 12,
    capacidade: 'Tigela 4 Litros',
    descricao: 'Movimento planetário com 8 velocidades e 3 batedores para massas leves, médias e pesadas.',
    ativo: true
  }
];

export const clientesIniciais: Cliente[] = [
  {
    id: 'cli-01',
    nome: 'Ana Paula Rodrigues',
    documento: '284.912.738-40',
    telefone: '(11) 98112-3344',
    email: 'ana.paula@email.com',
    endereco: 'Rua das Flores, 142 - Apto 31',
    cidade: 'São Paulo - SP',
    totalCompras: 4899.80,
    dataCadastro: '2026-01-15'
  },
  {
    id: 'cli-02',
    nome: 'Marcos Vinicius Souza',
    documento: '315.678.901-22',
    telefone: '(11) 97223-4455',
    email: 'marcos.vinicius@email.com',
    endereco: 'Av. Paulista, 1500 - Bela Vista',
    cidade: 'São Paulo - SP',
    totalCompras: 2899.90,
    dataCadastro: '2026-02-10'
  },
  {
    id: 'cli-03',
    nome: 'Restaurante & Buffet Sabor Ltda',
    documento: '45.123.890/0001-67',
    telefone: '(11) 3224-5566',
    email: 'contato@buffetsabor.com.br',
    endereco: 'Rua Augusta, 890 - Consolação',
    cidade: 'São Paulo - SP',
    totalCompras: 7450.00,
    dataCadastro: '2026-03-01'
  }
];

export const vendasIniciais: Venda[] = [
  {
    id: 'ven-1001',
    numero: 'PED-2026-1001',
    dataHora: '2026-09-28 10:30',
    vendedorId: 'func-02',
    vendedorNome: 'Carlos Eduardo',
    clienteNome: 'Ana Paula Rodrigues',
    clienteCpf: '284.912.738-40',
    clienteTelefone: '(11) 98112-3344',
    clienteEndereco: 'Rua das Flores, 142 - Apto 31, São Paulo - SP',
    itens: [
      {
        produtoId: 'eletro-01',
        codigo: 'ELTDMS - 1001',
        nome: 'Geladeira Brastemp Frost Free Duplex 375L',
        marca: 'Brastemp',
        voltagem: '110V',
        quantidade: 1,
        precoUnitario: 2899.90,
        subtotal: 2899.90
      },
      {
        produtoId: 'eletro-09',
        codigo: 'ELTDMS - 1009',
        nome: 'Fritadeira Elétrica Air Fryer Mondial 4L Inox',
        marca: 'Mondial',
        voltagem: '110V',
        quantidade: 1,
        precoUnitario: 349.90,
        subtotal: 349.90
      }
    ],
    subtotal: 3249.80,
    desconto: 100.00,
    total: 3149.80,
    formaPagamento: 'cartao_credito',
    parcelas: 10,
    tipoEntrega: 'entrega',
    status: 'concluida',
    observacoes: 'Entrega agendada para o período da manhã.'
  },
  {
    id: 'ven-1002',
    numero: 'PED-2026-1002',
    dataHora: '2026-09-28 14:15',
    vendedorId: 'func-02',
    vendedorNome: 'Carlos Eduardo',
    clienteNome: 'Marcos Vinicius Souza',
    clienteCpf: '315.678.901-22',
    clienteTelefone: '(11) 97223-4455',
    itens: [
      {
        produtoId: 'eletro-04',
        codigo: 'ELTDMS - 1004',
        nome: 'Máquina de Lavar Electrolux 14kg Essential Care',
        marca: 'Electrolux',
        voltagem: '110V',
        quantidade: 1,
        precoUnitario: 1999.00,
        subtotal: 1999.00
      }
    ],
    subtotal: 1999.00,
    desconto: 50.00,
    total: 1949.00,
    formaPagamento: 'pix',
    tipoEntrega: 'retirada',
    status: 'concluida',
    observacoes: 'Cliente retirou no balcão da expedição.'
  }
];

export const movimentacoesIniciais: MovimentacaoEstoque[] = [
  {
    id: 'mov-01',
    dataHora: '2026-09-27 08:30',
    produtoId: 'eletro-01',
    produtoCodigo: 'ELTDMS - 1001',
    produtoNome: 'Geladeira Brastemp Frost Free Duplex 375L',
    tipo: 'entrada',
    quantidade: 15,
    estoqueAnterior: 0,
    estoqueNovo: 15,
    responsavel: 'Gustavo',
    motivo: 'Recebimento de lote do fornecedor - NF 84920'
  }
];

export const pedidosOnlineIniciais: PedidoOnline[] = [
  {
    id: 'onl-101',
    numero: 'ONL-2026-101',
    dataHora: '2026-09-29 09:15',
    clienteNome: 'Juliana Mendes Camargo',
    clienteTelefone: '(11) 98334-5566',
    endereco: 'Rua Bela Cintra, 1200 - Apto 44',
    cidade: 'São Paulo - SP',
    itens: [
      {
        produtoNome: 'Fritadeira Elétrica Air Fryer Mondial 4L Inox',
        codigo: 'ELTDMS - 1009',
        quantidade: 1,
        preco: 349.90
      },
      {
        produtoNome: 'Micro-ondas Consul 32L com Função Descongelar',
        codigo: 'ELTDMS - 1008',
        quantidade: 1,
        preco: 749.90
      }
    ],
    total: 1099.80,
    status: 'Aguardando Separação',
    pagamento: 'Pix Aprovado'
  },
  {
    id: 'onl-102',
    numero: 'ONL-2026-102',
    dataHora: '2026-09-29 11:40',
    clienteNome: 'Roberto Silveira Lima',
    clienteTelefone: '(11) 97112-9988',
    endereco: 'Av. Ibirapuera, 310 - Moema',
    cidade: 'São Paulo - SP',
    itens: [
      {
        produtoNome: 'Geladeira Electrolux French Door 590L Inox',
        codigo: 'ELTDMS - 1003',
        quantidade: 1,
        preco: 6199.00
      }
    ],
    total: 6199.00,
    status: 'Em Separação',
    pagamento: 'Cartão de Crédito 10x'
  }
];

export const enviosIniciais: Envio[] = [
  {
    id: 'env-201',
    codigoRastreio: 'BR-ELD-99823',
    pedidoNumero: 'PED-2026-1001',
    destinatario: 'Ana Paula Rodrigues',
    enderecoEntrega: 'Rua das Flores, 142 - Apto 31',
    cidade: 'São Paulo - SP',
    transportadora: 'Frota Própria Eletrônicos Demais',
    dataDespacho: '2026-09-28 14:00',
    previsaoEntrega: '2026-09-29 18:00',
    status: 'Em Trânsito'
  },
  {
    id: 'env-202',
    codigoRastreio: 'BR-ELD-99824',
    pedidoNumero: 'ONL-2026-098',
    destinatario: 'Fernando Castro',
    enderecoEntrega: 'Rua Vergueiro, 2500 - Vila Mariana',
    cidade: 'São Paulo - SP',
    transportadora: 'Transportadora Rápido SP',
    dataDespacho: '2026-09-27 10:30',
    previsaoEntrega: '2026-09-28 17:00',
    status: 'Entregue'
  }
];
