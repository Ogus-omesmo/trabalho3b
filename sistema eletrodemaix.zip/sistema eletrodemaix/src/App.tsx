import React, { useState, useEffect } from 'react';
import {
  Funcionario,
  Eletrodomestico,
  Venda,
  PedidoOnline,
  Envio
} from './types';
import {
  funcionariosIniciais,
  eletrodomesticosIniciais,
  vendasIniciais,
  pedidosOnlineIniciais,
  enviosIniciais
} from './mockData';
import { Navbar } from './components/Navbar';
import { Sidebar, MainSection } from './components/Sidebar';
import { LoginView } from './components/LoginView';
import { TelaBrancaView } from './components/TelaBrancaView';
import { CadastrarItemView } from './components/CadastrarItemView';
import { EstoqueView } from './components/EstoqueView';
import { FecharVendaView } from './components/FecharVendaView';
import { HistoricoVendasView } from './components/HistoricoVendasView';
import { PedidosOnlineView } from './components/PedidosOnlineView';
import { EnviosView } from './components/EnviosView';
import { ComprovanteVendaModal } from './components/ComprovanteVendaModal';
import { ContaModal } from './components/ContaModal';
import {
  carregarProdutosSupabase,
  salvarProdutoSupabase,
  atualizarProdutoSupabase,
  excluirProdutoSupabase,
  ajustarEstoqueSupabase,
  carregarFuncionariosSupabase,
  carregarVendasSupabase,
  salvarVendaSupabase,
  cancelarVendaSupabase,
  carregarPedidosOnlineSupabase,
  carregarEnviosSupabase
} from './supabaseService';
import { isSupabaseConfigured } from './supabaseClient';

export const App: React.FC = () => {
  // Tela de login inicial
  const [funcionarioLogado, setFuncionarioLogado] = useState<Funcionario | null>(null);

  // Inicia com tela branca, sem informação direto na tela
  const [activeSection, setActiveSection] = useState<MainSection>('inicio');

  // Estado da barra lateral (abre e fecha ao clicar no botão de 3 linhas)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Estados dos dados da loja
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>(funcionariosIniciais);
  const [eletrodomesticos, setEletrodomesticos] = useState<Eletrodomestico[]>(eletrodomesticosIniciais);
  const [vendas, setVendas] = useState<Venda[]>(vendasIniciais);
  const [pedidosOnline, setPedidosOnline] = useState<PedidoOnline[]>(pedidosOnlineIniciais);
  const [envios, setEnvios] = useState<Envio[]>(enviosIniciais);

  // Modais
  const [comprovanteVenda, setComprovanteVenda] = useState<Venda | null>(null);
  const [contaModalAberta, setContaModalAberta] = useState(false);

  // Sincronização inicial com o Supabase quando configurado
  useEffect(() => {
    if (!isSupabaseConfigured) return;

    let isMounted = true;

    async function syncComSupabase() {
      const [prodsSupabase, funcsSupabase, vendasSupabase, pedidosSupabase, enviosSupabase] =
        await Promise.all([
          carregarProdutosSupabase(),
          carregarFuncionariosSupabase(),
          carregarVendasSupabase(),
          carregarPedidosOnlineSupabase(),
          carregarEnviosSupabase()
        ]);

      if (!isMounted) return;

      if (prodsSupabase && prodsSupabase.length > 0) {
        setEletrodomesticos(prodsSupabase);
      }
      if (funcsSupabase && funcsSupabase.length > 0) {
        setFuncionarios(funcsSupabase);
      }
      if (vendasSupabase && vendasSupabase.length > 0) {
        setVendas(vendasSupabase);
      }
      if (pedidosSupabase && pedidosSupabase.length > 0) {
        setPedidosOnline(pedidosSupabase);
      }
      if (enviosSupabase && enviosSupabase.length > 0) {
        setEnvios(enviosSupabase);
      }
    }

    syncComSupabase();

    return () => {
      isMounted = false;
    };
  }, []);

  // AÇÕES DE ESTOQUE
  const handleAdicionarProduto = (novo: Eletrodomestico) => {
    setEletrodomesticos((prev) => [novo, ...prev]);
    salvarProdutoSupabase(novo);
  };

  const handleEditarProduto = (atualizado: Eletrodomestico) => {
    setEletrodomesticos((prev) =>
      prev.map((item) => (item.id === atualizado.id ? atualizado : item))
    );
    atualizarProdutoSupabase(atualizado);
  };

  const handleExcluirProduto = (id: string) => {
    const itemParaExcluir = eletrodomesticos.find((p) => p.id === id);
    setEletrodomesticos((prev) => prev.filter((item) => item.id !== id));
    if (itemParaExcluir) {
      excluirProdutoSupabase(itemParaExcluir);
    }
  };

  const handleAjustarEstoqueRapido = (id: string, delta: number) => {
    setEletrodomesticos((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const novoEstoque = Math.max(0, item.estoque + delta);
          ajustarEstoqueSupabase(item, novoEstoque);
          return { ...item, estoque: novoEstoque };
        }
        return item;
      })
    );
  };

  // VENDAS (Realizar Venda e Baixar Estoque)
  const handleFinalizarVenda = (novaVenda: Venda) => {
    setVendas((prev) => [novaVenda, ...prev]);
    salvarVendaSupabase(novaVenda);

    // Baixa automática no estoque
    setEletrodomesticos((prev) => {
      let copia = [...prev];
      for (const itemVenda of novaVenda.itens) {
        copia = copia.map((p) => {
          if (p.id === itemVenda.produtoId) {
            const novoEstoque = Math.max(0, p.estoque - itemVenda.quantidade);
            ajustarEstoqueSupabase(p, novoEstoque);
            return {
              ...p,
              estoque: novoEstoque
            };
          }
          return p;
        });
      }
      return copia;
    });

    setComprovanteVenda(novaVenda);
  };

  // CANCELAR VENDA (Devolver ao Estoque)
  const handleCancelarVenda = (vendaId: string) => {
    const venda = vendas.find((v) => v.id === vendaId);
    if (!venda || venda.status === 'cancelada') return;

    setVendas((prev) =>
      prev.map((v) => (v.id === vendaId ? { ...v, status: 'cancelada' } : v))
    );
    cancelarVendaSupabase(vendaId, venda.numero);

    setEletrodomesticos((prev) => {
      let copia = [...prev];
      for (const item of venda.itens) {
        copia = copia.map((p) => {
          if (p.id === item.produtoId) {
            const novoEstoque = p.estoque + item.quantidade;
            ajustarEstoqueSupabase(p, novoEstoque);
            return {
              ...p,
              estoque: novoEstoque
            };
          }
          return p;
        });
      }
      return copia;
    });
  };

  // ATUALIZAR STATUS DE PEDIDO ONLINE
  const handleAtualizarStatusPedidoOnline = (id: string, novoStatus: PedidoOnline['status']) => {
    setPedidosOnline((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status: novoStatus } : p))
    );
  };

  // ATUALIZAR STATUS DE ENVIO
  const handleAtualizarStatusEnvio = (id: string, novoStatus: Envio['status']) => {
    setEnvios((prev) =>
      prev.map((e) => (e.id === id ? { ...e, status: novoStatus } : e))
    );
  };

  // CONTA DE FUNCIONÁRIO
  const handleSalvarConta = (atualizado: Funcionario) => {
    setFuncionarioLogado(atualizado);
    setFuncionarios((prev) =>
      prev.map((f) => (f.id === atualizado.id ? atualizado : f))
    );
  };

  // Tela de Login Obrigatória
  if (!funcionarioLogado) {
    return (
      <LoginView
        funcionarios={funcionarios}
        onLoginSuccess={(func) => {
          setFuncionarioLogado(func);
          setActiveSection('inicio'); // Ao entrar, tela branca sem informação direto
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-white text-neutral-800 flex flex-col antialiased">
      {/* Barra Superior com botão de 3 linhas (menu lateral) e silhueta de pessoa (gerenciar usuário) */}
      <Navbar
        funcionario={funcionarioLogado}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        onOpenConta={() => setContaModalAberta(true)}
        isSidebarAberta={isSidebarOpen}
      />

      {/* Navbar Lateral (Sidebar) com as opções solicitadas */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        activeSection={activeSection}
        onSelectSection={(sec) => setActiveSection(sec)}
        funcionario={funcionarioLogado}
        onOpenConta={() => setContaModalAberta(true)}
        onLogout={() => {
          setFuncionarioLogado(null);
          setIsSidebarOpen(false);
        }}
      />

      {/* Conteúdo Principal com base na opção selecionada no navbar lateral */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Tela Branca Inicial (sem informação direto) */}
        {activeSection === 'inicio' && (
          <TelaBrancaView onAbrirMenu={() => setIsSidebarOpen(true)} />
        )}

        {/* 1. CADASTRAR ITEM */}
        {activeSection === 'cadastrar_item' && (
          <CadastrarItemView onAdicionarProduto={handleAdicionarProduto} />
        )}

        {/* 2. GERENCIAR ESTOQUE */}
        {activeSection === 'gerenciar_estoque' && (
          <EstoqueView
            funcionario={funcionarioLogado}
            eletrodomesticos={eletrodomesticos}
            onAdicionarProduto={handleAdicionarProduto}
            onEditarProduto={handleEditarProduto}
            onExcluirProduto={handleExcluirProduto}
            onAjustarEstoqueRapido={handleAjustarEstoqueRapido}
          />
        )}

        {/* 3. FECHAR VENDA (Formulário separado) */}
        {activeSection === 'fechar_venda' && (
          <FecharVendaView
            funcionario={funcionarioLogado}
            eletrodomesticos={eletrodomesticos}
            onFinalizarVenda={handleFinalizarVenda}
          />
        )}

        {/* 4. HISTÓRICO DE VENDAS (Aba separada) */}
        {activeSection === 'historico_vendas' && (
          <HistoricoVendasView
            vendas={vendas}
            onCancelarVenda={handleCancelarVenda}
            onImprimirComprovante={(v) => setComprovanteVenda(v)}
          />
        )}

        {/* 5. PEDIDOS ONLINE */}
        {activeSection === 'pedidos_online' && (
          <PedidosOnlineView
            pedidos={pedidosOnline}
            onAtualizarStatus={handleAtualizarStatusPedidoOnline}
          />
        )}

        {/* 6. ENVIOS */}
        {activeSection === 'envios' && (
          <EnviosView
            envios={envios}
            onAtualizarStatusEnvio={handleAtualizarStatusEnvio}
          />
        )}
      </main>

      {/* Rodapé Simples e Discreto */}
      <footer className="bg-white border-t border-neutral-100 py-2.5 text-center text-xs text-neutral-400 font-normal flex items-center justify-center gap-2">
        <img src="/favicon.png" alt="EletroDemaix" className="w-4 h-4 object-contain mix-blend-multiply select-none" />
        <span>EletroDemaix • Sistema de Controle de Estoque e Vendas</span>
      </footer>

      {/* Modal de Gerenciamento de Usuário */}
      {contaModalAberta && (
        <ContaModal
          funcionario={funcionarioLogado}
          isOpen={contaModalAberta}
          onClose={() => setContaModalAberta(false)}
          onSave={handleSalvarConta}
        />
      )}

      {/* Modal de Comprovante de Venda */}
      {comprovanteVenda && (
        <ComprovanteVendaModal
          venda={comprovanteVenda}
          onFechar={() => setComprovanteVenda(null)}
        />
      )}
    </div>
  );
};

export default App;
