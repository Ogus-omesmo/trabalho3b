export type UserRole = 'gerente' | 'vendedor' | 'estoquista';

export interface Funcionario {
  id: string;
  usuario: string;
  senha?: string;
  nome: string;
  cargo: string;
  role: UserRole;
  email: string;
  telefone: string;
  matricula: string;
}

export type CategoriaEletro =
  | 'Refrigeração'
  | 'Lavanderia'
  | 'Cocção'
  | 'Eletroportáteis'
  | 'Climatização'
  | 'TVs e Áudio'
  | 'Linha Branca';

export type Voltagem = '110V' | '220V' | 'Bivolt';

export interface Eletrodomestico {
  id: string;
  codigo: string; // SKU / Código interno (ex: REF-001)
  nome: string;
  categoria: CategoriaEletro;
  marca: string;
  modelo: string;
  voltagem: Voltagem;
  cor: string;
  precoCusto: number;
  precoVenda: number;
  estoque: number;
  estoqueMinimo: number;
  localizacao: string; // ex: Corredor A, Prateleira 2
  garantiaMeses: number;
  capacidade?: string; // ex: 375 Litros, 14 Kg, 12000 BTUs
  descricao?: string;
  ativo: boolean;
}

export interface ItemCarrinho {
  produto: Eletrodomestico;
  quantidade: number;
  precoUnitario: number;
  subtotal: number;
}

export type FormaPagamento = 'pix' | 'cartao_credito' | 'cartao_debito' | 'dinheiro' | 'boleto';

export interface ItemVendaGravado {
  produtoId: string;
  codigo: string;
  nome: string;
  marca: string;
  voltagem: Voltagem;
  quantidade: number;
  precoUnitario: number;
  subtotal: number;
}

export interface Venda {
  id: string;
  numero: string; // ex: PED-2026-1001
  dataHora: string;
  vendedorId: string;
  vendedorNome: string;
  clienteNome: string;
  clienteCpf: string;
  clienteTelefone: string;
  clienteEndereco?: string;
  itens: ItemVendaGravado[];
  subtotal: number;
  desconto: number;
  total: number;
  formaPagamento: FormaPagamento;
  parcelas?: number;
  tipoEntrega: 'retirada' | 'entrega';
  status: 'concluida' | 'cancelada';
  observacoes?: string;
}

export interface Cliente {
  id: string;
  nome: string;
  documento: string; // CPF ou CNPJ
  telefone: string;
  email: string;
  endereco: string;
  cidade: string;
  totalCompras: number;
  dataCadastro: string;
}

export interface MovimentacaoEstoque {
  id: string;
  dataHora: string;
  produtoId: string;
  produtoCodigo: string;
  produtoNome: string;
  tipo: 'entrada' | 'saida_venda' | 'ajuste_manual' | 'devolucao';
  quantidade: number;
  estoqueAnterior: number;
  estoqueNovo: number;
  responsavel: string;
  motivo: string;
}

export interface PedidoOnline {
  id: string;
  numero: string;
  dataHora: string;
  clienteNome: string;
  clienteTelefone: string;
  endereco: string;
  cidade: string;
  itens: { produtoNome: string; codigo: string; quantidade: number; preco: number }[];
  total: number;
  status: 'Aguardando Separação' | 'Em Separação' | 'Pronto para Envio' | 'Cancelado';
  pagamento: string;
}

export interface Envio {
  id: string;
  codigoRastreio: string;
  pedidoNumero: string;
  destinatario: string;
  enderecoEntrega: string;
  cidade: string;
  transportadora: string;
  dataDespacho: string;
  previsaoEntrega: string;
  status: 'Aguardando Coleta' | 'Em Trânsito' | 'Saiu para Entrega' | 'Entregue';
}
