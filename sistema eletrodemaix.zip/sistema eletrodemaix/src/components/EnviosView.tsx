import React, { useState } from 'react';
import { Envio } from '../types';

interface EnviosViewProps {
  envios: Envio[];
  onAtualizarStatusEnvio: (id: string, novoStatus: Envio['status']) => void;
}

export const EnviosView: React.FC<EnviosViewProps> = ({
  envios,
  onAtualizarStatusEnvio
}) => {
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<string>('todos');

  const enviosFiltrados = envios.filter((e) => {
    const matchBusca =
      e.codigoRastreio.toLowerCase().includes(busca.toLowerCase()) ||
      e.pedidoNumero.toLowerCase().includes(busca.toLowerCase()) ||
      e.destinatario.toLowerCase().includes(busca.toLowerCase()) ||
      e.cidade.toLowerCase().includes(busca.toLowerCase());

    const matchStatus = filtroStatus === 'todos' || e.status === filtroStatus;

    return matchBusca && matchStatus;
  });

  return (
    <div className="space-y-4">
      {/* Cabeçalho */}
      <div className="bg-white p-3 border border-neutral-300 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
        <div>
          <h1 className="text-sm sm:text-base font-semibold text-neutral-800">
            Controle de Envios e Logística
          </h1>
          <p className="text-xs text-neutral-500 font-normal">
            EletroDemaix • Rastreamento de despachos, transportadoras e entregas
          </p>
        </div>
        <div className="text-xs text-neutral-600 bg-[#f4f4f4] px-2.5 py-1 rounded border border-neutral-200">
          Remessas: <span className="font-semibold text-neutral-800">{envios.length}</span>
        </div>
      </div>

      {/* Filtros */}
      <div className="bg-white border border-neutral-300 rounded-lg p-3 sm:p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pb-2 border-b border-neutral-200">
          <input
            type="text"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar por código de rastreio, pedido ou destinatário..."
            className="w-full sm:w-72 px-2.5 py-1 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
          />

          <select
            value={filtroStatus}
            onChange={(e) => setFiltroStatus(e.target.value)}
            className="w-full sm:w-auto px-2.5 py-1 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none"
          >
            <option value="todos">Todos os Status</option>
            <option value="Aguardando Coleta">Aguardando Coleta</option>
            <option value="Em Trânsito">Em Trânsito</option>
            <option value="Saiu para Entrega">Saiu para Entrega</option>
            <option value="Entregue">Entregue</option>
          </select>
        </div>

        {/* Tabela de Envios Compacta */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-200 text-left text-[11px]">
            <thead className="bg-[#f4f4f4] text-neutral-700 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th scope="col" className="px-2 py-1.5">Rastreio</th>
                <th scope="col" className="px-2 py-1.5">Pedido</th>
                <th scope="col" className="px-2 py-1.5">Destinatário</th>
                <th scope="col" className="px-2 py-1.5">Endereço de Entrega</th>
                <th scope="col" className="px-2 py-1.5">Transportadora</th>
                <th scope="col" className="px-2 py-1.5">Previsão</th>
                <th scope="col" className="px-2 py-1.5 text-center">Status</th>
                <th scope="col" className="px-2 py-1.5 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-neutral-800">
              {enviosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-3 py-6 text-center text-neutral-500 font-normal">
                    Nenhum registro de envio localizado.
                  </td>
                </tr>
              ) : (
                enviosFiltrados.map((envio) => (
                  <tr key={envio.id} className="hover:bg-[#f4f4f4] transition-colors leading-tight">
                    <td className="px-2 py-1 whitespace-nowrap font-mono font-medium text-neutral-900">
                      {envio.codigoRastreio}
                    </td>
                    <td className="px-2 py-1 whitespace-nowrap font-mono text-neutral-600">
                      {envio.pedidoNumero}
                    </td>
                    <td className="px-2 py-1 whitespace-nowrap font-medium text-neutral-900">
                      {envio.destinatario}
                    </td>
                    <td className="px-2 py-1 text-neutral-600">
                      {envio.enderecoEntrega} - {envio.cidade}
                    </td>
                    <td className="px-2 py-1 whitespace-nowrap text-neutral-700">
                      {envio.transportadora}
                    </td>
                    <td className="px-2 py-1 whitespace-nowrap text-neutral-500">
                      {envio.previsaoEntrega}
                    </td>
                    <td className="px-2 py-1 whitespace-nowrap text-center">
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-medium ${
                          envio.status === 'Entregue'
                            ? 'bg-neutral-800 text-white'
                            : envio.status === 'Em Trânsito' || envio.status === 'Saiu para Entrega'
                            ? 'bg-orange-600 text-white'
                            : 'bg-[#f4f4f4] border border-neutral-300 text-neutral-800'
                        }`}
                      >
                        {envio.status}
                      </span>
                    </td>
                    <td className="px-2 py-1 whitespace-nowrap text-center">
                      <div className="inline-flex items-center gap-1">
                        {envio.status === 'Aguardando Coleta' && (
                          <button
                            type="button"
                            onClick={() => onAtualizarStatusEnvio(envio.id, 'Em Trânsito')}
                            className="px-2 py-0.5 bg-orange-600 hover:bg-orange-700 text-white text-[10px] font-medium rounded transition-colors cursor-pointer"
                          >
                            Despachar
                          </button>
                        )}

                        {envio.status === 'Em Trânsito' && (
                          <button
                            type="button"
                            onClick={() => onAtualizarStatusEnvio(envio.id, 'Saiu para Entrega')}
                            className="px-2 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-white text-[10px] font-medium rounded transition-colors cursor-pointer"
                          >
                            Saiu p/ Entrega
                          </button>
                        )}

                        {envio.status === 'Saiu para Entrega' && (
                          <button
                            type="button"
                            onClick={() => onAtualizarStatusEnvio(envio.id, 'Entregue')}
                            className="px-2 py-0.5 bg-orange-600 hover:bg-orange-700 text-white text-[10px] font-medium rounded transition-colors cursor-pointer"
                          >
                            Confirmar Entrega
                          </button>
                        )}

                        {envio.status === 'Entregue' && (
                          <span className="text-[10px] text-neutral-400 font-normal">
                            Finalizado
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
