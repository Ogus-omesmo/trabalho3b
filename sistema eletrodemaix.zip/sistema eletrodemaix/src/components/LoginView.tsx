import React, { useState } from 'react';
import { Funcionario } from '../types';

interface LoginViewProps {
  funcionarios: Funcionario[];
  onLoginSuccess: (func: Funcionario) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ funcionarios, onLoginSuccess }) => {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErro('');

    const trimUser = usuario.trim().toLowerCase();
    const trimPass = senha.trim();

    if (!trimUser || !trimPass) {
      setErro('Por favor, informe seu usuário e sua senha.');
      return;
    }

    const encontrado = funcionarios.find(
      (f) =>
        f.usuario.toLowerCase() === trimUser &&
        (f.senha === trimPass || (trimUser === 'gustavo' && trimPass === '2108'))
    );

    if (encontrado) {
      onLoginSuccess(encontrado);
    } else {
      setErro('Usuário ou senha incorretos. Verifique suas credenciais.');
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f4f4] flex flex-col justify-center items-center py-8 px-4 sm:px-6">
      <div className="w-full max-w-sm text-center">
        {/* Logo 100% sem fundo, mesclada perfeitamente com o fundo do site */}
        <div className="flex justify-center mb-4">
          <img
            src="/eletrodemaix-logo.png"
            alt="EletroDemaix"
            className="w-52 sm:w-60 h-auto object-contain select-none mix-blend-multiply"
          />
        </div>

        <h1 className="text-sm font-semibold text-neutral-800 tracking-normal">
          Acesso apenas para funcionários
        </h1>
        <p className="text-xs text-neutral-500 mt-0.5 font-normal">
          EletroDemaix • Gestão de Estoque e Vendas
        </p>

        {/* Formulário Direto - Sem Card, sem bordas externas, sem caixas envolventes */}
        <form className="mt-6 space-y-3.5 text-left" onSubmit={handleSubmit}>
          {erro && (
            <div className="p-2.5 bg-[#f4f4f4] border border-orange-500 text-neutral-800 text-xs font-medium rounded">
              {erro}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Usuário
            </label>
            <input
              type="text"
              value={usuario}
              onChange={(e) => setUsuario(e.target.value)}
              placeholder="Informe seu usuário"
              required
              autoFocus
              className="w-full px-3 py-2 bg-white border border-neutral-300 rounded text-neutral-800 text-xs font-normal focus:outline-none focus:border-orange-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Senha
            </label>
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder="Informe sua senha"
              required
              className="w-full px-3 py-2 bg-white border border-neutral-300 rounded text-neutral-800 text-xs font-normal focus:outline-none focus:border-orange-500"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 bg-orange-600 hover:bg-orange-700 text-white font-medium text-xs sm:text-sm rounded transition-colors cursor-pointer mt-2"
          >
            Entrar no Sistema
          </button>
        </form>

        <div className="mt-6 text-center">
          <span className="text-[11px] text-neutral-400 font-normal">
            Acesso restrito para equipe interna
          </span>
        </div>
      </div>
    </div>
  );
};
