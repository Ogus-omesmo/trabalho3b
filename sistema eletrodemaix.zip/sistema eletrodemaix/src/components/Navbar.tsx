import React from 'react';
import { Funcionario } from '../types';

interface NavbarProps {
  funcionario: Funcionario;
  onToggleSidebar: () => void;
  onOpenConta: () => void;
  isSidebarAberta: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  funcionario,
  onToggleSidebar,
  onOpenConta,
  isSidebarAberta
}) => {
  return (
    <header className="bg-white border-b border-neutral-200 text-neutral-800 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-13">
          {/* Botão com símbolo de 3 linhas horizontais (abre e fecha a barra lateral) */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onToggleSidebar}
              className="p-1.5 rounded-lg text-neutral-700 hover:text-orange-600 hover:bg-[#f4f4f4] transition-colors cursor-pointer"
              title={isSidebarAberta ? 'Fechar menu lateral' : 'Abrir menu lateral'}
              aria-label="Menu"
            >
              {/* Símbolo de 3 linhas horizontais */}
              <svg
                viewBox="0 0 24 24"
                className="w-6 h-6 stroke-current fill-none stroke-2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="18" x2="21" y2="18" />
              </svg>
            </button>

            {/* No lugar do título "eletrônicos demais", o símbolo do favicon sem fundo */}
            <div className="flex items-center gap-2">
              <img
                src="/favicon.png"
                alt="EletroDemaix"
                className="w-8 h-8 object-contain mix-blend-multiply select-none"
              />
              <span className="font-semibold text-sm text-neutral-900 tracking-tight">
                EletroDemaix
              </span>
            </div>
          </div>

          {/* Botão no topo com o símbolo de uma pessoa (silhueta do ombro para cima) */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenConta}
              className="flex items-center gap-2 px-2.5 py-1 rounded-lg border border-neutral-300 bg-[#f4f4f4] hover:bg-neutral-200 text-neutral-800 transition-colors cursor-pointer"
              title="Gerenciar Usuário"
              aria-label="Gerenciar Usuário"
            >
              {/* Silhueta de pessoa do ombro para cima */}
              <svg
                viewBox="0 0 24 24"
                className="w-4 h-4 text-orange-600 fill-none stroke-current stroke-2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
              <span className="text-xs font-medium text-neutral-800 hidden sm:inline">
                {funcionario.nome}
              </span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
