import React, { useState } from 'react';
import { Funcionario } from '../types';

interface ContaModalProps {
  funcionario: Funcionario;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedFuncionario: Funcionario) => void;
}

export const ContaModal: React.FC<ContaModalProps> = ({
  funcionario,
  isOpen,
  onClose,
  onSave
}) => {
  const [nome, setNome] = useState(funcionario.nome);
  const [cargo, setCargo] = useState(funcionario.cargo);
  const [matricula, setMatricula] = useState(funcionario.matricula);
  const [usuario, setUsuario] = useState(funcionario.usuario);
  const [email, setEmail] = useState(funcionario.email);
  const [telefone, setTelefone] = useState(funcionario.telefone);
  const [novaSenha, setNovaSenha] = useState('');
  const [sucesso, setSucesso] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...funcionario,
      nome: nome.trim(),
      cargo: cargo.trim(),
      matricula: matricula.trim(),
      usuario: usuario.trim(),
      email: email.trim(),
      telefone: telefone.trim(),
      senha: novaSenha.trim() ? novaSenha.trim() : funcionario.senha
    });
    setSucesso(true);
    setTimeout(() => {
      setSucesso(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-5 border border-orange-500 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
          <h3 className="text-sm font-semibold text-neutral-800">
            Perfil de Acesso do Funcionário
          </h3>
          <button
            onClick={onClose}
            className="text-neutral-500 hover:text-neutral-800 text-xs px-2 py-0.5 bg-[#f4f4f4] rounded"
          >
            Fechar
          </button>
        </div>

        {sucesso && (
          <div className="mt-3 p-2 bg-[#f4f4f4] border border-orange-500 text-neutral-800 text-xs font-medium rounded">
            Dados da conta atualizados com sucesso!
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-3 text-xs">
          <div>
            <label className="block text-neutral-700 font-medium mb-1">Nome Completo *</label>
            <input
              type="text"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              required
              className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 focus:outline-none focus:border-orange-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-700 font-medium mb-1">Cargo *</label>
              <input
                type="text"
                value={cargo}
                onChange={(e) => setCargo(e.target.value)}
                required
                className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 focus:outline-none focus:border-orange-500"
              />
            </div>
            <div>
              <label className="block text-neutral-700 font-medium mb-1">Matrícula</label>
              <input
                type="text"
                value={matricula}
                onChange={(e) => setMatricula(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 font-mono focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-700 font-medium mb-1">Usuário *</label>
              <input
                type="text"
                value={usuario}
                onChange={(e) => setUsuario(e.target.value)}
                required
                className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 focus:outline-none focus:border-orange-500"
              />
            </div>
            <div>
              <label className="block text-neutral-700 font-medium mb-1">Perfil</label>
              <div className="px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-200 rounded text-neutral-800 font-medium text-xs">
                {funcionario.role}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-neutral-700 font-medium mb-1">E-mail Corporativo</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 focus:outline-none focus:border-orange-500"
            />
          </div>

          <div>
            <label className="block text-neutral-700 font-medium mb-1">Telefone ou Ramal</label>
            <input
              type="text"
              value={telefone}
              onChange={(e) => setTelefone(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 focus:outline-none focus:border-orange-500"
            />
          </div>

          <div className="pt-2 border-t border-neutral-200">
            <label className="block text-neutral-700 font-medium mb-1">
              Alterar Senha de Acesso (deixe em branco para manter)
            </label>
            <input
              type="password"
              value={novaSenha}
              onChange={(e) => setNovaSenha(e.target.value)}
              placeholder="Digite a nova senha"
              className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 focus:outline-none focus:border-orange-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-200">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-[#f4f4f4] hover:bg-neutral-200 text-neutral-700 font-medium rounded"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-orange-600 hover:bg-orange-700 text-white font-medium rounded transition-colors"
            >
              Salvar Perfil
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
