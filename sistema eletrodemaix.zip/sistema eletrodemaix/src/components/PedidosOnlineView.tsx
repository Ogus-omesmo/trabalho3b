import React, { useState } from 'react';
import { PedidoOnline } from '../types';

interface PedidosOnlineViewProps {
  pedidos: PedidoOnline[];
  onAtualizarStatus: (id: string, novoStatus: PedidoOnline['status']) => void;
}

export const PedidosOnlineView: React.FC<PedidosOnlineViewProps> = ({
  pedidos,
  onAtualizarStatus
}) => {
  const [filtroStatus, setFiltroStatus] = useState<string>('todos');
  const [busca, setBusca] = useState('');

  const formatarMoeda = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const pedidosFiltrados = pedidos.filter((p) => {
    const matchBusca =
      p.numero.toLowerCase().includes(busca.toLowerCase()) ||
      p.clienteNome.toLowerCase().includes(busca.toLowerCase()) ||
      p.clienteTelefone.toLowerCase().includes(busca.toLowerCase());

    const matchStatus = filtroStatus === 'todos' || p.status === filtroStatus;

    return matchBusca && matchStatus;
  });

  return (
    <div className="space-y-4">
      {/* Cabeçalho */}
      <div className="bg-white p-3 border border-neutral-300 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
        <div>
          <h1 className="text-sm sm:text-base font-semibold text-neutral-800">
            Pedidos Online
          </h1>
          <p className="text-xs text-neutral-500 font-normal">
            EletroDemaix • Controle de pedidos recebidos via canais digitais e e-commerce
          </p>
        </div>
        <div className="text-xs text-neutral-600 bg-[#f4f4f4] px-2.5 py-1 rounded border border-neutral-200">
          Total de Pedidos: <span className="font-semibold text-neutral-800">{pedidos.length}</span>
        </div>
      </div>

      {/* Tabela Compacta de Pedidos Online */}
      <div className="bg-white border border-neutral-300 rounded-lg p-3 sm:p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pb-2 border-b border-neutral-200">
          <input
            type="text"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar por número do pedido, cliente ou telefone..."
            className="w-full sm:w-72 px-2.5 py-1 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
          />

          <select
            value={filtroStatus}
            onChange={(e) => setFiltroStatus(e.target.value)}
            className="w-full sm:w-auto px-2.5 py-1 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none"
          >
            <option value="todos">Todos os Status</option>
            <option value="Aguardando Separação">Aguardando Separação</option>
            <option value="Em Separação">Em Separação</option>
            <option value="Pronto para Envio">Pronto para Envio</option>
            <option value="Cancelado">Cancelado</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-200 text-left text-[11px]">
            <thead className="bg-[#f4f4f4] text-neutral-700 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th scope="col" className="px-2 py-1.5">Pedido / Data</th>
                <th scope="col" className="px-2 py-1.5">Cliente e Telefone</th>
                <th scope="col" className="px-2 py-1.5">Cidade / Destino</th>
                <th scope="col" className="px-2 py-1.5">Itens do Pedido</th>
                <th scope="col" className="px-2 py-1.5 text-right">Total</th>
                <th scope="col" className="px-2 py-1.5 text-center">Status</th>
                <th scope="col" className="px-2 py-1.5 text-center">Avançar Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-neutral-800">
              {pedidosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-3 py-6 text-center text-neutral-500 font-normal">
                    Nenhum pedido online localizado com os filtros atuais.
                  </td>
                </tr>
              ) : (
                pedidosFiltrados.map((pedido) => (
                  <tr key={pedido.id} className="hover:bg-[#f4f4f4] transition-colors leading-tight">
                    <td className="px-2 py-1 whitespace-nowrap">
                      <div className="font-mono font-medium text-neutral-900 leading-tight">{pedido.numero}</div>
                      <div className="text-[10px] text-neutral-400 font-normal">{pedido.dataHora}</div>
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap">
                      <div className="font-medium text-neutral-900 leading-tight">{pedido.clienteNome}</div>
                      <div className="text-[10px] text-neutral-500 font-normal">{pedido.clienteTelefone}</div>
                    </td>

                    <td className="px-2 py-1">
                      <div className="font-medium text-neutral-800 leading-tight">{pedido.cidade}</div>
                      <div className="text-[10px] text-neutral-400 font-normal truncate max-w-[160px]" title={pedido.endereco}>
                        {pedido.endereco}
                      </div>
                    </td>

                    <td className="px-2 py-1">
                      {pedido.itens.length > 0 ? (
                        pedido.itens.map((it, idx) => (
                          <div key={idx} className="text-[10px] text-neutral-700 leading-tight">
                            {it.quantidade}x {it.produtoNome}
                          </div>
                        ))
                      ) : (
                        <span className="text-[10px] text-neutral-400">Eletrodoméstico Geral</span>
                      )}
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap text-right font-semibold text-neutral-900">
                      {formatarMoeda(pedido.total)}
                      <div className="text-[9px] text-neutral-400 font-normal">{pedido.pagamento}</div>
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap text-center">
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-medium ${
                          pedido.status === 'Pronto para Envio'
                            ? 'bg-neutral-800 text-white'
                            : pedido.status === 'Em Separação'
                            ? 'bg-orange-600 text-white'
                            : 'bg-[#f4f4f4] border border-neutral-300 text-neutral-800'
                        }`}
                      >
                        {pedido.status}
                      </span>
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap text-center">
                      <div className="inline-flex items-center gap-1">
                        {pedido.status === 'Aguardando Separação' && (
                          <button
                            type="button"
                            onClick={() => onAtualizarStatus(pedido.id, 'Em Separação')}
                            className="px-2 py-0.5 bg-orange-600 hover:bg-orange-700 text-white text-[10px] font-medium rounded transition-colors cursor-pointer"
                          >
                            Iniciar Separação
                          </button>
                        )}

                        {pedido.status === 'Em Separação' && (
                          <button
                            type="button"
                            onClick={() => onAtualizarStatus(pedido.id, 'Pronto para Envio')}
                            className="px-2 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-white text-[10px] font-medium rounded transition-colors cursor-pointer"
                          >
                            Pronto p/ Envio
                          </button>
                        )}

                        {pedido.status === 'Pronto para Envio' && (
                          <span className="text-[10px] text-neutral-400">Aguardando Coleta</span>
                        )}

                        {pedido.status === 'Cancelado' && (
                          <span className="text-[10px] text-neutral-400">Cancelado</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
