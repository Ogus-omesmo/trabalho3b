import React from 'react';
import { Funcionario } from '../types';

export type MainSection =
  | 'inicio'
  | 'cadastrar_item'
  | 'gerenciar_estoque'
  | 'fechar_venda'
  | 'historico_vendas'
  | 'pedidos_online'
  | 'envios';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeSection: MainSection;
  onSelectSection: (section: MainSection) => void;
  funcionario: Funcionario;
  onOpenConta: () => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  activeSection,
  onSelectSection,
  funcionario,
  onOpenConta,
  onLogout
}) => {
  if (!isOpen) return null;

  const handleSelect = (sec: MainSection) => {
    onSelectSection(sec);
    onClose();
  };

  return (
    <>
      {/* Backdrop para fechar ao clicar fora */}
      <div
        className="fixed inset-0 bg-black/40 z-50 transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Painel Lateral */}
      <aside className="fixed inset-y-0 left-0 w-72 sm:w-80 bg-white border-r border-neutral-300 z-50 shadow-2xl flex flex-col justify-between transition-transform duration-200 ease-in-out">
        <div>
          {/* Topo do Navbar Lateral com botão de perfil (silhueta) */}
          <div className="p-4 border-b border-neutral-200 bg-[#f4f4f4] flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                onOpenConta();
                onClose();
              }}
              className="flex items-center gap-3 text-left hover:opacity-80 transition-opacity cursor-pointer"
              title="Gerenciar Usuário"
            >
              {/* Silhueta da pessoa (do ombro pra cima) */}
              <div className="w-10 h-10 rounded-full bg-orange-600 text-white flex items-center justify-center shadow-xs">
                <svg
                  viewBox="0 0 24 24"
                  className="w-5 h-5 fill-none stroke-current stroke-2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
              </div>

              <div>
                <div className="text-sm font-semibold text-neutral-800">
                  {funcionario.nome}
                </div>
                <div className="text-xs text-neutral-500 font-normal">
                  Gerenciar Usuário
                </div>
              </div>
            </button>

            {/* Botão fechar barra lateral */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-200 transition-colors cursor-pointer text-sm font-medium"
              title="Fechar menu"
            >
              Fechar
            </button>
          </div>

          {/* Opções de Navegação Requisitadas */}
          <div className="p-3 space-y-1 text-xs sm:text-sm font-medium">
            <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
              Menu Principal
            </div>

            {/* 1. CADASTRAR ITEM */}
            <button
              type="button"
              onClick={() => handleSelect('cadastrar_item')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg transition-colors cursor-pointer ${
                activeSection === 'cadastrar_item'
                  ? 'bg-orange-600 text-white font-semibold shadow-xs'
                  : 'text-neutral-700 hover:bg-[#f4f4f4] hover:text-neutral-900'
              }`}
            >
              CADASTRAR ITEM
            </button>

            {/* 2. GERENCIAR ESTOQUE */}
            <button
              type="button"
              onClick={() => handleSelect('gerenciar_estoque')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg transition-colors cursor-pointer ${
                activeSection === 'gerenciar_estoque'
                  ? 'bg-orange-600 text-white font-semibold shadow-xs'
                  : 'text-neutral-700 hover:bg-[#f4f4f4] hover:text-neutral-900'
              }`}
            >
              GERENCIAR ESTOQUE
            </button>

            {/* 3. FECHAR VENDA */}
            <button
              type="button"
              onClick={() => handleSelect('fechar_venda')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg transition-colors cursor-pointer ${
                activeSection === 'fechar_venda'
                  ? 'bg-orange-600 text-white font-semibold shadow-xs'
                  : 'text-neutral-700 hover:bg-[#f4f4f4] hover:text-neutral-900'
              }`}
            >
              FECHAR VENDA
            </button>

            {/* 4. HISTÓRICO DE VENDAS */}
            <button
              type="button"
              onClick={() => handleSelect('historico_vendas')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg transition-colors cursor-pointer ${
                activeSection === 'historico_vendas'
                  ? 'bg-orange-600 text-white font-semibold shadow-xs'
                  : 'text-neutral-700 hover:bg-[#f4f4f4] hover:text-neutral-900'
              }`}
            >
              HISTÓRICO DE VENDAS
            </button>

            {/* 5. PEDIDOS ONLINE */}
            <button
              type="button"
              onClick={() => handleSelect('pedidos_online')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg transition-colors cursor-pointer ${
                activeSection === 'pedidos_online'
                  ? 'bg-orange-600 text-white font-semibold shadow-xs'
                  : 'text-neutral-700 hover:bg-[#f4f4f4] hover:text-neutral-900'
              }`}
            >
              PEDIDOS ONLINE
            </button>

            {/* 6. ENVIOS */}
            <button
              type="button"
              onClick={() => handleSelect('envios')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg transition-colors cursor-pointer ${
                activeSection === 'envios'
                  ? 'bg-orange-600 text-white font-semibold shadow-xs'
                  : 'text-neutral-700 hover:bg-[#f4f4f4] hover:text-neutral-900'
              }`}
            >
              ENVIOS
            </button>

            {/* Opção para voltar à Tela Branca */}
            <div className="pt-2 border-t border-neutral-200 mt-2">
              <button
                type="button"
                onClick={() => handleSelect('inicio')}
                className={`w-full text-left px-3.5 py-2 rounded-lg text-xs font-normal transition-colors cursor-pointer ${
                  activeSection === 'inicio'
                    ? 'bg-neutral-800 text-white font-medium'
                    : 'text-neutral-500 hover:bg-[#f4f4f4] hover:text-neutral-800'
                }`}
              >
                Tela Inicial (Em Branco)
              </button>
            </div>
          </div>
        </div>

        {/* Rodapé da Barra Lateral com Logout */}
        <div className="p-3 border-t border-neutral-200 bg-[#f4f4f4] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img
              src="/favicon.png"
              alt="EletroDemaix"
              className="w-5 h-5 object-contain mix-blend-multiply select-none"
            />
            <span className="text-xs text-neutral-700 font-medium">
              EletroDemaix
            </span>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="px-3 py-1.5 rounded-lg text-xs font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            Sair
          </button>
        </div>
      </aside>
    </>
  );
};
