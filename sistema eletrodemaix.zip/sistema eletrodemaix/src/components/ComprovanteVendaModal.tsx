import React from 'react';
import { Venda } from '../types';

interface ComprovanteVendaModalProps {
  venda: Venda;
  onFechar: () => void;
}

export const ComprovanteVendaModal: React.FC<ComprovanteVendaModalProps> = ({
  venda,
  onFechar
}) => {
  const formatarMoeda = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const handleImprimir = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg max-w-lg w-full p-5 border border-orange-500 my-8 shadow-xl">
        {/* Barra Superior */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200 print:hidden">
          <span className="font-semibold text-neutral-800 text-sm">
            Comprovante de Pedido e Venda
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleImprimir}
              className="px-3 py-1 bg-orange-600 hover:bg-orange-700 text-white font-medium text-xs rounded"
            >
              Imprimir Recibo
            </button>
            <button
              onClick={onFechar}
              className="text-neutral-600 hover:text-neutral-900 font-medium text-xs px-2 py-0.5 bg-[#f4f4f4] rounded"
            >
              Fechar
            </button>
          </div>
        </div>

        {/* Recibo Formatado para Impressão */}
        <div className="mt-3 p-4 border border-dashed border-neutral-300 bg-[#f4f4f4] text-neutral-800 font-mono text-xs space-y-3">
          <div className="text-center pb-2 border-b border-dashed border-neutral-300">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <img src="/favicon.png" alt="EletroDemaix" className="w-5 h-5 object-contain mix-blend-multiply select-none" />
              <span className="font-semibold text-sm text-neutral-900">ELETRODEMAIX • VENDAS E ESTOQUE</span>
            </div>
            <div className="text-[10px] text-neutral-500">CNPJ: 12.345.678/0001-90</div>
            <div className="text-[10px] text-neutral-500">Av. Central, 1000 • Tel: (11) 3300-8000</div>
            <div className="mt-1 font-medium bg-white py-0.5 border border-neutral-200">
              Cupom de Venda de Eletrodomésticos
            </div>
          </div>

          <div className="space-y-0.5 text-[11px] pb-2 border-b border-dashed border-neutral-300">
            <div>Pedido: <strong className="font-semibold">{venda.numero}</strong></div>
            <div>Data e Hora: {venda.dataHora}</div>
            <div>Vendedor: {venda.vendedorNome}</div>
            <div>Cliente: {venda.clienteNome}</div>
            {venda.clienteCpf && <div>Documento: {venda.clienteCpf}</div>}
          </div>

          <div>
            <div className="font-semibold pb-1 text-[11px] uppercase">Itens da Venda:</div>
            {venda.itens.map((it, idx) => (
              <div key={idx} className="flex justify-between items-start text-[11px] py-0.5">
                <div>
                  <div className="font-medium text-neutral-900">{it.nome}</div>
                  <div className="text-[10px] text-neutral-500">
                    Código: {it.codigo} | {it.voltagem} | {it.quantidade} un. x {formatarMoeda(it.precoUnitario)}
                  </div>
                </div>
                <div className="font-semibold text-neutral-900">{formatarMoeda(it.subtotal)}</div>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-dashed border-neutral-300 space-y-0.5 text-[11px]">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>{formatarMoeda(venda.subtotal)}</span>
            </div>
            {venda.desconto > 0 && (
              <div className="flex justify-between">
                <span>Desconto:</span>
                <span>- {formatarMoeda(venda.desconto)}</span>
              </div>
            )}
            <div className="flex justify-between font-semibold text-sm pt-1 border-t border-neutral-300 text-neutral-900">
              <span>Total Pago:</span>
              <span>{formatarMoeda(venda.total)}</span>
            </div>
            <div className="text-[10px] text-neutral-500">
              Forma de Pagamento: {venda.formaPagamento.toUpperCase()}
            </div>
          </div>

          <div className="pt-2 border-t border-dashed border-neutral-300 text-[10px] text-neutral-500">
            Garantia legal de 90 dias conforme CDC, mais garantia do fabricante do eletrodoméstico.
          </div>

          <div className="pt-4 text-center text-[10px] text-neutral-500">
            <div className="border-t border-neutral-300 w-2/3 mx-auto mb-1"></div>
            Assinatura do Recebedor
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-200 mt-3 print:hidden">
          <button
            type="button"
            onClick={onFechar}
            className="px-3 py-1.5 bg-[#f4f4f4] hover:bg-neutral-200 text-neutral-700 font-medium text-xs rounded"
          >
            Fechar
          </button>
          <button
            type="button"
            onClick={handleImprimir}
            className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white font-medium text-xs rounded"
          >
            Imprimir
          </button>
        </div>
      </div>
    </div>
  );
};
