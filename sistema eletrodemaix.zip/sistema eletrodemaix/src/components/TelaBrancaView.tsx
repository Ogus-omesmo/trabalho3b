import React from 'react';

interface TelaBrancaViewProps {
  onAbrirMenu: () => void;
}

export const TelaBrancaView: React.FC<TelaBrancaViewProps> = ({ onAbrirMenu }) => {
  return (
    <div className="min-h-[calc(100vh-7rem)] bg-white flex flex-col items-center justify-center p-6 text-center">
      {/* Tela branca limpa, sem excesso de informações direto */}
      <div className="max-w-md w-full py-16 px-4">
        <div className="flex justify-center mb-4">
          <img src="/favicon.png" alt="EletroDemaix" className="w-16 h-16 object-contain mix-blend-multiply select-none" />
        </div>

        <h2 className="text-base font-semibold text-neutral-800">
          EletroDemaix
        </h2>

        <p className="text-xs text-neutral-400 mt-1 font-normal">
          Clique no menu lateral com as 3 linhas horizontais no canto superior esquerdo para acessar as opções do sistema.
        </p>

        <button
          type="button"
          onClick={onAbrirMenu}
          className="mt-5 px-4 py-2 bg-[#f4f4f4] hover:bg-neutral-200 border border-neutral-300 text-neutral-700 text-xs font-medium rounded-lg transition-colors cursor-pointer"
        >
          Abrir Menu Lateral
        </button>
      </div>
    </div>
  );
};
