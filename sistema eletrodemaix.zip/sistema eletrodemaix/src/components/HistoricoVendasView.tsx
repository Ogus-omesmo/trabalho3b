import React, { useState } from 'react';
import { Venda } from '../types';

interface HistoricoVendasViewProps {
  vendas: Venda[];
  onCancelarVenda: (vendaId: string) => void;
  onImprimirComprovante: (venda: Venda) => void;
}

export const HistoricoVendasView: React.FC<HistoricoVendasViewProps> = ({
  vendas,
  onCancelarVenda,
  onImprimirComprovante
}) => {
  const [buscaVenda, setBuscaVenda] = useState('');

  const formatarMoeda = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const vendasFiltradas = vendas.filter(
    (v) =>
      v.numero.toLowerCase().includes(buscaVenda.toLowerCase()) ||
      v.clienteNome.toLowerCase().includes(buscaVenda.toLowerCase()) ||
      v.vendedorNome.toLowerCase().includes(buscaVenda.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Cabeçalho */}
      <div className="bg-white p-3 border border-neutral-300 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
        <div>
          <h1 className="text-sm sm:text-base font-semibold text-neutral-800">
            Histórico de Vendas
          </h1>
          <p className="text-xs text-neutral-500 font-normal">
            EletroDemaix • Relatório de vendas realizadas, comprovantes e estorno de pedidos
          </p>
        </div>
        <div className="text-xs text-neutral-600 bg-[#f4f4f4] px-2.5 py-1 rounded border border-neutral-200">
          Total de Vendas: <strong className="font-semibold text-neutral-800">{vendas.length}</strong>
        </div>
      </div>

      {/* Histórico de Vendas Compacto */}
      <div className="bg-white border border-neutral-300 rounded-lg p-3 sm:p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-neutral-200">
          <span className="text-[11px] font-semibold text-neutral-800 uppercase tracking-wide">
            Vendas Concluídas e Canceladas
          </span>

          <input
            type="text"
            value={buscaVenda}
            onChange={(e) => setBuscaVenda(e.target.value)}
            placeholder="Buscar pedido, cliente ou vendedor..."
            className="w-full sm:w-64 px-2.5 py-1 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-200 text-left text-[11px]">
            <thead className="bg-[#f4f4f4] text-neutral-700 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th scope="col" className="px-2 py-1.5">Pedido / Data</th>
                <th scope="col" className="px-2 py-1.5">Cliente</th>
                <th scope="col" className="px-2 py-1.5">Eletrodoméstico(s)</th>
                <th scope="col" className="px-2 py-1.5">Vendedor</th>
                <th scope="col" className="px-2 py-1.5 text-right">Total</th>
                <th scope="col" className="px-2 py-1.5 text-center">Status</th>
                <th scope="col" className="px-2 py-1.5 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-neutral-800">
              {vendasFiltradas.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-3 py-6 text-center text-neutral-500 font-normal">
                    Nenhuma venda encontrada no histórico.
                  </td>
                </tr>
              ) : (
                vendasFiltradas.map((v) => (
                  <tr
                    key={v.id}
                    className={`hover:bg-[#f4f4f4] transition-colors leading-tight ${
                      v.status === 'cancelada' ? 'opacity-60 bg-neutral-100/60' : ''
                    }`}
                  >
                    <td className="px-2 py-1 whitespace-nowrap">
                      <div className="font-mono font-medium text-neutral-900 leading-tight">{v.numero}</div>
                      <div className="text-[10px] text-neutral-400 font-normal">{v.dataHora}</div>
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap">
                      <div className="font-medium text-neutral-900 leading-tight">{v.clienteNome}</div>
                      <div className="text-[10px] text-neutral-500 font-normal">Doc: {v.clienteCpf}</div>
                    </td>

                    <td className="px-2 py-1">
                      {v.itens.map((it, idx) => (
                        <div key={idx} className="font-normal text-neutral-800 leading-tight text-[11px]">
                          {it.quantidade}x {it.nome} ({it.voltagem})
                          <span className="text-[9px] text-neutral-400 font-mono ml-1">[{it.codigo}]</span>
                        </div>
                      ))}
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap text-neutral-600 font-normal">
                      {v.vendedorNome}
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap text-right font-semibold text-neutral-900">
                      {formatarMoeda(v.total)}
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap text-center">
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-medium ${
                          v.status === 'concluida'
                            ? 'bg-neutral-800 text-white'
                            : 'bg-neutral-200 text-neutral-700'
                        }`}
                      >
                        {v.status === 'concluida' ? 'Concluída' : 'Cancelada'}
                      </span>
                    </td>

                    <td className="px-2 py-1 whitespace-nowrap text-center">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onImprimirComprovante(v)}
                          className="px-2 py-0.5 bg-[#f4f4f4] hover:bg-neutral-200 border border-neutral-300 text-neutral-800 font-medium rounded text-[10px] cursor-pointer"
                          title="Imprimir Comprovante"
                        >
                          Imprimir
                        </button>
                        {v.status === 'concluida' && (
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`Deseja cancelar a venda ${v.numero} e estornar os produtos ao estoque?`)) {
                                onCancelarVenda(v.id);
                              }
                            }}
                            className="px-2 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-white font-medium rounded text-[10px] cursor-pointer"
                            title="Cancelar Venda e Devolver ao Estoque"
                          >
                            Cancelar
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
