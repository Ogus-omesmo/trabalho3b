import React, { useState } from 'react';
import { Eletrodomestico, Venda, Funcionario, FormaPagamento } from '../types';

interface FecharVendaViewProps {
  funcionario: Funcionario;
  eletrodomesticos: Eletrodomestico[];
  onFinalizarVenda: (novaVenda: Venda) => void;
}

export const FecharVendaView: React.FC<FecharVendaViewProps> = ({
  funcionario,
  eletrodomesticos,
  onFinalizarVenda
}) => {
  const [produtoId, setProdutoId] = useState<string>(eletrodomesticos[0]?.id || '');
  const [quantidade, setQuantidade] = useState<number>(1);
  const [clienteNome, setClienteNome] = useState('');
  const [clienteDoc, setClienteDoc] = useState('');
  const [formaPagamento, setFormaPagamento] = useState<FormaPagamento>('pix');
  const [desconto, setDesconto] = useState<number>(0);
  const [mensagem, setMensagem] = useState('');

  const produtoSelecionado = eletrodomesticos.find((p) => p.id === produtoId);
  const precoUnitario = produtoSelecionado ? produtoSelecionado.precoVenda : 0;
  const subtotal = precoUnitario * (quantidade || 1);
  const totalFinal = Math.max(0, subtotal - (desconto || 0));

  const formatarMoeda = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const handleRegistrarVenda = (e: React.FormEvent) => {
    e.preventDefault();

    if (!produtoSelecionado) {
      alert('Selecione um eletrodoméstico para a venda.');
      return;
    }

    if (quantidade <= 0) {
      alert('A quantidade deve ser de pelo menos 1 unidade.');
      return;
    }

    if (quantidade > produtoSelecionado.estoque) {
      alert(`Estoque insuficiente! Disponível apenas: ${produtoSelecionado.estoque} unidades.`);
      return;
    }

    if (!clienteNome.trim()) {
      alert('Informe o nome do cliente.');
      return;
    }

    const agora = new Date();
    const dataHoraFormatada = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, '0')}-${String(agora.getDate()).padStart(2, '0')} ${String(agora.getHours()).padStart(2, '0')}:${String(agora.getMinutes()).padStart(2, '0')}`;

    const novaVenda: Venda = {
      id: `ven-${Date.now()}`,
      numero: `PED-${agora.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      dataHora: dataHoraFormatada,
      vendedorId: funcionario.id,
      vendedorNome: funcionario.nome,
      clienteNome: clienteNome.trim(),
      clienteCpf: clienteDoc.trim() || 'Não informado',
      clienteTelefone: 'Não informado',
      itens: [
        {
          produtoId: produtoSelecionado.id,
          codigo: produtoSelecionado.codigo,
          nome: produtoSelecionado.nome,
          marca: produtoSelecionado.marca,
          voltagem: produtoSelecionado.voltagem,
          quantidade,
          precoUnitario: produtoSelecionado.precoVenda,
          subtotal
        }
      ],
      subtotal,
      desconto: Number(desconto) || 0,
      total: totalFinal,
      formaPagamento,
      tipoEntrega: 'retirada',
      status: 'concluida'
    };

    onFinalizarVenda(novaVenda);
    setMensagem(`Venda ${novaVenda.numero} concluída com sucesso! Baixa de ${quantidade} unidade(s) efetuada no estoque.`);
    setClienteNome('');
    setClienteDoc('');
    setQuantidade(1);
    setDesconto(0);
    setTimeout(() => setMensagem(''), 5000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Cabeçalho */}
      <div className="bg-white p-4 border border-neutral-300 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <h1 className="text-base font-semibold text-neutral-800">
            Fechar Venda
          </h1>
          <p className="text-xs text-neutral-500 font-normal">
            Emissão de pedido de venda com baixa imediata no estoque
          </p>
        </div>
        <div className="text-xs text-neutral-700 bg-[#f4f4f4] px-3 py-1.5 rounded border border-neutral-200">
          Vendedor Ativo: <strong className="font-semibold">{funcionario.nome}</strong>
        </div>
      </div>

      {mensagem && (
        <div className="p-3 bg-white border border-orange-500 text-neutral-800 text-xs font-medium rounded shadow-xs">
          {mensagem}
        </div>
      )}

      {/* Formulário de Registro de Venda */}
      <div className="bg-white border border-neutral-300 rounded-lg p-6 shadow-xs">
        <form onSubmit={handleRegistrarVenda} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* Seleção do Produto */}
            <div className="sm:col-span-2">
              <label className="block text-neutral-700 font-medium mb-1">
                Eletrodoméstico do Estoque *
              </label>
              <select
                value={produtoId}
                onChange={(e) => setProdutoId(e.target.value)}
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              >
                {eletrodomesticos.map((p) => (
                  <option key={p.id} value={p.id} disabled={p.estoque <= 0}>
                    {p.codigo} - {p.nome} ({p.voltagem}) - Estoque: {p.estoque} un. - {formatarMoeda(p.precoVenda)}
                    {p.estoque <= 0 ? ' (Esgotado)' : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Quantidade */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Quantidade *
              </label>
              <input
                type="number"
                min="1"
                max={produtoSelecionado ? produtoSelecionado.estoque : 100}
                value={quantidade}
                onChange={(e) => setQuantidade(Math.max(1, parseInt(e.target.value) || 1))}
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 font-medium text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
              <span className="text-[11px] text-neutral-500 mt-0.5 block font-normal">
                Disponível no depósito:{' '}
                <strong className="font-semibold">{produtoSelecionado ? produtoSelecionado.estoque : 0} un.</strong>
              </span>
            </div>

            {/* Nome do Cliente */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Nome do Cliente *
              </label>
              <input
                type="text"
                value={clienteNome}
                onChange={(e) => setClienteNome(e.target.value)}
                placeholder="Ex: João da Silva"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* CPF ou Documento */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                CPF ou CNPJ do Cliente
              </label>
              <input
                type="text"
                value={clienteDoc}
                onChange={(e) => setClienteDoc(e.target.value)}
                placeholder="000.000.000-00"
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Forma de Pagamento */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Forma de Pagamento *
              </label>
              <select
                value={formaPagamento}
                onChange={(e) => setFormaPagamento(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              >
                <option value="pix">PIX (À Vista)</option>
                <option value="dinheiro">Dinheiro</option>
                <option value="cartao_debito">Cartão de Débito</option>
                <option value="cartao_credito">Cartão de Crédito</option>
                <option value="boleto">Boleto ou Carnê</option>
              </select>
            </div>
          </div>

          {/* Resumo de Valores */}
          <div className="p-3.5 bg-[#f4f4f4] border border-neutral-200 rounded-lg flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
            <div className="flex items-center gap-4">
              <div>
                <span className="text-neutral-500 block font-normal">Subtotal:</span>
                <span className="font-semibold text-neutral-800">{formatarMoeda(subtotal)}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-neutral-500 font-normal">Desconto (R$):</span>
                <input
                  type="number"
                  min="0"
                  max={subtotal}
                  value={desconto || ''}
                  onChange={(e) => setDesconto(Number(e.target.value) || 0)}
                  placeholder="0,00"
                  className="w-20 px-2 py-1 bg-white border border-neutral-300 rounded font-medium text-neutral-800"
                />
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <span className="text-[11px] font-normal text-neutral-500 block">
                  Total da Venda:
                </span>
                <span className="text-base font-semibold text-orange-600">
                  {formatarMoeda(totalFinal)}
                </span>
              </div>

              <button
                type="submit"
                disabled={!produtoSelecionado || produtoSelecionado.estoque <= 0}
                className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-medium text-xs sm:text-sm rounded transition-colors shadow-xs disabled:opacity-40 cursor-pointer"
              >
                Concluir Venda e Baixar Estoque
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
