import React, { useState } from 'react';
import { Eletrodomestico, CategoriaEletro, Voltagem, Funcionario } from '../types';

interface EstoqueViewProps {
  funcionario: Funcionario;
  eletrodomesticos: Eletrodomestico[];
  onAdicionarProduto: (produto: Eletrodomestico) => void;
  onEditarProduto: (produto: Eletrodomestico) => void;
  onExcluirProduto: (id: string) => void;
  onAjustarEstoqueRapido: (id: string, delta: number) => void;
}

const CATEGORIAS: CategoriaEletro[] = [
  'Refrigeração',
  'Lavanderia',
  'Cocção',
  'Eletroportáteis',
  'Climatização',
  'TVs e Áudio',
  'Linha Branca'
];

export const EstoqueView: React.FC<EstoqueViewProps> = ({
  funcionario,
  eletrodomesticos,
  onAdicionarProduto,
  onEditarProduto,
  onExcluirProduto,
  onAjustarEstoqueRapido
}) => {
  // Busca e Filtros
  const [busca, setBusca] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState<string>('todas');
  const [voltagemFiltro, setVoltagemFiltro] = useState<string>('todas');

  // Estado do Formulário de Cadastro (padrão de código: ELTDMS - XXXX)
  const [formCodigo, setFormCodigo] = useState(`ELTDMS - ${Math.floor(1000 + Math.random() * 9000)}`);
  const [formNome, setFormNome] = useState('');
  const [formCategoria, setFormCategoria] = useState<CategoriaEletro>('Refrigeração');
  const [formMarca, setFormMarca] = useState('');
  const [formModelo, setFormModelo] = useState('');
  const [formVoltagem, setFormVoltagem] = useState<Voltagem>('110V');
  const [formPrecoCusto, setFormPrecoCusto] = useState<number | ''>('');
  const [formPrecoVenda, setFormPrecoVenda] = useState<number | ''>('');
  const [formEstoque, setFormEstoque] = useState<number | ''>(10);
  const [formEstoqueMinimo, setFormEstoqueMinimo] = useState<number | ''>(4);
  const [formLocalizacao, setFormLocalizacao] = useState('Corredor 1');
  const [mensagemSucesso, setMensagemSucesso] = useState('');

  // Modais de Edição e Exclusão
  const [produtoEditando, setProdutoEditando] = useState<Eletrodomestico | null>(null);
  const [produtoExcluir, setProdutoExcluir] = useState<Eletrodomestico | null>(null);

  // Submissão do Formulário de Cadastro
  const handleCriarProduto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNome.trim() || !formMarca.trim() || Number(formPrecoVenda) <= 0) {
      alert('Preencha os campos obrigatórios com valores válidos.');
      return;
    }

    const novoProduto: Eletrodomestico = {
      id: `eletro-${Date.now()}`,
      codigo: formCodigo.trim() || `ELTDMS - ${Math.floor(1000 + Math.random() * 9000)}`,
      nome: formNome.trim(),
      categoria: formCategoria,
      marca: formMarca.trim(),
      modelo: formModelo.trim(),
      voltagem: formVoltagem,
      cor: 'Padrão',
      precoCusto: Number(formPrecoCusto) || 0,
      precoVenda: Number(formPrecoVenda) || 0,
      estoque: Number(formEstoque) || 0,
      estoqueMinimo: Number(formEstoqueMinimo) || 0,
      localizacao: formLocalizacao.trim() || 'Depósito Principal',
      garantiaMeses: 12,
      ativo: true
    };

    onAdicionarProduto(novoProduto);

    // Limpar formulário e gerar novo código no padrão ELTDMS - XXXX
    setFormCodigo(`ELTDMS - ${Math.floor(1000 + Math.random() * 9000)}`);
    setFormNome('');
    setFormMarca('');
    setFormModelo('');
    setFormPrecoCusto('');
    setFormPrecoVenda('');
    setFormEstoque(10);
    setMensagemSucesso(`Eletrodoméstico "${novoProduto.nome}" cadastrado com sucesso no estoque!`);
    setTimeout(() => setMensagemSucesso(''), 4000);
  };

  // Submissão da Edição
  const handleSalvarEdicao = (e: React.FormEvent) => {
    e.preventDefault();
    if (!produtoEditando) return;

    onEditarProduto(produtoEditando);
    setProdutoEditando(null);
    setMensagemSucesso(`Eletrodoméstico "${produtoEditando.nome}" atualizado com sucesso!`);
    setTimeout(() => setMensagemSucesso(''), 4000);
  };

  // Filtragem
  const produtosFiltrados = eletrodomesticos.filter((item) => {
    const matchBusca =
      item.nome.toLowerCase().includes(busca.toLowerCase()) ||
      item.codigo.toLowerCase().includes(busca.toLowerCase()) ||
      item.marca.toLowerCase().includes(busca.toLowerCase());

    const matchCategoria = categoriaFiltro === 'todas' || item.categoria === categoriaFiltro;
    const matchVoltagem = voltagemFiltro === 'todas' || item.voltagem === voltagemFiltro;

    return matchBusca && matchCategoria && matchVoltagem;
  });

  const formatarMoeda = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho da Seção */}
      <div className="bg-white p-3 border border-neutral-300 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
        <div>
          <h1 className="text-sm sm:text-base font-semibold text-neutral-800">
            Controle de Estoque de Eletrodomésticos
          </h1>
          <p className="text-xs text-neutral-500 font-normal">
            EletroDemaix • Gerenciamento de produtos, especificações e quantidades
          </p>
        </div>
        <div className="text-xs text-neutral-700 bg-[#f4f4f4] px-2.5 py-1 rounded border border-neutral-200">
          Total no Estoque: <span className="text-orange-600 font-semibold">{eletrodomesticos.length}</span> modelos
        </div>
      </div>

      {mensagemSucesso && (
        <div className="p-3 bg-white border border-orange-500 text-neutral-800 text-xs font-medium rounded shadow-sm">
          {mensagemSucesso}
        </div>
      )}

      {/* 1. FORMULÁRIO DE CADASTRO */}
      <div className="bg-white border border-neutral-300 rounded-lg p-5 shadow-sm">
        <div className="pb-3 mb-4 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="text-xs font-semibold text-neutral-800 uppercase tracking-wide">
            Formulário de Cadastro • Novo Eletrodoméstico
          </h2>
          <span className="text-xs text-neutral-400 font-normal">
            Padrão de Código: ELTDMS - XXXX
          </span>
        </div>

        <form onSubmit={handleCriarProduto} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            {/* Código / SKU */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Código (SKU) *
              </label>
              <input
                type="text"
                value={formCodigo}
                onChange={(e) => setFormCodigo(e.target.value)}
                placeholder="ELTDMS - 1001"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 font-mono text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Nome do Produto */}
            <div className="sm:col-span-2">
              <label className="block text-neutral-700 font-medium mb-1">
                Nome do Eletrodoméstico *
              </label>
              <input
                type="text"
                value={formNome}
                onChange={(e) => setFormNome(e.target.value)}
                placeholder="Ex: Geladeira Brastemp Frost Free Duplex"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Categoria */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Categoria *
              </label>
              <select
                value={formCategoria}
                onChange={(e) => setFormCategoria(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              >
                {CATEGORIAS.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Marca */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Marca *
              </label>
              <input
                type="text"
                value={formMarca}
                onChange={(e) => setFormMarca(e.target.value)}
                placeholder="Ex: Brastemp, Electrolux"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Modelo */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Modelo
              </label>
              <input
                type="text"
                value={formModelo}
                onChange={(e) => setFormModelo(e.target.value)}
                placeholder="Ex: BRM44HK"
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Voltagem */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Voltagem *
              </label>
              <select
                value={formVoltagem}
                onChange={(e) => setFormVoltagem(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              >
                <option value="110V">110V</option>
                <option value="220V">220V</option>
                <option value="Bivolt">Bivolt</option>
              </select>
            </div>

            {/* Localização */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Localização no Depósito
              </label>
              <input
                type="text"
                value={formLocalizacao}
                onChange={(e) => setFormLocalizacao(e.target.value)}
                placeholder="Ex: Corredor A, Prateleira 2"
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Preço de Custo */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Preço de Custo (R$)
              </label>
              <input
                type="number"
                step="0.01"
                value={formPrecoCusto}
                onChange={(e) => setFormPrecoCusto(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0.00"
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Preço de Venda */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Preço de Venda (R$) *
              </label>
              <input
                type="number"
                step="0.01"
                value={formPrecoVenda}
                onChange={(e) => setFormPrecoVenda(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0.00"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-orange-500 rounded text-neutral-900 font-semibold text-xs focus:outline-none focus:bg-white"
              />
            </div>

            {/* Quantidade em Estoque */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Quantidade em Estoque *
              </label>
              <input
                type="number"
                min="0"
                value={formEstoque}
                onChange={(e) => setFormEstoque(e.target.value === '' ? '' : Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Estoque Mínimo */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Estoque Mínimo (Alerta)
              </label>
              <input
                type="number"
                min="1"
                value={formEstoqueMinimo}
                onChange={(e) => setFormEstoqueMinimo(e.target.value === '' ? '' : Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-200">
            <button
              type="submit"
              className="px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white font-medium text-xs sm:text-sm rounded transition-colors shadow-sm cursor-pointer"
            >
              Cadastrar Eletrodoméstico no Estoque
            </button>
          </div>
        </form>
      </div>

      {/* 2. TABELA DE CONSULTA DE ESTOQUE */}
      <div className="bg-white border border-neutral-300 rounded-lg p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-neutral-200">
          <h2 className="text-xs font-semibold text-neutral-800 uppercase tracking-wide">
            Eletrodomésticos Cadastrados no Estoque
          </h2>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Campo de Busca */}
            <input
              type="text"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              placeholder="Buscar por nome, código ou marca..."
              className="w-64 px-3 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
            />

            {/* Filtro Categoria */}
            <select
              value={categoriaFiltro}
              onChange={(e) => setCategoriaFiltro(e.target.value)}
              className="px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none"
            >
              <option value="todas">Todas as Categorias</option>
              {CATEGORIAS.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>

            {/* Filtro Voltagem */}
            <select
              value={voltagemFiltro}
              onChange={(e) => setVoltagemFiltro(e.target.value)}
              className="px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none"
            >
              <option value="todas">Todas as Voltagens</option>
              <option value="110V">110V</option>
              <option value="220V">220V</option>
              <option value="Bivolt">Bivolt</option>
            </select>
          </div>
        </div>

        {/* Tabela de Produtos Compacta */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-200 text-left text-[11px]">
            <thead className="bg-[#f4f4f4] text-neutral-700 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th scope="col" className="px-2 py-1.5">Código (SKU)</th>
                <th scope="col" className="px-2 py-1.5">Eletrodoméstico e Marca</th>
                <th scope="col" className="px-2 py-1.5">Categoria</th>
                <th scope="col" className="px-2 py-1.5">Voltagem</th>
                <th scope="col" className="px-2 py-1.5 text-right">Preço Venda</th>
                <th scope="col" className="px-2 py-1.5 text-center">Estoque</th>
                <th scope="col" className="px-2 py-1.5">Local</th>
                <th scope="col" className="px-2 py-1.5 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-neutral-800">
              {produtosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-3 py-6 text-center text-neutral-500 font-normal">
                    Nenhum produto encontrado para os filtros informados.
                  </td>
                </tr>
              ) : (
                produtosFiltrados.map((item) => {
                  const isZerado = item.estoque <= 0;
                  const isBaixo = !isZerado && item.estoque <= item.estoqueMinimo;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-[#f4f4f4] transition-colors leading-tight ${
                        isZerado ? 'bg-neutral-100/60' : ''
                      }`}
                    >
                      {/* Código SKU */}
                      <td className="px-2 py-1 whitespace-nowrap font-mono font-medium text-neutral-800">
                        {item.codigo}
                      </td>

                      {/* Nome e Marca */}
                      <td className="px-2 py-1">
                        <div className="font-medium text-neutral-900 leading-tight">{item.nome}</div>
                        <div className="text-[10px] text-neutral-400 font-normal">
                          {item.marca}{item.modelo ? ` • ${item.modelo}` : ''}
                        </div>
                      </td>

                      {/* Categoria */}
                      <td className="px-2 py-1 whitespace-nowrap">
                        <span className="px-1.5 py-0.2 bg-[#f4f4f4] border border-neutral-200 rounded text-neutral-700 text-[10px]">
                          {item.categoria}
                        </span>
                      </td>

                      {/* Voltagem */}
                      <td className="px-2 py-1 whitespace-nowrap">
                        <span className="px-1.5 py-0.2 bg-neutral-800 text-white rounded font-medium text-[10px]">
                          {item.voltagem}
                        </span>
                      </td>

                      {/* Preço de Venda */}
                      <td className="px-2 py-1 whitespace-nowrap text-right font-semibold text-neutral-900">
                        {formatarMoeda(item.precoVenda)}
                        {item.precoCusto > 0 && (
                          <div className="text-[9px] text-neutral-400 font-normal">
                            Custo: {formatarMoeda(item.precoCusto)}
                          </div>
                        )}
                      </td>

                      {/* Estoque Atual */}
                      <td className="px-2 py-1 whitespace-nowrap text-center">
                        <div className="inline-flex items-center gap-1">
                          <span
                            className={`px-1.5 py-0.2 rounded text-[10px] ${
                              isZerado
                                ? 'bg-neutral-800 text-white font-medium'
                                : isBaixo
                                ? 'bg-orange-600 text-white font-medium'
                                : 'bg-[#f4f4f4] border border-neutral-300 text-neutral-800 font-medium'
                            }`}
                          >
                            {item.estoque} un.
                          </span>
                        </div>
                        {isBaixo && (
                          <div className="text-[9px] text-orange-600 font-medium">
                            Baixo
                          </div>
                        )}
                        {isZerado && (
                          <div className="text-[9px] text-neutral-500 font-medium">
                            Esgotado
                          </div>
                        )}
                      </td>

                      {/* Localização */}
                      <td className="px-2 py-1 whitespace-nowrap text-[10px] text-neutral-600 font-normal">
                        {item.localizacao}
                      </td>

                      {/* Ações */}
                      <td className="px-2 py-1 whitespace-nowrap text-center">
                        <div className="inline-flex items-center gap-1">
                          {/* Ajuste rápido +1 / -1 */}
                          <button
                            type="button"
                            onClick={() => onAjustarEstoqueRapido(item.id, 1)}
                            className="px-1.5 py-0.5 bg-[#f4f4f4] hover:bg-neutral-200 border border-neutral-300 text-neutral-800 font-medium rounded text-[10px] cursor-pointer"
                            title="Adicionar 1 un."
                          >
                            +1
                          </button>
                          <button
                            type="button"
                            onClick={() => onAjustarEstoqueRapido(item.id, -1)}
                            disabled={item.estoque <= 0}
                            className="px-1.5 py-0.5 bg-[#f4f4f4] hover:bg-neutral-200 border border-neutral-300 text-neutral-800 font-medium rounded text-[10px] disabled:opacity-30 cursor-pointer"
                            title="Remover 1 un."
                          >
                            -1
                          </button>

                          {/* Botão Editar */}
                          <button
                            type="button"
                            onClick={() => setProdutoEditando({ ...item })}
                            className="px-2 py-0.5 bg-orange-600 hover:bg-orange-700 text-white font-medium rounded text-[10px] cursor-pointer"
                            title="Editar"
                          >
                            Editar
                          </button>

                          {/* Botão Excluir */}
                          <button
                            type="button"
                            onClick={() => setProdutoExcluir(item)}
                            className="px-2 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-white font-medium rounded text-[10px] cursor-pointer"
                            title="Excluir"
                          >
                            Excluir
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. MODAL DE EDIÇÃO */}
      {produtoEditando && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-lg max-w-xl w-full p-5 border border-orange-500 my-8 shadow-lg">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
              <h3 className="text-sm font-semibold text-neutral-800">
                Editar Dados do Eletrodoméstico
              </h3>
              <button
                type="button"
                onClick={() => setProdutoEditando(null)}
                className="text-neutral-500 hover:text-neutral-800 text-xs px-2 py-0.5 bg-[#f4f4f4] rounded"
              >
                Fechar
              </button>
            </div>

            <form onSubmit={handleSalvarEdicao} className="mt-4 space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Código (SKU)</label>
                  <input
                    type="text"
                    value={produtoEditando.codigo}
                    onChange={(e) =>
                      setProdutoEditando({ ...produtoEditando, codigo: e.target.value })
                    }
                    placeholder="ELTDMS - 1001"
                    required
                    className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded font-mono text-neutral-800"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Nome do Produto</label>
                  <input
                    type="text"
                    value={produtoEditando.nome}
                    onChange={(e) =>
                      setProdutoEditando({ ...produtoEditando, nome: e.target.value })
                    }
                    required
                    className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Marca</label>
                  <input
                    type="text"
                    value={produtoEditando.marca}
                    onChange={(e) =>
                      setProdutoEditando({ ...produtoEditando, marca: e.target.value })
                    }
                    required
                    className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Voltagem</label>
                  <select
                    value={produtoEditando.voltagem}
                    onChange={(e) =>
                      setProdutoEditando({ ...produtoEditando, voltagem: e.target.value as any })
                    }
                    className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800"
                  >
                    <option value="110V">110V</option>
                    <option value="220V">220V</option>
                    <option value="Bivolt">Bivolt</option>
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Preço de Venda (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={produtoEditando.precoVenda}
                    onChange={(e) =>
                      setProdutoEditando({ ...produtoEditando, precoVenda: Number(e.target.value) })
                    }
                    required
                    className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded font-semibold text-neutral-900"
                  />
                </div>

                <div>
                  <label className="block text-neutral-700 font-medium mb-1">Quantidade em Estoque</label>
                  <input
                    type="number"
                    min="0"
                    value={produtoEditando.estoque}
                    onChange={(e) =>
                      setProdutoEditando({ ...produtoEditando, estoque: Number(e.target.value) })
                    }
                    required
                    className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded font-semibold text-neutral-900"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-neutral-700 font-medium mb-1">Localização no Depósito</label>
                  <input
                    type="text"
                    value={produtoEditando.localizacao}
                    onChange={(e) =>
                      setProdutoEditando({ ...produtoEditando, localizacao: e.target.value })
                    }
                    className="w-full px-2.5 py-1.5 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setProdutoEditando(null)}
                  className="px-3 py-1.5 bg-[#f4f4f4] hover:bg-neutral-200 text-neutral-700 font-medium rounded"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-orange-600 hover:bg-orange-700 text-white font-medium rounded"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. MODAL DE EXCLUSÃO */}
      {produtoExcluir && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-5 border border-neutral-300 shadow-lg">
            <div className="pb-2 border-b border-neutral-200 font-semibold text-neutral-800 text-sm">
              Confirmar Exclusão de Produto
            </div>

            <div className="my-3 text-xs text-neutral-700 space-y-2">
              <p>
                Tem certeza que deseja remover do estoque o seguinte eletrodoméstico?
              </p>
              <div className="p-3 bg-[#f4f4f4] border border-neutral-200 rounded font-normal">
                <div>Nome: <strong className="font-semibold">{produtoExcluir.nome}</strong></div>
                <div>Código: <span className="font-mono">{produtoExcluir.codigo}</span></div>
                <div>Estoque atual: <strong className="font-semibold">{produtoExcluir.estoque} unidades</strong></div>
              </div>
              <p className="text-orange-700 font-normal">
                Esta ação removerá definitivamente o item do estoque da loja.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-200 text-xs">
              <button
                type="button"
                onClick={() => setProdutoExcluir(null)}
                className="px-3 py-1.5 bg-[#f4f4f4] hover:bg-neutral-200 text-neutral-700 font-medium rounded"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onExcluirProduto(produtoExcluir.id);
                  setProdutoExcluir(null);
                  setMensagemSucesso(`Produto "${produtoExcluir.nome}" excluído com sucesso.`);
                  setTimeout(() => setMensagemSucesso(''), 4000);
                }}
                className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white font-medium rounded"
              >
                Sim, Excluir Produto
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
