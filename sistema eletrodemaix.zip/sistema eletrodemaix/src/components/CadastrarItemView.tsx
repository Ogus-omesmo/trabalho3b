import React, { useState } from 'react';
import { Eletrodomestico, CategoriaEletro, Voltagem } from '../types';

interface CadastrarItemViewProps {
  onAdicionarProduto: (produto: Eletrodomestico) => void;
}

const CATEGORIAS: CategoriaEletro[] = [
  'Refrigeração',
  'Lavanderia',
  'Cocção',
  'Eletroportáteis',
  'Climatização',
  'TVs e Áudio',
  'Linha Branca'
];

export const CadastrarItemView: React.FC<CadastrarItemViewProps> = ({ onAdicionarProduto }) => {
  const [formCodigo, setFormCodigo] = useState(`ELTDMS - ${Math.floor(1000 + Math.random() * 9000)}`);
  const [formNome, setFormNome] = useState('');
  const [formCategoria, setFormCategoria] = useState<CategoriaEletro>('Refrigeração');
  const [formMarca, setFormMarca] = useState('');
  const [formModelo, setFormModelo] = useState('');
  const [formVoltagem, setFormVoltagem] = useState<Voltagem>('110V');
  const [formPrecoCusto, setFormPrecoCusto] = useState<number | ''>('');
  const [formPrecoVenda, setFormPrecoVenda] = useState<number | ''>('');
  const [formEstoque, setFormEstoque] = useState<number | ''>(10);
  const [formEstoqueMinimo, setFormEstoqueMinimo] = useState<number | ''>(4);
  const [formLocalizacao, setFormLocalizacao] = useState('Corredor 1');
  const [mensagemSucesso, setMensagemSucesso] = useState('');

  const handleCriarProduto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNome.trim() || !formMarca.trim() || Number(formPrecoVenda) <= 0) {
      alert('Preencha os campos obrigatórios com valores válidos.');
      return;
    }

    const novoProduto: Eletrodomestico = {
      id: `eletro-${Date.now()}`,
      codigo: formCodigo.trim() || `ELTDMS - ${Math.floor(1000 + Math.random() * 9000)}`,
      nome: formNome.trim(),
      categoria: formCategoria,
      marca: formMarca.trim(),
      modelo: formModelo.trim(),
      voltagem: formVoltagem,
      cor: 'Padrão',
      precoCusto: Number(formPrecoCusto) || 0,
      precoVenda: Number(formPrecoVenda) || 0,
      estoque: Number(formEstoque) || 0,
      estoqueMinimo: Number(formEstoqueMinimo) || 0,
      localizacao: formLocalizacao.trim() || 'Depósito Principal',
      garantiaMeses: 12,
      ativo: true
    };

    onAdicionarProduto(novoProduto);

    // Gera novo código no padrão ELTDMS - XXXX e limpa campos
    setFormCodigo(`ELTDMS - ${Math.floor(1000 + Math.random() * 9000)}`);
    setFormNome('');
    setFormMarca('');
    setFormModelo('');
    setFormPrecoCusto('');
    setFormPrecoVenda('');
    setFormEstoque(10);
    setMensagemSucesso(`Eletrodoméstico "${novoProduto.nome}" cadastrado com sucesso!`);
    setTimeout(() => setMensagemSucesso(''), 5000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white p-4 border border-neutral-300 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
        <div>
          <h1 className="text-base font-semibold text-neutral-800">
            Cadastrar Novo Item
          </h1>
          <p className="text-xs text-neutral-500 font-normal">
            Preencha os dados do eletrodoméstico para inseri-lo no estoque da loja
          </p>
        </div>
        <span className="text-xs text-neutral-600 bg-[#f4f4f4] px-3 py-1.5 rounded border border-neutral-200 font-normal">
          Padrão de Código: <strong className="font-mono">ELTDMS - XXXX</strong>
        </span>
      </div>

      {mensagemSucesso && (
        <div className="p-3 bg-white border border-orange-500 text-neutral-800 text-xs font-medium rounded shadow-xs">
          {mensagemSucesso}
        </div>
      )}

      <div className="bg-white border border-neutral-300 rounded-lg p-6 shadow-xs">
        <form onSubmit={handleCriarProduto} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* Código / SKU */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Código (SKU) *
              </label>
              <input
                type="text"
                value={formCodigo}
                onChange={(e) => setFormCodigo(e.target.value)}
                placeholder="ELTDMS - 1001"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 font-mono text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Nome do Produto */}
            <div className="sm:col-span-2">
              <label className="block text-neutral-700 font-medium mb-1">
                Nome do Eletrodoméstico *
              </label>
              <input
                type="text"
                value={formNome}
                onChange={(e) => setFormNome(e.target.value)}
                placeholder="Ex: Geladeira Brastemp Frost Free Duplex"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Categoria */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Categoria *
              </label>
              <select
                value={formCategoria}
                onChange={(e) => setFormCategoria(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              >
                {CATEGORIAS.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Marca */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Marca *
              </label>
              <input
                type="text"
                value={formMarca}
                onChange={(e) => setFormMarca(e.target.value)}
                placeholder="Ex: Brastemp, Electrolux"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Modelo */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Modelo
              </label>
              <input
                type="text"
                value={formModelo}
                onChange={(e) => setFormModelo(e.target.value)}
                placeholder="Ex: BRM44HK"
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Voltagem */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Voltagem *
              </label>
              <select
                value={formVoltagem}
                onChange={(e) => setFormVoltagem(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              >
                <option value="110V">110V</option>
                <option value="220V">220V</option>
                <option value="Bivolt">Bivolt</option>
              </select>
            </div>

            {/* Localização no Depósito */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Localização no Depósito
              </label>
              <input
                type="text"
                value={formLocalizacao}
                onChange={(e) => setFormLocalizacao(e.target.value)}
                placeholder="Ex: Corredor A, Prateleira 2"
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Preço de Custo */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Preço de Custo (R$)
              </label>
              <input
                type="number"
                step="0.01"
                value={formPrecoCusto}
                onChange={(e) => setFormPrecoCusto(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0.00"
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Preço de Venda */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Preço de Venda (R$) *
              </label>
              <input
                type="number"
                step="0.01"
                value={formPrecoVenda}
                onChange={(e) => setFormPrecoVenda(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0.00"
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-orange-500 rounded text-neutral-900 font-semibold text-xs focus:outline-none focus:bg-white"
              />
            </div>

            {/* Quantidade em Estoque */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Quantidade Inicial em Estoque *
              </label>
              <input
                type="number"
                min="0"
                value={formEstoque}
                onChange={(e) => setFormEstoque(e.target.value === '' ? '' : Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>

            {/* Estoque Mínimo */}
            <div>
              <label className="block text-neutral-700 font-medium mb-1">
                Estoque Mínimo de Alerta
              </label>
              <input
                type="number"
                min="1"
                value={formEstoqueMinimo}
                onChange={(e) => setFormEstoqueMinimo(e.target.value === '' ? '' : Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-[#f4f4f4] border border-neutral-300 rounded text-neutral-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-200">
            <button
              type="submit"
              className="px-6 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-medium text-xs sm:text-sm rounded transition-colors shadow-xs cursor-pointer"
            >
              Salvar e Cadastrar Eletrodoméstico
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
