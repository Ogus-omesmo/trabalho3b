import { supabase, isSupabaseConfigured } from './supabaseClient';
import {
  Eletrodomestico,
  Funcionario,
  Venda,
  PedidoOnline,
  Envio,
  ItemVendaGravado,
  CategoriaEletro,
  Voltagem,
  FormaPagamento
} from './types';

// ==========================================
// 1. PRODUTOS / ELETRODOMÉSTICOS
// ==========================================

export async function carregarProdutosSupabase(): Promise<Eletrodomestico[] | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase
      .from('produtos')
      .select('*')
      .order('criado_em', { ascending: false });

    if (error || !data) {
      console.warn('Supabase: Erro ao carregar produtos:', error?.message);
      return null;
    }

    return data.map((row) => ({
      id: row.id,
      codigo: row.codigo,
      nome: row.nome,
      categoria: row.categoria as CategoriaEletro,
      marca: row.marca,
      modelo: row.modelo || '',
      voltagem: row.voltagem as Voltagem,
      cor: row.cor || 'Padrão',
      precoCusto: Number(row.preco_custo) || 0,
      precoVenda: Number(row.preco_venda) || 0,
      estoque: Number(row.estoque) || 0,
      estoqueMinimo: Number(row.estoque_minimo) || 4,
      localizacao: row.localizacao || 'Depósito Principal',
      garantiaMeses: Number(row.garantia_meses) || 12,
      ativo: Boolean(row.ativo)
    }));
  } catch (err) {
    console.warn('Supabase: Falha na conexão:', err);
    return null;
  }
}

export async function salvarProdutoSupabase(produto: Eletrodomestico): Promise<void> {
  if (!isSupabaseConfigured || !supabase) return;

  try {
    await supabase.from('produtos').insert([
      {
        codigo: produto.codigo,
        nome: produto.nome,
        categoria: produto.categoria,
        marca: produto.marca,
        modelo: produto.modelo,
        voltagem: produto.voltagem,
        cor: produto.cor,
        preco_custo: produto.precoCusto,
        preco_venda: produto.precoVenda,
        estoque: produto.estoque,
        estoque_minimo: produto.estoqueMinimo,
        localizacao: produto.localizacao,
        garantia_meses: produto.garantiaMeses,
        ativo: produto.ativo
      }
    ]);
  } catch (err) {
    console.warn('Supabase: Erro ao salvar produto:', err);
  }
}

export async function atualizarProdutoSupabase(produto: Eletrodomestico): Promise<void> {
  if (!isSupabaseConfigured || !supabase) return;

  try {
    await supabase
      .from('produtos')
      .update({
        codigo: produto.codigo,
        nome: produto.nome,
        categoria: produto.categoria,
        marca: produto.marca,
        modelo: produto.modelo,
        voltagem: produto.voltagem,
        cor: produto.cor,
        preco_custo: produto.precoCusto,
        preco_venda: produto.precoVenda,
        estoque: produto.estoque,
        estoque_minimo: produto.estoqueMinimo,
        localizacao: produto.localizacao,
        garantia_meses: produto.garantiaMeses,
        ativo: produto.ativo
      })
      .match(produto.id.startsWith('eletro-') ? { codigo: produto.codigo } : { id: produto.id });
  } catch (err) {
    console.warn('Supabase: Erro ao atualizar produto:', err);
  }
}

export async function excluirProdutoSupabase(produto: Eletrodomestico): Promise<void> {
  if (!isSupabaseConfigured || !supabase) return;

  try {
    await supabase
      .from('produtos')
      .delete()
      .match(produto.id.startsWith('eletro-') ? { codigo: produto.codigo } : { id: produto.id });
  } catch (err) {
    console.warn('Supabase: Erro ao excluir produto:', err);
  }
}

export async function ajustarEstoqueSupabase(produto: Eletrodomestico, novoEstoque: number): Promise<void> {
  if (!isSupabaseConfigured || !supabase) return;

  try {
    await supabase
      .from('produtos')
      .update({ estoque: novoEstoque })
      .match(produto.id.startsWith('eletro-') ? { codigo: produto.codigo } : { id: produto.id });
  } catch (err) {
    console.warn('Supabase: Erro ao ajustar estoque:', err);
  }
}

// ==========================================
// 2. FUNCIONÁRIOS
// ==========================================

export async function carregarFuncionariosSupabase(): Promise<Funcionario[] | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase.from('funcionarios').select('*');
    if (error || !data || data.length === 0) return null;

    return data.map((row) => ({
      id: row.id,
      usuario: row.usuario,
      senha: row.senha,
      nome: row.nome,
      cargo: row.cargo,
      role: row.role,
      matricula: row.matricula || '',
      email: row.email || '',
      telefone: row.telefone || ''
    }));
  } catch (err) {
    console.warn('Supabase: Erro ao carregar funcionários:', err);
    return null;
  }
}

// ==========================================
// 3. VENDAS
// ==========================================

export async function carregarVendasSupabase(): Promise<Venda[] | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data: vendasData, error: errVendas } = await supabase
      .from('vendas')
      .select('*')
      .order('criado_em', { ascending: false });

    if (errVendas || !vendasData) return null;

    const { data: itensData } = await supabase.from('itens_venda').select('*');

    return vendasData.map((v) => {
      const itensFiltrados: ItemVendaGravado[] = (itensData || [])
        .filter((it) => it.venda_id === v.id)
        .map((it) => ({
          produtoId: it.produto_id || '',
          codigo: it.codigo,
          nome: it.nome,
          marca: it.marca || '',
          voltagem: (it.voltagem as Voltagem) || '110V',
          quantidade: Number(it.quantidade) || 1,
          precoUnitario: Number(it.preco_unitario) || 0,
          subtotal: Number(it.subtotal) || 0
        }));

      return {
        id: v.id,
        numero: v.numero,
        dataHora: v.data_hora,
        vendedorId: v.vendedor_id || '',
        vendedorNome: v.vendedor_nome,
        clienteNome: v.cliente_nome,
        clienteCpf: v.cliente_cpf || '',
        clienteTelefone: v.cliente_telefone || '',
        itens: itensFiltrados,
        subtotal: Number(v.subtotal) || 0,
        desconto: Number(v.desconto) || 0,
        total: Number(v.total) || 0,
        formaPagamento: v.forma_pagamento as FormaPagamento,
        tipoEntrega: 'retirada',
        status: v.status as 'concluida' | 'cancelada'
      };
    });
  } catch (err) {
    console.warn('Supabase: Erro ao carregar vendas:', err);
    return null;
  }
}

export async function salvarVendaSupabase(venda: Venda): Promise<void> {
  if (!isSupabaseConfigured || !supabase) return;

  try {
    const { data: vendaCriada, error } = await supabase
      .from('vendas')
      .insert([
        {
          numero: venda.numero,
          data_hora: venda.dataHora,
          vendedor_id: venda.vendedorId,
          vendedor_nome: venda.vendedorNome,
          cliente_nome: venda.clienteNome,
          cliente_cpf: venda.clienteCpf,
          cliente_telefone: venda.clienteTelefone,
          subtotal: venda.subtotal,
          desconto: venda.desconto,
          total: venda.total,
          forma_pagamento: venda.formaPagamento,
          status: venda.status
        }
      ])
      .select()
      .single();

    if (error || !vendaCriada) {
      console.warn('Supabase: Erro ao inserir venda:', error?.message);
      return;
    }

    if (venda.itens.length > 0) {
      const itensParaInserir = venda.itens.map((it) => ({
        venda_id: vendaCriada.id,
        codigo: it.codigo,
        nome: it.nome,
        marca: it.marca,
        voltagem: it.voltagem,
        quantidade: it.quantidade,
        preco_unitario: it.precoUnitario,
        subtotal: it.subtotal
      }));

      await supabase.from('itens_venda').insert(itensParaInserir);
    }
  } catch (err) {
    console.warn('Supabase: Erro ao salvar venda:', err);
  }
}

export async function cancelarVendaSupabase(vendaId: string, numero: string): Promise<void> {
  if (!isSupabaseConfigured || !supabase) return;

  try {
    await supabase
      .from('vendas')
      .update({ status: 'cancelada' })
      .match(vendaId.startsWith('ven-') ? { numero } : { id: vendaId });
  } catch (err) {
    console.warn('Supabase: Erro ao cancelar venda:', err);
  }
}

// ==========================================
// 4. PEDIDOS ONLINE E ENVIOS
// ==========================================

export async function carregarPedidosOnlineSupabase(): Promise<PedidoOnline[] | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase
      .from('pedidos_online')
      .select('*')
      .order('criado_em', { ascending: false });

    if (error || !data) return null;

    return data.map((p) => ({
      id: p.id,
      numero: p.numero,
      dataHora: p.data_hora,
      clienteNome: p.cliente_nome,
      clienteTelefone: p.cliente_telefone || '',
      endereco: p.endereco,
      cidade: p.cidade,
      itens: [],
      total: Number(p.total) || 0,
      status: p.status,
      pagamento: p.pagamento
    }));
  } catch (err) {
    console.warn('Supabase: Erro pedidos online:', err);
    return null;
  }
}

export async function carregarEnviosSupabase(): Promise<Envio[] | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase
      .from('envios')
      .select('*')
      .order('criado_em', { ascending: false });

    if (error || !data) return null;

    return data.map((e) => ({
      id: e.id,
      codigoRastreio: e.codigo_rastreio,
      pedidoNumero: e.pedido_numero,
      destinatario: e.destinatario,
      enderecoEntrega: e.endereco_entrega,
      cidade: e.cidade,
      transportadora: e.transportadora,
      dataDespacho: e.data_despacho || '',
      previsaoEntrega: e.previsao_entrega || '',
      status: e.status
    }));
  } catch (err) {
    console.warn('Supabase: Erro envios:', err);
    return null;
  }
}
